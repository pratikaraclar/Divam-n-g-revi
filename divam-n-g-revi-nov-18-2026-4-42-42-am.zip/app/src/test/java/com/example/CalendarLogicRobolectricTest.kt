package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.TaskDraft
import com.example.core.data.local.TaskRepository
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskScheduleValidator
import com.example.core.model.TaskStatus
import com.example.core.model.WeekStartDay
import com.example.feature.calendar.CalendarLogic
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CalendarLogicRobolectricTest {

    private lateinit var database: DivamDatabase
    private lateinit var repository: TaskRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, DivamDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = TaskRepository(database.taskDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `rescheduling task persists updated date and time in Room`() = runTest {
        repository.ensureDefaultCategories()
        val day1 = TaskDateTimeUtils.localDayMillis(2026, 10, 17)
        val day2 = TaskDateTimeUtils.localDayMillis(2026, 10, 19)

        val id = repository.createTask(
            TaskDraft(
                title = "Mimarlık Toplantısı",
                description = "Kat planları incelemesi",
                note = "",
                startDateMillis = day1,
                endDateMillis = day1,
                startTimeMinutes = 10 * 60,
                endTimeMinutes = 11 * 60,
                priority = TaskPriority.HIGH,
                categoryId = "cat_is",
                categoryName = "İş",
                status = TaskStatus.PENDING,
                isFavorite = false
            )
        )

        repository.rescheduleTask(
            taskId = id,
            startDateMillis = day2,
            endDateMillis = day2,
            startTimeMinutes = 14 * 60 + 30,
            endTimeMinutes = 15 * 60 + 30
        )

        val updated = repository.getTaskById(id)
        assertNotNull(updated)
        assertEquals(day2, updated?.startDateMillis)
        assertEquals(day2, updated?.endDateMillis)
        assertEquals(14 * 60 + 30, updated?.startTimeMinutes)
        assertEquals(15 * 60 + 30, updated?.endTimeMinutes)
        assertEquals(1, repository.tasksFlow.first().size)
    }

    @Test
    fun `daily schedule groups overlapping and same-hour tasks cleanly`() {
        val day = TaskDateTimeUtils.localDayMillis(2026, 10, 17)
        val t1 = sampleTask(1L, "Toplantı A", day, 9 * 60, 10 * 60, TaskPriority.HIGH)
        val t2 = sampleTask(2L, "Toplantı B", day, 9 * 60 + 15, 10 * 60 + 30, TaskPriority.NORMAL)
        val t3 = sampleTask(3L, "Öğle Arası", day, 12 * 60, 13 * 60, TaskPriority.LOW)
        val untimed = sampleTask(4L, "Esnek Okuma", day, null, null, TaskPriority.NORMAL)

        val schedule = CalendarLogic.buildDailySchedule(
            tasksForDay = listOf(t1, t2, t3, untimed),
            use24HourFormat = true
        )

        assertEquals(2, schedule.timedClusters.size)
        assertTrue(schedule.timedClusters[0].hasOverlap)
        assertEquals(2, schedule.timedClusters[0].tasks.size)
        assertFalse(schedule.timedClusters[1].hasOverlap)
        assertEquals(1, schedule.untimedTasks.size)
    }

    @Test
    fun `week start day switches cleanly between Monday and Sunday`() {
        // 18 Kasım 2026 Çarşamba günü
        val wednesday = TaskDateTimeUtils.localDayMillis(2026, Calendar.NOVEMBER, 18)

        val monWeek = CalendarLogic.weekDaysFor(wednesday, WeekStartDay.MONDAY)
        val sunWeek = CalendarLogic.weekDaysFor(wednesday, WeekStartDay.SUNDAY)

        val calMon = Calendar.getInstance().apply { timeInMillis = monWeek.first() }
        val calSun = Calendar.getInstance().apply { timeInMillis = sunWeek.first() }

        assertEquals(Calendar.MONDAY, calMon.get(Calendar.DAY_OF_WEEK))
        assertEquals(Calendar.SUNDAY, calSun.get(Calendar.DAY_OF_WEEK))
        assertEquals(7, monWeek.size)
        assertEquals(7, sunWeek.size)
    }

    @Test
    fun `calendar filters by category and status while excluding archived and deleted`() {
        val day = TaskDateTimeUtils.localDayMillis(2026, 10, 17)
        val activeWork = sampleTask(1L, "Aktif İş", day, 9 * 60, 10 * 60, TaskPriority.HIGH, "cat_is", TaskStatus.PENDING)
        val postponedSport = sampleTask(2L, "Ertelenen Spor", day, 18 * 60, 19 * 60, TaskPriority.LOW, "cat_spor", TaskStatus.POSTPONED)
        val archivedWork = sampleTask(3L, "Arşiv İş", day, 8 * 60, 9 * 60, TaskPriority.NORMAL, "cat_is", TaskStatus.COMPLETED, isArchived = true)
        val deletedWork = sampleTask(4L, "Silinen İş", day, 11 * 60, 12 * 60, TaskPriority.NORMAL, "cat_is", TaskStatus.PENDING, isDeleted = true)

        val all = listOf(activeWork, postponedSport, archivedWork, deletedWork)
        val onlyWork = CalendarLogic.filterTasksForCalendar(all, categoryFilterId = "cat_is", statusFilter = null)
        assertEquals(1, onlyWork.size)
        assertEquals("Aktif İş", onlyWork.first().title)

        val onlyPostponed = CalendarLogic.filterTasksForCalendar(all, categoryFilterId = null, statusFilter = TaskStatus.POSTPONED)
        assertEquals(1, onlyPostponed.size)
        assertEquals("Ertelenen Spor", onlyPostponed.first().title)
    }

    @Test
    fun `schedule validator rejects invalid date and time ranges`() {
        val d1 = TaskDateTimeUtils.localDayMillis(2026, 10, 20)
        val d2 = TaskDateTimeUtils.localDayMillis(2026, 10, 18)

        val blankTitle = TaskScheduleValidator.validate("   ", d1, d1, 9 * 60, 10 * 60)
        assertFalse(blankTitle.isValid)
        assertNotNull(blankTitle.titleError)

        val endBeforeStartDate = TaskScheduleValidator.validate("Test", d1, d2, null, null)
        assertFalse(endBeforeStartDate.isValid)
        assertNotNull(endBeforeStartDate.scheduleError)

        val endBeforeStartSameDay = TaskScheduleValidator.validate("Test", d1, d1, 15 * 60, 14 * 60)
        assertFalse(endBeforeStartSameDay.isValid)
        assertNotNull(endBeforeStartSameDay.scheduleError)

        val validCrossDay = TaskScheduleValidator.validate("Test", d2, d1, 20 * 60, 9 * 60)
        assertTrue(validCrossDay.isValid)
    }

    private fun sampleTask(
        id: Long,
        title: String,
        dayMillis: Long,
        startTime: Int?,
        endTime: Int?,
        priority: TaskPriority,
        categoryId: String = "cat_is",
        status: TaskStatus = TaskStatus.PENDING,
        isArchived: Boolean = false,
        isDeleted: Boolean = false
    ) = TaskItem(
        id = id,
        title = title,
        description = "",
        note = "",
        startDateMillis = dayMillis,
        endDateMillis = dayMillis,
        startTimeMinutes = startTime,
        endTimeMinutes = endTime,
        priority = priority,
        categoryId = categoryId,
        categoryName = if (categoryId == "cat_is") "İş" else "Spor",
        status = status,
        isFavorite = false,
        isArchived = isArchived,
        isDeleted = isDeleted,
        deletedAtMillis = null,
        completedAtMillis = null,
        createdAtMillis = dayMillis,
        updatedAtMillis = dayMillis
    )
}
