package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.backup.TaskBackupManager
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.TaskDraft
import com.example.core.data.local.TaskRepository
import com.example.core.data.preferences.UserPreferencesRepository
import com.example.core.model.AppFontScale
import com.example.core.model.DateFormatStyle
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskStatus
import com.example.core.model.WeekStartDay
import com.example.core.security.AppSecurityHelper
import com.example.feature.stats.StatsCalculator
import com.example.feature.stats.StatsDateRangePreset
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StatsAndSecurityBackupRobolectricTest {

    @Test
    fun `stats calculator computes daily weekly monthly goals comparisons and deduplicates ids`() {
        val today = TaskDateTimeUtils.localDayMillis(2026, Calendar.NOVEMBER, 18)
        val yesterday = TaskDateTimeUtils.addDaysToLocalDayMillis(today, -1)
        val lastWeekDay = TaskDateTimeUtils.addDaysToLocalDayMillis(today, -7)

        val completedToday = makeTask(
            id = 1L,
            title = "Bugün Biten",
            dayMillis = today,
            status = TaskStatus.COMPLETED,
            priority = TaskPriority.HIGH,
            categoryId = "cat_is",
            categoryName = "İş",
            completedAt = today + 9 * 3600_000L
        )
        val pendingToday = makeTask(
            id = 2L,
            title = "Bugün Bekleyen",
            dayMillis = today,
            status = TaskStatus.PENDING,
            priority = TaskPriority.NORMAL,
            categoryId = "cat_kisisel",
            categoryName = "Kişisel"
        )
        val overdueYesterday = makeTask(
            id = 3L,
            title = "Dünden Geciken",
            dayMillis = yesterday,
            status = TaskStatus.PENDING,
            priority = TaskPriority.HIGH,
            categoryId = "cat_is",
            categoryName = "İş"
        )
        val cancelledToday = makeTask(
            id = 4L,
            title = "İptal Edilen",
            dayMillis = today,
            status = TaskStatus.CANCELLED,
            priority = TaskPriority.LOW,
            categoryId = "cat_spor",
            categoryName = "Spor"
        )
        val lastWeekDone = makeTask(
            id = 5L,
            title = "Geçen Hafta Biten",
            dayMillis = lastWeekDay,
            status = TaskStatus.COMPLETED,
            priority = TaskPriority.NORMAL,
            categoryId = "cat_is",
            categoryName = "İş",
            completedAt = lastWeekDay + 12 * 3600_000L
        )

        // Kasıtlı olarak id=1'i iki kez geçirerek tekilleştirmeyi doğrula
        val snapshot = StatsCalculator.calculate(
            allTasks = listOf(completedToday, completedToday, pendingToday, overdueYesterday, cancelledToday, lastWeekDone),
            todayDayMillis = today,
            rangePreset = StatsDateRangePreset.LAST_7_DAYS,
            customStartDayMillis = null,
            customEndDayMillis = null,
            categoryFilterId = null,
            weekStartDay = WeekStartDay.MONDAY,
            dailyGoalTarget = 4,
            weeklyGoalTarget = 10
        )

        assertEquals(5, snapshot.totalActiveRecords)
        assertEquals(1, snapshot.dailyCompletedCount)
        assertEquals(1, snapshot.dailyPendingCount)
        assertEquals(1, snapshot.dailyOverdueCount)
        assertEquals(50, snapshot.dailyCompletionPercent)
        assertEquals(1, snapshot.dailyGoal.completed)
        assertEquals(4, snapshot.dailyGoal.target)
        assertEquals("İş", snapshot.topCategories.first().categoryName)
        assertTrue(snapshot.weekComparison.previousCount >= 1)
    }

    @Test
    fun `json backup export validate and restore prevents duplicates and rejects corrupted input`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, DivamDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = TaskRepository(db.taskDao())
        repo.ensureDefaultCategories()

        val day = TaskDateTimeUtils.localDayMillis(2026, Calendar.NOVEMBER, 17)
        repo.createTask(
            TaskDraft(
                title = "Yedeklenecek Görev",
                description = "Açıklama",
                note = "Özel not",
                startDateMillis = day,
                endDateMillis = day,
                startTimeMinutes = 9 * 60,
                endTimeMinutes = 10 * 60,
                priority = TaskPriority.HIGH,
                categoryId = "cat_is",
                categoryName = "İş",
                status = TaskStatus.PENDING,
                isFavorite = true
            )
        )

        val tasks = repo.tasksFlow.first()
        val categories = repo.categoriesFlow.first()
        val json = TaskBackupManager.serializeToJson(tasks, categories)

        // Aynı veritabanına geri yüklemede mükerrer atlanmalı
        val duplicateCheck = TaskBackupManager.parseAndValidate(json, tasks, categories)
        assertTrue(duplicateCheck.isSuccess)
        val dupPreview = duplicateCheck.getOrThrow()
        assertEquals(1, dupPreview.totalTasksInFile)
        assertEquals(0, dupPreview.newTasksToImportCount)
        assertEquals(1, dupPreview.duplicateTasksSkippedCount)

        // Boş/bozuk JSON reddedilmeli
        val corrupted = TaskBackupManager.parseAndValidate("{invalid_json", tasks, categories)
        assertTrue(corrupted.isFailure)

        // Temiz veritabanına geri yüklemede 1 yeni görev eklenmeli
        val db2 = Room.inMemoryDatabaseBuilder(context, DivamDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo2 = TaskRepository(db2.taskDao())
        repo2.ensureDefaultCategories()
        val freshPreview = TaskBackupManager.parseAndValidate(json, emptyList(), repo2.categoriesFlow.first()).getOrThrow()
        assertEquals(1, freshPreview.newTasksToImportCount)
        val summary = repo2.restoreFromBackup(freshPreview.document)
        assertEquals(1, summary.importedTasksCount)
        assertEquals(0, summary.skippedDuplicatesCount)
        assertEquals("Yedeklenecek Görev", repo2.tasksFlow.first().first().title)

        db.close()
        db2.close()
    }

    @Test
    fun `pin hashing with salt validates correct pin and rejects wrong pin`() {
        assertTrue(AppSecurityHelper.isPinFormatValid("1453"))
        assertTrue(AppSecurityHelper.isPinFormatValid("258099"))
        assertFalse(AppSecurityHelper.isPinFormatValid("123"))
        assertFalse(AppSecurityHelper.isPinFormatValid("12ab"))

        val salt1 = AppSecurityHelper.generateSalt()
        val salt2 = AppSecurityHelper.generateSalt()
        assertNotEquals(salt1, salt2)

        val hash = AppSecurityHelper.hashPin("4826", salt1)
        assertTrue(AppSecurityHelper.verifyPin("4826", salt1, hash))
        assertFalse(AppSecurityHelper.verifyPin("0000", salt1, hash))
        assertFalse(AppSecurityHelper.verifyPin("4826", salt2, hash))
    }

    @Test
    fun `user preferences repository persists settings and resets appearance cleanly`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = UserPreferencesRepository(context)
        repo.resetAllPreferences()

        repo.update {
            it.copy(
                userName = "Ayşe Yılmaz",
                dailyTaskGoal = 8,
                weeklyTaskGoal = 40,
                goldAccentsEnabled = false,
                fontScale = AppFontScale.LARGE,
                dateFormatStyle = DateFormatStyle.NUMERIC_DOT,
                use24HourFormat = false
            )
        }

        val updated = repo.getSnapshot()
        assertEquals("Ayşe Yılmaz", updated.userName)
        assertEquals(8, updated.dailyTaskGoal)
        assertFalse(updated.goldAccentsEnabled)
        assertEquals(AppFontScale.LARGE, updated.fontScale)
        assertEquals(DateFormatStyle.NUMERIC_DOT, updated.dateFormatStyle)
        assertFalse(updated.use24HourFormat)

        repo.resetAppearanceSettings()
        val afterAppearanceReset = repo.getSnapshot()
        assertTrue(afterAppearanceReset.goldAccentsEnabled)
        assertEquals(AppFontScale.NORMAL, afterAppearanceReset.fontScale)
        // Görünüm sıfırlanınca kullanıcı adı ve hedefler korunur
        assertEquals("Ayşe Yılmaz", afterAppearanceReset.userName)
        assertEquals(8, afterAppearanceReset.dailyTaskGoal)
    }

    private fun makeTask(
        id: Long,
        title: String,
        dayMillis: Long,
        status: TaskStatus,
        priority: TaskPriority,
        categoryId: String,
        categoryName: String,
        completedAt: Long? = null
    ) = TaskItem(
        id = id,
        title = title,
        description = "",
        note = "",
        startDateMillis = dayMillis,
        endDateMillis = dayMillis,
        startTimeMinutes = 10 * 60,
        endTimeMinutes = 11 * 60,
        priority = priority,
        categoryId = categoryId,
        categoryName = categoryName,
        status = status,
        isFavorite = false,
        isArchived = false,
        isDeleted = false,
        deletedAtMillis = null,
        completedAtMillis = completedAt,
        createdAtMillis = dayMillis,
        updatedAtMillis = dayMillis
    )
}
