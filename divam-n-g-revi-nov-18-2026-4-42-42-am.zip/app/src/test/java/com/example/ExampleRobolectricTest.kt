package com.example

import android.content.Context
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.WindowWidthClass
import com.example.core.navigation.TopLevelDestination
import com.example.ui.theme.ThemeMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Divamin Gorevi`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Divamın Görevi", appName)
    }

    @Test
    fun `bottom navigation contains all five Turkish destinations`() {
        val labels = TopLevelDestination.entries.map { it.label }
        assertEquals(
            listOf("Ana Sayfa", "Görevler", "Takvim", "İstatistikler", "Profil"),
            labels
        )
    }

    @Test
    fun `theme mode resolves keys safely with dark fallback`() {
        assertEquals(ThemeMode.LIGHT, ThemeMode.fromKey("light"))
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromKey("system"))
        assertEquals(ThemeMode.DARK, ThemeMode.fromKey("dark"))
        assertEquals(ThemeMode.DARK, ThemeMode.fromKey(null))
    }

    @Test
    fun `window width class switches cleanly between phone and tablet`() {
        val phone = WindowWidthClass.fromWidth(360.dp)
        val mediumTablet = WindowWidthClass.fromWidth(700.dp)
        val expandedTablet = WindowWidthClass.fromWidth(1024.dp)

        assertEquals(WindowWidthClass.COMPACT, phone)
        assertFalse(phone.isTabletOrWide)

        assertEquals(WindowWidthClass.MEDIUM, mediumTablet)
        assertTrue(mediumTablet.isTabletOrWide)

        assertEquals(WindowWidthClass.EXPANDED, expandedTablet)
        assertTrue(expandedTablet.isTabletOrWide)
    }
}
