package com.example

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.DivamDatabase
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationSoundCatalog
import com.example.core.model.QuietHoursPolicy
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import com.example.core.notifications.NotificationChannelHelper
import com.example.core.notifications.ReminderScheduleCalculator
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NotificationAndSoundRobolectricTest {

    @Test
    fun `Room MIGRATION_1_2 preserves existing version 1 tasks without data loss`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "migration_test_${System.currentTimeMillis()}.db"

        // Sürüm 1 şemasını oluştur ve mevcut bir görev ekle
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbName)
                .callback(object : SupportSQLiteOpenHelper.Callback(1) {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        db.execSQL(
                            """
                            CREATE TABLE IF NOT EXISTS tasks (
                                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                                title TEXT NOT NULL,
                                description TEXT NOT NULL,
                                note TEXT NOT NULL,
                                startDateMillis INTEGER,
                                endDateMillis INTEGER,
                                startTimeMinutes INTEGER,
                                endTimeMinutes INTEGER,
                                priority TEXT NOT NULL,
                                categoryId TEXT NOT NULL,
                                categoryName TEXT NOT NULL,
                                status TEXT NOT NULL,
                                isFavorite INTEGER NOT NULL,
                                isArchived INTEGER NOT NULL,
                                isDeleted INTEGER NOT NULL,
                                deletedAtMillis INTEGER,
                                completedAtMillis INTEGER,
                                createdAtMillis INTEGER NOT NULL,
                                updatedAtMillis INTEGER NOT NULL
                            )
                            """.trimIndent()
                        )
                        db.execSQL(
                            """
                            INSERT INTO tasks (
                                id, title, description, note, startDateMillis, endDateMillis,
                                startTimeMinutes, endTimeMinutes, priority, categoryId, categoryName,
                                status, isFavorite, isArchived, isDeleted, deletedAtMillis,
                                completedAtMillis, createdAtMillis, updatedAtMillis
                            ) VALUES (
                                7, 'Sürüm 1 Görevi', 'Açıklama', 'Not', 1794873600000, NULL,
                                540, NULL, 'HIGH', 'cat_is', 'İş',
                                'PENDING', 1, 0, 0, NULL, NULL, 1794873600000, 1794873600000
                            )
                            """.trimIndent()
                        )
                    }

                    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                })
                .build()
        )

        val db = helper.writableDatabase
        DivamDatabase.MIGRATION_1_2.migrate(db)

        val cursor = db.query("SELECT id, title, reminderEnabled, reminderOffsetsCsv, recurrence FROM tasks WHERE id = 7")
        assertTrue(cursor.moveToFirst())
        assertEquals(7L, cursor.getLong(0))
        assertEquals("Sürüm 1 Görevi", cursor.getString(1))
        assertEquals(1, cursor.getInt(2))
        assertEquals("15", cursor.getString(3))
        assertEquals("NONE", cursor.getString(4))
        cursor.close()
        db.close()
        context.deleteDatabase(dbName)
    }

    @Test
    fun `reminder calculator supports all offsets custom offset completed skip and daily recurrence`() {
        val day = TaskDateTimeUtils.localDayMillis(2026, Calendar.NOVEMBER, 20)
        val taskStartTime = 10 * 60 // 10:00
        val beforeStart = TaskDateTimeUtils.combineLocalDayAndMinutes(day, 8 * 60)

        val offsets = listOf(0, 5, 10, 15, 30, 60, 1440, 45)
        val task = TaskItem(
            id = 12L,
            title = "Önemli Görüşme",
            description = "",
            note = "",
            startDateMillis = day,
            endDateMillis = day,
            startTimeMinutes = taskStartTime,
            endTimeMinutes = 11 * 60,
            priority = TaskPriority.HIGH,
            categoryId = "cat_is",
            categoryName = "İş",
            status = TaskStatus.PENDING,
            isFavorite = false,
            isArchived = false,
            isDeleted = false,
            deletedAtMillis = null,
            completedAtMillis = null,
            createdAtMillis = beforeStart,
            updatedAtMillis = beforeStart,
            reminderEnabled = true,
            reminderOffsetsMinutes = offsets,
            recurrence = TaskRecurrence.DAILY
        )

        val exactTrigger = ReminderScheduleCalculator.computeNextTrigger(task, 0, beforeStart)
        assertNotNull(exactTrigger)
        assertEquals(TaskDateTimeUtils.combineLocalDayAndMinutes(day, taskStartTime), exactTrigger!!.triggerAtMillis)

        // 1440 dakika (1 gün) önce geçmişte kaldı -> günlük tekrarda ertesi günün 1 gün öncesine (yani bugüne değil yarına) ilerler
        val oneDayBeforePast = ReminderScheduleCalculator.computeNextTrigger(task, 1440, beforeStart)
        assertNotNull(oneDayBeforePast)
        assertTrue(oneDayBeforePast!!.triggerAtMillis > beforeStart)

        // Tamamlanmış görev için bildirim planlanmaz
        val completedTask = task.copy(status = TaskStatus.COMPLETED)
        assertNull(ReminderScheduleCalculator.computeNextTrigger(completedTask, 15, beforeStart))

        // Silinmiş görev için bildirim planlanmaz
        val deletedTask = task.copy(isDeleted = true)
        assertNull(ReminderScheduleCalculator.computeNextTrigger(deletedTask, 15, beforeStart))
    }

    @Test
    fun `quiet hours handles overnight window and resolves silent vs suppressed policies`() {
        val settingsSilent = NotificationSettings(
            quietHoursEnabled = true,
            quietHoursStartMinutes = 23 * 60,
            quietHoursEndMinutes = 7 * 60 + 30,
            quietHoursPolicy = QuietHoursPolicy.SILENT_DELIVERY,
            soundEnabled = true,
            vibrationEnabled = true
        )

        assertTrue(settingsSilent.isInQuietHours(23 * 60 + 30))
        assertTrue(settingsSilent.isInQuietHours(2 * 60))
        assertFalse(settingsSilent.isInQuietHours(14 * 60))

        val calNight = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 17, 1, 15, 0)
        }
        val behaviorSilent = settingsSilent.resolveBehavior(
            kind = NotificationChannelKind.TASK_REMINDERS,
            atEpochMillis = calNight.timeInMillis,
            respectQuietHours = true
        )
        assertTrue(behaviorSilent.isQuietHoursActive)
        assertTrue(behaviorSilent.useSilentMode)
        assertFalse(behaviorSilent.suppressCompletely)
        assertFalse(behaviorSilent.effectiveSoundEnabled)
        assertFalse(behaviorSilent.effectiveVibrationEnabled)

        val settingsSuppress = settingsSilent.copy(quietHoursPolicy = QuietHoursPolicy.SUPPRESS_COMPLETELY)
        val behaviorSuppress = settingsSuppress.resolveBehavior(
            kind = NotificationChannelKind.TASK_REMINDERS,
            atEpochMillis = calNight.timeInMillis,
            respectQuietHours = true
        )
        assertTrue(behaviorSuppress.suppressCompletely)
    }

    @Test
    fun `notification preferences repository persists sounds and bumps channel version on change`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = NotificationPreferencesRepository(context)
        repo.updateSettings {
            NotificationSettings()
        }

        val initial = repo.getSettingsSnapshot()
        repo.updateChannelConfig(NotificationChannelKind.TASK_REMINDERS) {
            it.copy(soundId = NotificationSoundCatalog.ID_GOLD_CHIME)
        }
        val afterSoundChange = repo.getSettingsSnapshot()
        assertEquals(NotificationSoundCatalog.ID_GOLD_CHIME, afterSoundChange.taskReminderChannel.soundId)
        assertEquals(initial.channelConfigVersion + 1, afterSoundChange.channelConfigVersion)

        val chV1 = NotificationChannelHelper.activeChannelId(NotificationChannelKind.TASK_REMINDERS, initial.channelConfigVersion)
        val chV2 = NotificationChannelHelper.activeChannelId(NotificationChannelKind.TASK_REMINDERS, afterSoundChange.channelConfigVersion)
        assertFalse(chV1 == chV2)

        repo.resetSoundsToDefault()
        val afterReset = repo.getSettingsSnapshot()
        assertEquals(NotificationSoundCatalog.ID_SYSTEM_DEFAULT, afterReset.taskReminderChannel.soundId)
        assertTrue(afterReset.soundEnabled)
        assertTrue(afterReset.vibrationEnabled)
        assertFalse(afterReset.silentNotificationMode)
    }
}
