package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.TaskDraft
import com.example.core.data.local.TaskRepository
import com.example.core.model.TaskBoxFilter
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskPriority
import com.example.core.model.TaskSortOption
import com.example.core.model.TaskStatus
import com.example.feature.tasks.TaskFilterState
import com.example.feature.tasks.TaskViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TaskPersistenceRobolectricTest {

    private lateinit var database: DivamDatabase
    private lateinit var repository: TaskRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, DivamDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = TaskRepository(database.taskDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `default eight Turkish categories seed cleanly and tasks start empty`() = runTest {
        repository.ensureDefaultCategories()

        val categories = repository.categoriesFlow.first()
        val tasks = repository.tasksFlow.first()

        assertEquals(
            listOf("İş", "Kişisel", "Eğitim", "Alışveriş", "Sağlık", "Ev İşleri", "Spor", "Diğer"),
            categories.map { it.name }
        )
        assertTrue(tasks.isEmpty())
    }

    @Test
    fun `user can create custom category and duplicates are rejected`() = runTest {
        repository.ensureDefaultCategories()

        val created = repository.createCustomCategory("Finans")
        assertTrue(created.isSuccess)
        assertEquals("Finans", created.getOrThrow().name)
        assertFalse(created.getOrThrow().isDefault)

        val duplicate = repository.createCustomCategory("finans")
        assertTrue(duplicate.isFailure)

        val categories = repository.categoriesFlow.first()
        assertTrue(categories.any { it.name == "Finans" })
    }

    @Test
    fun `create update duplicate complete postpone favorite archive trash restore and delete work end to end`() = runTest {
        repository.ensureDefaultCategories()
        val today = TaskDateTimeUtils.localDayMillis(2026, 10, 17)
        val tomorrow = TaskDateTimeUtils.localDayMillis(2026, 10, 18)

        val taskId = repository.createTask(
            TaskDraft(
                title = "Bütçe Raporu",
                description = "Aylık gider özetini hazırla",
                note = "Muhasebe ekibiyle paylaşılacak",
                startDateMillis = today,
                endDateMillis = tomorrow,
                startTimeMinutes = 9 * 60 + 30,
                endTimeMinutes = 11 * 60,
                priority = TaskPriority.HIGH,
                categoryId = "cat_is",
                categoryName = "İş",
                status = TaskStatus.IN_PROGRESS,
                isFavorite = true
            )
        )

        val loaded = repository.getTaskById(taskId)
        assertNotNull(loaded)
        assertEquals("Bütçe Raporu", loaded?.title)
        assertEquals("Muhasebe ekibiyle paylaşılacak", loaded?.note)
        assertEquals(TaskPriority.HIGH, loaded?.priority)
        assertEquals(TaskStatus.IN_PROGRESS, loaded?.status)
        assertTrue(loaded?.isFavorite == true)

        // Düzenleme
        repository.updateTask(
            taskId,
            TaskDraft(
                title = "Bütçe Raporu v2",
                description = "Güncel özet",
                note = "Onaylandı",
                startDateMillis = today,
                endDateMillis = tomorrow,
                startTimeMinutes = 10 * 60,
                endTimeMinutes = 12 * 60,
                priority = TaskPriority.NORMAL,
                categoryId = "cat_kisisel",
                categoryName = "Kişisel",
                status = TaskStatus.PENDING,
                isFavorite = false
            )
        )
        val edited = repository.getTaskById(taskId)!!
        assertEquals("Bütçe Raporu v2", edited.title)
        assertEquals("Onaylandı", edited.note)
        assertEquals(TaskPriority.NORMAL, edited.priority)
        assertFalse(edited.isFavorite)

        // Kopyalama
        val copyId = repository.duplicateTask(taskId)!!
        val copied = repository.getTaskById(copyId)!!
        assertEquals("Bütçe Raporu v2 (Kopya)", copied.title)
        assertEquals(TaskStatus.PENDING, copied.status)

        // Tamamlandı işaretleme
        repository.toggleCompleted(taskId)
        assertEquals(TaskStatus.COMPLETED, repository.getTaskById(taskId)?.status)

        // Erteleme (+2 gün)
        repository.postponeTask(taskId, 2)
        val postponed = repository.getTaskById(taskId)!!
        assertEquals(TaskStatus.POSTPONED, postponed.status)
        assertEquals(TaskDateTimeUtils.addDaysToLocalDayMillis(today, 2), postponed.startDateMillis)

        // Favori ve Arşiv
        repository.toggleFavorite(taskId)
        assertTrue(repository.getTaskById(taskId)?.isFavorite == true)
        repository.setArchived(taskId, true)
        assertTrue(repository.getTaskById(taskId)?.isArchived == true)

        // Çöp kutusu -> Geri yükle -> Kalıcı sil
        repository.moveToTrash(taskId)
        assertTrue(repository.getTaskById(taskId)?.isDeleted == true)

        repository.restoreFromTrash(taskId)
        assertFalse(repository.getTaskById(taskId)?.isDeleted == true)

        repository.moveToTrash(copyId)
        repository.emptyTrash()
        assertNull(repository.getTaskById(copyId))
    }

    @Test
    fun `search filter and sort work accurately across tasks`() = runTest {
        repository.ensureDefaultCategories()
        val day1 = TaskDateTimeUtils.localDayMillis(2026, 10, 17)
        val day2 = TaskDateTimeUtils.localDayMillis(2026, 10, 20)

        repository.createTask(
            TaskDraft(
                title = "Koşu Antrenmanı",
                description = "5 km parkur",
                note = "Su şişesi al",
                startDateMillis = day2,
                endDateMillis = day2,
                startTimeMinutes = null,
                endTimeMinutes = null,
                priority = TaskPriority.LOW,
                categoryId = "cat_spor",
                categoryName = "Spor",
                status = TaskStatus.PENDING,
                isFavorite = false
            )
        )
        repository.createTask(
            TaskDraft(
                title = "Proje Sunumu",
                description = "Yönetim kurulu",
                note = "Slaytları kontrol et",
                startDateMillis = day1,
                endDateMillis = day1,
                startTimeMinutes = null,
                endTimeMinutes = null,
                priority = TaskPriority.HIGH,
                categoryId = "cat_is",
                categoryName = "İş",
                status = TaskStatus.IN_PROGRESS,
                isFavorite = true
            )
        )

        val all = repository.tasksFlow.first()
        assertEquals(2, all.size)

        // TaskViewModel arama, filtreleme ve sıralama doğrulaması
        val filtered = TaskViewModel.filterAndSortTasks(
            tasks = all,
            filter = TaskFilterState(
                searchQuery = "Slayt",
                priorityFilter = TaskPriority.HIGH
            )
        )
        assertEquals(1, filtered.size)
        assertEquals("Proje Sunumu", filtered.first().title)

        val allSortedAsc = TaskViewModel.filterAndSortTasks(
            tasks = all,
            filter = TaskFilterState(sortOption = TaskSortOption.PRIORITY_ASC)
        )
        assertEquals("Koşu Antrenmanı", allSortedAsc.first().title)

        val favoritesOnly = TaskViewModel.filterAndSortTasks(
            tasks = all,
            filter = TaskFilterState(boxFilter = TaskBoxFilter.FAVORITES)
        )
        assertEquals(1, favoritesOnly.size)
        assertEquals("Proje Sunumu", favoritesOnly.first().title)
    }
}
