package com.example

import android.app.Application
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.notifications.AndroidTaskReminderScheduler
import com.example.core.notifications.NotificationChannelHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class DivamApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            val settings = NotificationPreferencesRepository(applicationContext).getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(applicationContext, settings)
            AndroidTaskReminderScheduler.create(applicationContext).syncAll()
        }
    }
}
