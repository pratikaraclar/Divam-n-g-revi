package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.navigation.DivamAppShell
import com.example.core.notifications.NotificationChannelHelper
import com.example.core.viewmodel.AppViewModel
import com.example.feature.notifications.NotificationViewModel
import com.example.feature.tasks.TaskViewModel
import com.example.ui.theme.DivaminGoreviTheme

class MainActivity : ComponentActivity() {

    private val appViewModel: AppViewModel by viewModels {
        AppViewModel.Factory(applicationContext)
    }

    private val taskViewModel: TaskViewModel by viewModels {
        TaskViewModel.Factory(applicationContext)
    }

    private val notificationViewModel: NotificationViewModel by viewModels {
        NotificationViewModel.Factory(applicationContext)
    }

    private var pendingLaunchRoute by mutableStateOf<String?>(null)
    private var pendingLaunchTaskId by mutableLongStateOf(-1L)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleLaunchIntent(intent)
        enableEdgeToEdge()
        setContent {
            val themeMode by appViewModel.themeMode.collectAsStateWithLifecycle()
            val userPreferences by appViewModel.userPreferences.collectAsStateWithLifecycle()

            DivaminGoreviTheme(
                themeMode = themeMode,
                userPreferences = userPreferences
            ) {
                DivamAppShell(
                    appViewModel = appViewModel,
                    taskViewModel = taskViewModel,
                    notificationViewModel = notificationViewModel,
                    pendingLaunchRoute = pendingLaunchRoute,
                    pendingLaunchTaskId = pendingLaunchTaskId,
                    onConsumePendingLaunch = {
                        pendingLaunchRoute = null
                        pendingLaunchTaskId = -1L
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    private fun handleLaunchIntent(intent: Intent?) {
        if (intent == null) return
        val taskId = intent.getLongExtra(NotificationChannelHelper.EXTRA_OPEN_TASK_ID, -1L)
        val route = intent.getStringExtra(NotificationChannelHelper.EXTRA_OPEN_ROUTE)
        if (taskId > 0L) {
            pendingLaunchTaskId = taskId
        }
        if (!route.isNullOrBlank()) {
            pendingLaunchRoute = route
        }
    }
}
