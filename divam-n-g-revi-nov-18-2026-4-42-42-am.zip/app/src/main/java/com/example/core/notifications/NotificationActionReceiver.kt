package com.example.core.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.example.core.data.local.DivamDatabase
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.model.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_MARK_COMPLETED) return
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        val notificationId = intent.getIntExtra(EXTRA_NOTIFICATION_ID, -1)
        if (taskId <= 0L) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val db = DivamDatabase.getInstance(appContext)
                val taskDao = db.taskDao()
                val existing = taskDao.getTaskById(taskId)
                if (existing != null && TaskStatus.fromName(existing.status) != TaskStatus.COMPLETED) {
                    val now = System.currentTimeMillis()
                    taskDao.updateTask(
                        existing.copy(
                            status = TaskStatus.COMPLETED.name,
                            completedAtMillis = now,
                            updatedAtMillis = now
                        )
                    )
                }
                AndroidTaskReminderScheduler.create(appContext).onTaskRemoved(taskId)
                val settings = NotificationPreferencesRepository(appContext).getSettingsSnapshot()
                TaskSoundManager.playTaskCompletedFeedback(appContext, settings)
                if (notificationId != -1) {
                    NotificationManagerCompat.from(appContext).cancel(notificationId)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_MARK_COMPLETED = "com.example.action.NOTIFICATION_MARK_COMPLETED"
        const val EXTRA_TASK_ID = "extra_action_task_id"
        const val EXTRA_NOTIFICATION_ID = "extra_action_notification_id"
    }
}
