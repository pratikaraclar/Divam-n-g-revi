package com.example.core.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.NotificationHistoryEntity
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationDeliveryStatus
import com.example.core.model.NotificationType
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TaskReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        val offsetMinutes = intent.getIntExtra(EXTRA_OFFSET_MINUTES, 0)
        val occurrenceDayMillis = intent.getLongExtra(EXTRA_OCCURRENCE_DAY_MILLIS, 0L)
        if (taskId <= 0L) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                handleReminderTrigger(
                    context = context.applicationContext,
                    taskId = taskId,
                    offsetMinutes = offsetMinutes,
                    occurrenceDayMillis = occurrenceDayMillis
                )
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun handleReminderTrigger(
        context: Context,
        taskId: Long,
        offsetMinutes: Int,
        occurrenceDayMillis: Long
    ) {
        val db = DivamDatabase.getInstance(context)
        val taskDao = db.taskDao()
        val notificationDao = db.notificationDao()
        val prefs = NotificationPreferencesRepository(context)
        val settings = prefs.getSettingsSnapshot()

        val task = taskDao.getTaskById(taskId)?.toDomain() ?: run {
            notificationDao.deleteScheduledRemindersForTask(taskId)
            return
        }

        val inactive = !settings.notificationsEnabled ||
            task.isDeleted ||
            task.isArchived ||
            task.status == TaskStatus.COMPLETED ||
            task.status == TaskStatus.CANCELLED ||
            !task.reminderEnabled ||
            offsetMinutes !in task.reminderOffsetsMinutes

        if (inactive) {
            notificationDao.deleteScheduledReminder(taskId, offsetMinutes)
            return
        }

        val now = System.currentTimeMillis()
        val dedupKey = "task_${taskId}_${offsetMinutes}_$occurrenceDayMillis"
        if (notificationDao.countHistoryByDedupKey(dedupKey) > 0) {
            return
        }

        val offsetText = TaskDateTimeUtils.formatReminderOffsetTurkish(offsetMinutes)
        val timeText = task.startTimeMinutes?.let(TaskDateTimeUtils::formatTimeMinutes) ?: ""
        val title = if (offsetMinutes <= 0) {
            "Görev Zamanı: ${task.title}"
        } else {
            "Hatırlatma ($offsetText): ${task.title}"
        }
        val message = buildString {
            append(task.categoryName)
            if (timeText.isNotEmpty()) {
                append(" • Saat $timeText")
            }
            if (task.description.isNotBlank()) {
                append(" — ")
                append(task.description)
            }
        }

        val behavior = settings.resolveBehavior(
            kind = NotificationChannelKind.TASK_REMINDERS,
            atEpochMillis = now,
            respectQuietHours = true
        )

        val status = when {
            !NotificationChannelHelper.hasPostNotificationPermission(context) ->
                NotificationDeliveryStatus.SKIPPED_NO_PERMISSION
            behavior.suppressCompletely ->
                NotificationDeliveryStatus.SUPPRESSED_QUIET_HOURS
            else -> {
                val notificationId = ReminderScheduleCalculator.reminderRequestCode(taskId, offsetMinutes)
                val posted = NotificationChannelHelper.postNotification(
                    context = context,
                    notificationId = notificationId,
                    title = title,
                    message = message,
                    settings = settings,
                    behavior = behavior,
                    taskId = task.id
                )
                if (!posted) {
                    NotificationDeliveryStatus.SKIPPED_NO_PERMISSION
                } else if (behavior.useSilentMode) {
                    NotificationDeliveryStatus.SENT_SILENT
                } else {
                    NotificationDeliveryStatus.SENT
                }
            }
        }

        notificationDao.insertNotificationHistory(
            NotificationHistoryEntity(
                taskId = task.id,
                taskTitle = task.title,
                title = title,
                message = message,
                type = NotificationType.TASK_REMINDER.name,
                deliveryStatus = status.name,
                offsetMinutes = offsetMinutes,
                triggeredAtMillis = now,
                dedupKey = dedupKey
            )
        )

        if (task.recurrence != TaskRecurrence.NONE) {
            AndroidTaskReminderScheduler.create(context).onTaskChanged(task.id)
        } else {
            notificationDao.deleteScheduledReminder(task.id, offsetMinutes)
        }
    }

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_OFFSET_MINUTES = "extra_offset_minutes"
        const val EXTRA_OCCURRENCE_DAY_MILLIS = "extra_occurrence_day_millis"

        fun buildIntent(
            context: Context,
            taskId: Long,
            offsetMinutes: Int,
            occurrenceDayMillis: Long
        ): Intent = Intent(context, TaskReminderReceiver::class.java).apply {
            action = "com.example.action.TASK_REMINDER_$taskId"
            putExtra(EXTRA_TASK_ID, taskId)
            putExtra(EXTRA_OFFSET_MINUTES, offsetMinutes)
            putExtra(EXTRA_OCCURRENCE_DAY_MILLIS, occurrenceDayMillis)
        }
    }
}
