package com.example.core.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.core.model.NotificationDeliveryStatus
import com.example.core.model.NotificationHistoryItem
import com.example.core.model.NotificationType
import com.example.core.model.ScheduledReminderItem
import com.example.core.model.TaskCategory
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isDefault: Boolean,
    val createdAtMillis: Long
) {
    fun toDomain(): TaskCategory = TaskCategory(
        id = id,
        name = name,
        isDefault = isDefault,
        createdAtMillis = createdAtMillis
    )
}

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val description: String,
    val note: String,
    val startDateMillis: Long?,
    val endDateMillis: Long?,
    val startTimeMinutes: Int?,
    val endTimeMinutes: Int?,
    val priority: String,
    val categoryId: String,
    val categoryName: String,
    val status: String,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedAtMillis: Long? = null,
    val completedAtMillis: Long? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val reminderEnabled: Boolean = true,
    val reminderOffsetsCsv: String = "15",
    val recurrence: String = TaskRecurrence.NONE.name
) {
    fun toDomain(): TaskItem = TaskItem(
        id = id,
        title = title,
        description = description,
        note = note,
        startDateMillis = startDateMillis,
        endDateMillis = endDateMillis,
        startTimeMinutes = startTimeMinutes,
        endTimeMinutes = endTimeMinutes,
        priority = TaskPriority.fromName(priority),
        categoryId = categoryId,
        categoryName = categoryName,
        status = TaskStatus.fromName(status),
        isFavorite = isFavorite,
        isArchived = isArchived,
        isDeleted = isDeleted,
        deletedAtMillis = deletedAtMillis,
        completedAtMillis = completedAtMillis,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis,
        reminderEnabled = reminderEnabled,
        reminderOffsetsMinutes = ReminderOffsetsCodec.decode(reminderOffsetsCsv),
        recurrence = TaskRecurrence.fromName(recurrence)
    )
}

@Entity(
    tableName = "scheduled_reminders",
    indices = [
        Index(value = ["taskId", "offsetMinutes"], unique = true),
        Index(value = ["triggerAtMillis"])
    ]
)
data class ScheduledReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskId: Long,
    val taskTitle: String,
    val offsetMinutes: Int,
    val occurrenceDayMillis: Long,
    val triggerAtMillis: Long,
    val requestCode: Int,
    val updatedAtMillis: Long
) {
    fun toDomain(): ScheduledReminderItem = ScheduledReminderItem(
        id = id,
        taskId = taskId,
        taskTitle = taskTitle,
        offsetMinutes = offsetMinutes,
        occurrenceDayMillis = occurrenceDayMillis,
        triggerAtMillis = triggerAtMillis,
        requestCode = requestCode,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "notification_history",
    indices = [
        Index(value = ["triggeredAtMillis"]),
        Index(value = ["dedupKey"], unique = true)
    ]
)
data class NotificationHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskId: Long?,
    val taskTitle: String,
    val title: String,
    val message: String,
    val type: String,
    val deliveryStatus: String,
    val offsetMinutes: Int?,
    val triggeredAtMillis: Long,
    val dedupKey: String? = null
) {
    fun toDomain(): NotificationHistoryItem = NotificationHistoryItem(
        id = id,
        taskId = taskId,
        taskTitle = taskTitle,
        title = title,
        message = message,
        type = NotificationType.fromName(type),
        deliveryStatus = NotificationDeliveryStatus.fromName(deliveryStatus),
        offsetMinutes = offsetMinutes,
        triggeredAtMillis = triggeredAtMillis
    )
}

object ReminderOffsetsCodec {
    fun decode(csv: String?): List<Int> {
        if (csv.isNullOrBlank()) return emptyList()
        return csv.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it >= 0 }
            .distinct()
            .sorted()
    }

    fun encode(offsets: List<Int>): String {
        return offsets
            .filter { it >= 0 }
            .distinct()
            .sorted()
            .joinToString(",")
    }
}
