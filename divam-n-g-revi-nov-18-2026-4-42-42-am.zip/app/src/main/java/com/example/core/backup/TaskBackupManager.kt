package com.example.core.backup

import android.content.Context
import android.net.Uri
import com.example.core.data.local.ReminderOffsetsCodec
import com.example.core.model.TaskCategory
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupTaskRecord(
    val title: String,
    val description: String,
    val note: String,
    val startDateMillis: Long?,
    val endDateMillis: Long?,
    val startTimeMinutes: Int?,
    val endTimeMinutes: Int?,
    val priority: TaskPriority,
    val categoryId: String,
    val categoryName: String,
    val status: TaskStatus,
    val isFavorite: Boolean,
    val isArchived: Boolean,
    val isDeleted: Boolean,
    val deletedAtMillis: Long?,
    val completedAtMillis: Long?,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val reminderEnabled: Boolean,
    val reminderOffsetsMinutes: List<Int>,
    val recurrence: TaskRecurrence
)

data class BackupCategoryRecord(
    val id: String,
    val name: String,
    val isDefault: Boolean,
    val createdAtMillis: Long
)

data class BackupDocument(
    val schemaVersion: Int,
    val exportedAtMillis: Long,
    val categories: List<BackupCategoryRecord>,
    val tasks: List<BackupTaskRecord>
)

data class BackupValidationPreview(
    val document: BackupDocument,
    val totalTasksInFile: Int,
    val newTasksToImportCount: Int,
    val duplicateTasksSkippedCount: Int,
    val newCategoriesCount: Int
)

data class BackupRestoreSummary(
    val importedTasksCount: Int,
    val skippedDuplicatesCount: Int,
    val importedCategoriesCount: Int
)

object TaskBackupManager {
    private const val SCHEMA_VERSION = 1

    fun taskDeduplicationSignature(
        title: String,
        startDateMillis: Long?,
        startTimeMinutes: Int?,
        categoryName: String
    ): String {
        val normTitle = title.trim().lowercase(Locale.forLanguageTag("tr-TR"))
        val normCat = categoryName.trim().lowercase(Locale.forLanguageTag("tr-TR"))
        return "$normTitle|${startDateMillis ?: -1L}|${startTimeMinutes ?: -1}|$normCat"
    }

    fun taskDeduplicationSignature(task: TaskItem): String =
        taskDeduplicationSignature(task.title, task.startDateMillis, task.startTimeMinutes, task.categoryName)

    fun taskDeduplicationSignature(record: BackupTaskRecord): String =
        taskDeduplicationSignature(record.title, record.startDateMillis, record.startTimeMinutes, record.categoryName)

    fun serializeToJson(
        tasks: List<TaskItem>,
        categories: List<TaskCategory>,
        exportedAtMillis: Long = System.currentTimeMillis()
    ): String {
        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)
        root.put("appName", "Divamın Görevi")
        root.put("exportedAtMillis", exportedAtMillis)

        val catsJson = JSONArray()
        categories.forEach { cat ->
            catsJson.put(
                JSONObject().apply {
                    put("id", cat.id)
                    put("name", cat.name)
                    put("isDefault", cat.isDefault)
                    put("createdAtMillis", cat.createdAtMillis)
                }
            )
        }
        root.put("categories", catsJson)

        val tasksJson = JSONArray()
        tasks.forEach { task ->
            tasksJson.put(
                JSONObject().apply {
                    put("title", task.title)
                    put("description", task.description)
                    put("note", task.note)
                    put("startDateMillis", task.startDateMillis ?: JSONObject.NULL)
                    put("endDateMillis", task.endDateMillis ?: JSONObject.NULL)
                    put("startTimeMinutes", task.startTimeMinutes ?: JSONObject.NULL)
                    put("endTimeMinutes", task.endTimeMinutes ?: JSONObject.NULL)
                    put("priority", task.priority.name)
                    put("categoryId", task.categoryId)
                    put("categoryName", task.categoryName)
                    put("status", task.status.name)
                    put("isFavorite", task.isFavorite)
                    put("isArchived", task.isArchived)
                    put("isDeleted", task.isDeleted)
                    put("deletedAtMillis", task.deletedAtMillis ?: JSONObject.NULL)
                    put("completedAtMillis", task.completedAtMillis ?: JSONObject.NULL)
                    put("createdAtMillis", task.createdAtMillis)
                    put("updatedAtMillis", task.updatedAtMillis)
                    put("reminderEnabled", task.reminderEnabled)
                    put("reminderOffsetsCsv", ReminderOffsetsCodec.encode(task.reminderOffsetsMinutes))
                    put("recurrence", task.recurrence.name)
                }
            )
        }
        root.put("tasks", tasksJson)
        return root.toString(2)
    }

    fun parseAndValidate(
        jsonString: String,
        existingTasks: List<TaskItem>,
        existingCategories: List<TaskCategory>
    ): Result<BackupValidationPreview> {
        return runCatching {
            val root = JSONObject(jsonString)
            if (!root.has("schemaVersion") || !root.has("tasks")) {
                throw IllegalArgumentException("Geçersiz yedek dosyası biçimi: zorunlu alanlar eksik.")
            }
            val schemaVersion = root.getInt("schemaVersion")
            if (schemaVersion <= 0 || schemaVersion > SCHEMA_VERSION) {
                throw IllegalArgumentException("Desteklenmeyen yedek sürümü: $schemaVersion")
            }

            val exportedAt = root.optLong("exportedAtMillis", System.currentTimeMillis())

            val categories = mutableListOf<BackupCategoryRecord>()
            val catArray = root.optJSONArray("categories") ?: JSONArray()
            for (i in 0 until catArray.length()) {
                val obj = catArray.getJSONObject(i)
                val name = obj.optString("name", "").trim()
                if (name.isNotEmpty()) {
                    categories.add(
                        BackupCategoryRecord(
                            id = obj.optString("id", "").ifBlank { "cat_imported_$i" },
                            name = name.take(32),
                            isDefault = obj.optBoolean("isDefault", false),
                            createdAtMillis = obj.optLong("createdAtMillis", exportedAt)
                        )
                    )
                }
            }

            val tasks = mutableListOf<BackupTaskRecord>()
            val taskArray = root.getJSONArray("tasks")
            for (i in 0 until taskArray.length()) {
                val obj = taskArray.getJSONObject(i)
                val title = obj.optString("title", "").trim()
                if (title.isEmpty()) {
                    throw IllegalArgumentException("${i + 1}. görev kaydında başlık eksik.")
                }
                val startDate = if (obj.isNull("startDateMillis")) null else obj.optLong("startDateMillis")
                val endDate = if (obj.isNull("endDateMillis")) null else obj.optLong("endDateMillis")
                val startTime = if (obj.isNull("startTimeMinutes")) null else obj.optInt("startTimeMinutes")
                val endTime = if (obj.isNull("endTimeMinutes")) null else obj.optInt("endTimeMinutes")

                tasks.add(
                    BackupTaskRecord(
                        title = title.take(120),
                        description = obj.optString("description", "").take(600),
                        note = obj.optString("note", "").take(500),
                        startDateMillis = startDate,
                        endDateMillis = endDate,
                        startTimeMinutes = startTime?.coerceIn(0, 23 * 60 + 59),
                        endTimeMinutes = endTime?.coerceIn(0, 23 * 60 + 59),
                        priority = TaskPriority.fromName(obj.optString("priority")),
                        categoryId = obj.optString("categoryId", "cat_diger").ifBlank { "cat_diger" },
                        categoryName = obj.optString("categoryName", "Diğer").ifBlank { "Diğer" },
                        status = TaskStatus.fromName(obj.optString("status")),
                        isFavorite = obj.optBoolean("isFavorite", false),
                        isArchived = obj.optBoolean("isArchived", false),
                        isDeleted = obj.optBoolean("isDeleted", false),
                        deletedAtMillis = if (obj.isNull("deletedAtMillis")) null else obj.optLong("deletedAtMillis"),
                        completedAtMillis = if (obj.isNull("completedAtMillis")) null else obj.optLong("completedAtMillis"),
                        createdAtMillis = obj.optLong("createdAtMillis", exportedAt),
                        updatedAtMillis = obj.optLong("updatedAtMillis", exportedAt),
                        reminderEnabled = obj.optBoolean("reminderEnabled", true),
                        reminderOffsetsMinutes = ReminderOffsetsCodec.decode(
                            obj.optString("reminderOffsetsCsv", "15")
                        ),
                        recurrence = TaskRecurrence.fromName(obj.optString("recurrence"))
                    )
                )
            }

            val existingSignatures = existingTasks.map(::taskDeduplicationSignature).toMutableSet()
            var newCount = 0
            var dupCount = 0
            tasks.forEach { rec ->
                val sig = taskDeduplicationSignature(rec)
                if (existingSignatures.add(sig)) {
                    newCount++
                } else {
                    dupCount++
                }
            }

            val trLocale = Locale.forLanguageTag("tr-TR")
            val existingCatNames = existingCategories.map { it.name.trim().lowercase(trLocale) }.toSet()
            val newCatsCount = categories.distinctBy { it.name.trim().lowercase(trLocale) }
                .count { it.name.trim().lowercase(trLocale) !in existingCatNames }

            BackupValidationPreview(
                document = BackupDocument(
                    schemaVersion = schemaVersion,
                    exportedAtMillis = exportedAt,
                    categories = categories,
                    tasks = tasks
                ),
                totalTasksInFile = tasks.size,
                newTasksToImportCount = newCount,
                duplicateTasksSkippedCount = dupCount,
                newCategoriesCount = newCatsCount
            )
        }
    }

    fun writeBackupToUri(context: Context, uri: Uri, jsonContent: String): Result<Unit> = runCatching {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(jsonContent.toByteArray(Charsets.UTF_8))
            out.flush()
        } ?: throw IllegalStateException("Dosya yazma akışı açılamadı.")
    }

    fun readBackupFromUri(context: Context, uri: Uri): Result<String> = runCatching {
        context.contentResolver.openInputStream(uri)?.use { input ->
            input.bufferedReader(Charsets.UTF_8).readText()
        } ?: throw IllegalStateException("Seçilen dosya okunamadı.")
    }

    fun saveInternalBackupSnapshot(context: Context, jsonContent: String): Result<File> = runCatching {
        val dir = File(context.filesDir, "backups").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val target = File(dir, "divam_yedek_$stamp.json")
        target.writeText(jsonContent, Charsets.UTF_8)
        target
    }

    fun listInternalBackupSnapshots(context: Context): List<File> {
        val dir = File(context.filesDir, "backups")
        if (!dir.exists()) return emptyList()
        return dir.listFiles { f -> f.isFile && f.extension.equals("json", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun defaultBackupFileName(): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())
        return "divamin_gorevi_yedek_$stamp.json"
    }
}
