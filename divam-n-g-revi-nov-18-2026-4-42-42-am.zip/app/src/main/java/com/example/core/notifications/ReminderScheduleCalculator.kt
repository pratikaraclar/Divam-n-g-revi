package com.example.core.notifications

import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import java.util.Calendar

data class PlannedReminderTrigger(
    val taskId: Long,
    val taskTitle: String,
    val offsetMinutes: Int,
    val occurrenceDayMillis: Long,
    val triggerAtMillis: Long,
    val requestCode: Int
)

data class DigestSummaryContent(
    val title: String,
    val message: String,
    val taskCount: Int
)

object ReminderScheduleCalculator {

    private const val MAX_RECURRENCE_SEARCH_STEPS = 400

    fun reminderRequestCode(taskId: Long, offsetMinutes: Int): Int {
        val raw = (taskId * 1009L + offsetMinutes.toLong() * 37L) xor (taskId shl 7)
        val positive = (raw.toInt() and 0x0FFFFFFF)
        return 100_000 + positive
    }

    fun isTaskEligibleForReminder(task: TaskItem): Boolean {
        if (task.isDeleted || task.isArchived) return false
        if (task.status == TaskStatus.COMPLETED || task.status == TaskStatus.CANCELLED) return false
        if (!task.reminderEnabled) return false
        if (task.startDateMillis == null || task.startTimeMinutes == null) return false
        return task.reminderOffsetsMinutes.isNotEmpty()
    }

    fun computeNextTrigger(
        task: TaskItem,
        offsetMinutes: Int,
        nowMillis: Long
    ): PlannedReminderTrigger? {
        if (!isTaskEligibleForReminder(task)) return null
        val baseDayMillis = task.startDateMillis ?: return null
        val startTimeMinutes = task.startTimeMinutes ?: return null
        val safeOffset = offsetMinutes.coerceAtLeast(0)

        var candidateDayMillis = baseDayMillis
        var step = 0

        if (task.recurrence == TaskRecurrence.WEEKDAYS) {
            candidateDayMillis = snapToWeekdayIfNeeded(candidateDayMillis)
        }

        while (step <= MAX_RECURRENCE_SEARCH_STEPS) {
            val eventStartMillis = TaskDateTimeUtils.combineLocalDayAndMinutes(
                localDayMillis = candidateDayMillis,
                minuteOfDay = startTimeMinutes
            )
            val triggerMillis = eventStartMillis - safeOffset * 60_000L
            if (triggerMillis > nowMillis) {
                return PlannedReminderTrigger(
                    taskId = task.id,
                    taskTitle = task.title,
                    offsetMinutes = safeOffset,
                    occurrenceDayMillis = candidateDayMillis,
                    triggerAtMillis = triggerMillis,
                    requestCode = reminderRequestCode(task.id, safeOffset)
                )
            }
            if (task.recurrence == TaskRecurrence.NONE) {
                return null
            }
            candidateDayMillis = advanceOccurrenceDay(candidateDayMillis, task.recurrence)
            step++
        }
        return null
    }

    private fun snapToWeekdayIfNeeded(dayMillis: Long): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = dayMillis }
        while (
            cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||
            cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
        ) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return TaskDateTimeUtils.localDayMillis(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun advanceOccurrenceDay(dayMillis: Long, recurrence: TaskRecurrence): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = dayMillis }
        when (recurrence) {
            TaskRecurrence.NONE -> Unit
            TaskRecurrence.DAILY -> cal.add(Calendar.DAY_OF_MONTH, 1)
            TaskRecurrence.WEEKDAYS -> {
                do {
                    cal.add(Calendar.DAY_OF_MONTH, 1)
                } while (
                    cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||
                    cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
                )
            }
            TaskRecurrence.WEEKLY -> cal.add(Calendar.WEEK_OF_YEAR, 1)
            TaskRecurrence.MONTHLY -> cal.add(Calendar.MONTH, 1)
        }
        return TaskDateTimeUtils.localDayMillis(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun computeNextDailyDigestTimeMillis(minuteOfDay: Int, nowMillis: Long): Long {
        val hour = (minuteOfDay / 60).coerceIn(0, 23)
        val minute = (minuteOfDay % 60).coerceIn(0, 59)
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= nowMillis) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return cal.timeInMillis
    }

    fun buildMorningSummaryContent(
        tasks: List<TaskItem>,
        todayDayMillis: Long
    ): DigestSummaryContent {
        val active = tasks.filter { !it.isDeleted && !it.isArchived && it.status != TaskStatus.CANCELLED }
        val todayIncomplete = active.filter { task ->
            task.status != TaskStatus.COMPLETED && TaskDateTimeUtils.isTaskOnDay(task, todayDayMillis)
        }
        val overdueCount = active.count { task ->
            task.status != TaskStatus.COMPLETED &&
                task.startDateMillis != null &&
                task.startDateMillis < todayDayMillis
        }
        val highCount = todayIncomplete.count { it.priority == TaskPriority.HIGH }

        return if (todayIncomplete.isEmpty() && overdueCount == 0) {
            DigestSummaryContent(
                title = "Günaydın • Divamın Görevi",
                message = "Bugün için bekleyen görev bulunmuyor. Dilerseniz gününüzü planlayabilirsiniz.",
                taskCount = 0
            )
        } else {
            val previewTitles = todayIncomplete.take(2).joinToString(", ") { it.title }
            val parts = buildList {
                if (todayIncomplete.isNotEmpty()) add("Bugün ${todayIncomplete.size} görev")
                if (highCount > 0) add("$highCount yüksek öncelikli")
                if (overdueCount > 0) add("$overdueCount gecikmiş")
            }
            val msg = buildString {
                append(parts.joinToString(" • "))
                if (previewTitles.isNotEmpty()) {
                    append(": ")
                    append(previewTitles)
                }
            }
            DigestSummaryContent(
                title = "Sabah Günlük Görev Özeti",
                message = msg,
                taskCount = todayIncomplete.size + overdueCount
            )
        }
    }

    fun buildEveningIncompleteContent(
        tasks: List<TaskItem>,
        todayDayMillis: Long
    ): DigestSummaryContent? {
        val activeIncomplete = tasks.filter { task ->
            !task.isDeleted &&
                !task.isArchived &&
                task.status != TaskStatus.COMPLETED &&
                task.status != TaskStatus.CANCELLED &&
                (task.startDateMillis == null || task.startDateMillis <= todayDayMillis)
        }
        if (activeIncomplete.isEmpty()) return null

        val topTitles = activeIncomplete.take(2).joinToString(", ") { it.title }
        return DigestSummaryContent(
            title = "Akşam Hatırlatması • ${activeIncomplete.size} Tamamlanmamış Görev",
            message = "Henüz tamamlanmamış görevleriniz: $topTitles",
            taskCount = activeIncomplete.size
        )
    }
}
