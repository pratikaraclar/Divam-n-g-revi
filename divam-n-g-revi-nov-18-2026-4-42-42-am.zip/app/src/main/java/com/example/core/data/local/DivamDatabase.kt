package com.example.core.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TaskEntity::class,
        CategoryEntity::class,
        ScheduledReminderEntity::class,
        NotificationHistoryEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class DivamDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        private const val DATABASE_NAME = "divamin_gorevi_db"

        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tasks ADD COLUMN reminderEnabled INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE tasks ADD COLUMN reminderOffsetsCsv TEXT NOT NULL DEFAULT '15'")
                db.execSQL("ALTER TABLE tasks ADD COLUMN recurrence TEXT NOT NULL DEFAULT 'NONE'")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS scheduled_reminders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        taskId INTEGER NOT NULL,
                        taskTitle TEXT NOT NULL,
                        offsetMinutes INTEGER NOT NULL,
                        occurrenceDayMillis INTEGER NOT NULL,
                        triggerAtMillis INTEGER NOT NULL,
                        requestCode INTEGER NOT NULL,
                        updatedAtMillis INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS index_scheduled_reminders_taskId_offsetMinutes ON scheduled_reminders (taskId, offsetMinutes)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_scheduled_reminders_triggerAtMillis ON scheduled_reminders (triggerAtMillis)"
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS notification_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        taskId INTEGER,
                        taskTitle TEXT NOT NULL,
                        title TEXT NOT NULL,
                        message TEXT NOT NULL,
                        type TEXT NOT NULL,
                        deliveryStatus TEXT NOT NULL,
                        offsetMinutes INTEGER,
                        triggeredAtMillis INTEGER NOT NULL,
                        dedupKey TEXT
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_notification_history_triggeredAtMillis ON notification_history (triggeredAtMillis)"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS index_notification_history_dedupKey ON notification_history (dedupKey)"
                )
            }
        }

        @Volatile
        private var INSTANCE: DivamDatabase? = null

        fun getInstance(context: Context): DivamDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DivamDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
