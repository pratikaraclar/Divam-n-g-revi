package com.example.core.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.core.model.ChannelSystemInspection
import com.example.core.model.EffectiveChannelBehavior
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationSettings

object NotificationChannelHelper {
    const val SILENT_CHANNEL_ID = "divam_silent_channel_v1"
    const val EXTRA_OPEN_ROUTE = "divam_open_route"
    const val EXTRA_OPEN_TASK_ID = "divam_open_task_id"

    private val DEFAULT_VIBRATION_PATTERN = longArrayOf(0L, 220L, 110L, 220L)

    fun activeChannelId(kind: NotificationChannelKind, version: Int): String =
        "${kind.baseId}_v${version.coerceAtLeast(1)}"

    fun ensureChannelsSynced(context: Context, settings: NotificationSettings) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        // Sessiz bildirim kanalı (sessiz saatler ve sessiz mod için)
        val silentChannel = NotificationChannel(
            SILENT_CHANNEL_ID,
            "Sessiz Bildirimler",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Sessiz saatlerde veya sessiz modda ses ve titreşimsiz gösterilen bildirimler"
            setSound(null, null)
            enableVibration(false)
            vibrationPattern = longArrayOf(0L)
        }
        manager.createNotificationChannel(silentChannel)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        NotificationChannelKind.entries.forEach { kind ->
            val currentId = activeChannelId(kind, settings.channelConfigVersion)
            val cfg = settings.channelConfigFor(kind)
            val soundEnabled = settings.soundEnabled && cfg.soundEnabled && !cfg.silentMode && !settings.silentNotificationMode
            val vibrationEnabled = settings.vibrationEnabled && cfg.vibrationEnabled && !cfg.silentMode && !settings.silentNotificationMode
            val soundUri = if (soundEnabled) {
                TaskSoundManager.resolveSoundUri(context, cfg.soundId)
            } else {
                null
            }

            // Eski yapılandırma sürümlerini temizle (ses değişikliğinin sonraki bildirimlere yansıması için)
            manager.notificationChannels
                .filter { existing ->
                    existing.id.startsWith("${kind.baseId}_v") && existing.id != currentId
                }
                .forEach { stale ->
                    runCatching { manager.deleteNotificationChannel(stale.id) }
                }

            val importance = when {
                cfg.silentMode || settings.silentNotificationMode || (!soundEnabled && !vibrationEnabled) ->
                    NotificationManager.IMPORTANCE_LOW
                kind == NotificationChannelKind.DAILY_DIGEST -> NotificationManager.IMPORTANCE_DEFAULT
                else -> NotificationManager.IMPORTANCE_HIGH
            }

            val channel = NotificationChannel(currentId, kind.turkishTitle, importance).apply {
                description = kind.turkishDescription
                if (soundUri != null) {
                    setSound(soundUri, audioAttributes)
                } else {
                    setSound(null, null)
                }
                enableVibration(vibrationEnabled)
                if (vibrationEnabled) {
                    vibrationPattern = DEFAULT_VIBRATION_PATTERN
                }
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun inspectSystemChannels(
        context: Context,
        settings: NotificationSettings
    ): List<ChannelSystemInspection> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return NotificationChannelKind.entries.map { kind ->
                ChannelSystemInspection(
                    kind = kind,
                    activeChannelId = activeChannelId(kind, settings.channelConfigVersion),
                    existsOnSystem = true,
                    blockedBySystem = !NotificationManagerCompat.from(context).areNotificationsEnabled(),
                    systemSoundMatchesSelected = true,
                    systemVibrationMatchesSelected = true
                )
            }
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return NotificationChannelKind.entries.map { kind ->
            val chId = activeChannelId(kind, settings.channelConfigVersion)
            val sysChannel = manager?.getNotificationChannel(chId)
            val cfg = settings.channelConfigFor(kind)
            val wantSound = settings.soundEnabled && cfg.soundEnabled && !cfg.silentMode && !settings.silentNotificationMode
            val wantSoundUri = if (wantSound) TaskSoundManager.resolveSoundUri(context, cfg.soundId) else null
            val wantVibration = settings.vibrationEnabled && cfg.vibrationEnabled && !cfg.silentMode && !settings.silentNotificationMode

            val soundMatches = if (sysChannel == null) {
                true
            } else if (!wantSound) {
                sysChannel.sound == null
            } else {
                sysChannel.sound?.toString() == wantSoundUri?.toString()
            }

            val vibrationMatches = if (sysChannel == null) {
                true
            } else {
                sysChannel.shouldVibrate() == wantVibration
            }

            ChannelSystemInspection(
                kind = kind,
                activeChannelId = chId,
                existsOnSystem = sysChannel != null,
                blockedBySystem = sysChannel?.importance == NotificationManager.IMPORTANCE_NONE,
                systemSoundMatchesSelected = soundMatches,
                systemVibrationMatchesSelected = vibrationMatches
            )
        }
    }

    fun hasPostNotificationPermission(context: Context): Boolean {
        val areEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        if (!areEnabled) return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        return alarmManager.canScheduleExactAlarms()
    }

    fun openAppNotificationSettings(context: Context) {
        val intent = Intent().apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            } else {
                action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                data = Uri.fromParts("package", context.packageName, null)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun openChannelNotificationSettings(context: Context, channelId: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (runCatching { context.startActivity(intent) }.isSuccess) {
                return
            }
        }
        openAppNotificationSettings(context)
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (runCatching { context.startActivity(intent) }.isSuccess) {
                return
            }
        }
        openAppNotificationSettings(context)
    }

    fun openBatteryOptimizationSettings(context: Context) {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    @SuppressLint("MissingPermission")
    fun postNotification(
        context: Context,
        notificationId: Int,
        title: String,
        message: String,
        settings: NotificationSettings,
        behavior: EffectiveChannelBehavior,
        taskId: Long? = null,
        openRoute: String? = null
    ): Boolean {
        if (!hasPostNotificationPermission(context)) return false
        ensureChannelsSynced(context, settings)

        val channelId = if (behavior.useSilentMode) {
            SILENT_CHANNEL_ID
        } else {
            activeChannelId(behavior.kind, settings.channelConfigVersion)
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (taskId != null && taskId > 0L) {
                putExtra(EXTRA_OPEN_TASK_ID, taskId)
            }
            if (openRoute != null) {
                putExtra(EXTRA_OPEN_ROUTE, openRoute)
            }
        }

        val contentPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)

        if (behavior.useSilentMode) {
            builder.setSilent(true)
            builder.setPriority(NotificationCompat.PRIORITY_LOW)
            builder.setSound(null)
            builder.setVibrate(longArrayOf(0L))
        } else {
            builder.setPriority(
                if (behavior.kind == NotificationChannelKind.DAILY_DIGEST) {
                    NotificationCompat.PRIORITY_DEFAULT
                } else {
                    NotificationCompat.PRIORITY_HIGH
                }
            )
            if (behavior.effectiveSoundEnabled) {
                TaskSoundManager.resolveSoundUri(context, behavior.effectiveSoundId)?.let { uri ->
                    builder.setSound(uri)
                }
            } else {
                builder.setSound(null)
            }
            if (behavior.effectiveVibrationEnabled) {
                builder.setVibrate(DEFAULT_VIBRATION_PATTERN)
            } else {
                builder.setVibrate(longArrayOf(0L))
            }
        }

        if (taskId != null && taskId > 0L && behavior.kind == NotificationChannelKind.TASK_REMINDERS) {
            val completeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_MARK_COMPLETED
                putExtra(NotificationActionReceiver.EXTRA_TASK_ID, taskId)
                putExtra(NotificationActionReceiver.EXTRA_NOTIFICATION_ID, notificationId)
            }
            val completePi = PendingIntent.getBroadcast(
                context,
                notificationId xor 0x3F3F,
                completeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(
                R.drawable.ic_launcher_foreground,
                "Tamamlandı",
                completePi
            )
        }

        return try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
            true
        } catch (_: SecurityException) {
            false
        }
    }
}
