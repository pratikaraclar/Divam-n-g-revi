package com.example.core.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.backup.BackupDocument
import com.example.core.backup.BackupRestoreSummary
import com.example.core.backup.BackupValidationPreview
import com.example.core.backup.TaskBackupManager
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.TaskRepository
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.data.preferences.ThemePreferencesRepository
import com.example.core.data.preferences.UserPreferencesRepository
import com.example.core.model.AppFontScale
import com.example.core.model.CardDisplayStyle
import com.example.core.model.DateFormatStyle
import com.example.core.model.TaskBoxFilter
import com.example.core.model.TaskPriority
import com.example.core.model.UserPreferences
import com.example.core.model.WeekStartDay
import com.example.core.notifications.AndroidTaskReminderScheduler
import com.example.core.notifications.NotificationChannelHelper
import com.example.core.security.AppSecurityHelper
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(
    private val appContext: Context,
    private val themePreferencesRepository: ThemePreferencesRepository,
    private val userPreferencesRepository: UserPreferencesRepository,
    private val notificationPreferencesRepository: NotificationPreferencesRepository,
    private val taskRepository: TaskRepository
) : ViewModel() {

    val themeMode: StateFlow<ThemeMode> = themePreferencesRepository.themeModeFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ThemeMode.DARK
        )

    val userPreferences: StateFlow<UserPreferences> = userPreferencesRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = UserPreferences()
        )

    private val _isSplashVisible = MutableStateFlow(true)
    val isSplashVisible: StateFlow<Boolean> = _isSplashVisible.asStateFlow()

    private val _isAppLocked = MutableStateFlow(false)
    val isAppLocked: StateFlow<Boolean> = _isAppLocked.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _localBackupFiles = MutableStateFlow<List<File>>(emptyList())
    val localBackupFiles: StateFlow<List<File>> = _localBackupFiles.asStateFlow()

    init {
        viewModelScope.launch {
            val prefs = userPreferencesRepository.getSnapshot()
            if (prefs.appLockEnabled && prefs.hasPinConfigured) {
                _isAppLocked.value = true
            }
            refreshLocalBackupSnapshots()
        }
    }

    fun dismissSplash() {
        _isSplashVisible.value = false
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            themePreferencesRepository.setThemeMode(mode)
        }
    }

    fun updateUserName(name: String) {
        val cleaned = name.trim()
        if (cleaned.isEmpty()) return
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(userName = cleaned.take(40)) }
            _messages.tryEmit("Kullanıcı adı güncellendi")
        }
    }

    fun saveAvatarFromUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val savedPath = runCatching {
                val targetFile = File(appContext.filesDir, "profile_avatar.jpg")
                appContext.contentResolver.openInputStream(uri)?.use { input ->
                    targetFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                } ?: throw IllegalStateException("Fotoğraf okunamadı")
                targetFile.absolutePath
            }.getOrNull()

            if (savedPath != null) {
                userPreferencesRepository.update { it.copy(avatarLocalPath = savedPath) }
                _messages.tryEmit("Profil fotoğrafı güncellendi")
            } else {
                _messages.tryEmit("Profil fotoğrafı kaydedilemedi")
            }
        }
    }

    fun removeAvatar() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                File(appContext.filesDir, "profile_avatar.jpg").delete()
            }
            userPreferencesRepository.update { it.copy(avatarLocalPath = null) }
            _messages.tryEmit("Profil fotoğrafı kaldırıldı")
        }
    }

    fun updateGoals(dailyGoal: Int, weeklyGoal: Int) {
        viewModelScope.launch {
            userPreferencesRepository.update {
                it.copy(
                    dailyTaskGoal = dailyGoal.coerceIn(1, 50),
                    weeklyTaskGoal = weeklyGoal.coerceIn(1, 300)
                )
            }
            _messages.tryEmit("Görev hedefleri kaydedildi")
        }
    }

    fun setGoldAccentsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(goldAccentsEnabled = enabled) }
        }
    }

    fun updateFontScale(scale: AppFontScale) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(fontScale = scale) }
        }
    }

    fun updateCardDisplayStyle(style: CardDisplayStyle) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(cardDisplayStyle = style) }
        }
    }

    fun setUse24HourFormat(use24Hour: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(use24HourFormat = use24Hour) }
        }
    }

    fun updateDateFormatStyle(style: DateFormatStyle) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(dateFormatStyle = style) }
        }
    }

    fun updateWeekStartDay(day: WeekStartDay) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(weekStartDay = day) }
        }
    }

    fun updateDefaultPriority(priority: TaskPriority) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(defaultPriority = priority) }
        }
    }

    fun updateDefaultCategoryId(categoryId: String) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(defaultCategoryId = categoryId) }
        }
    }

    fun updateDefaultTaskBoxFilter(boxFilter: TaskBoxFilter) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(defaultTaskBoxFilter = boxFilter) }
        }
    }

    fun setAutoArchiveCompleted(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(autoArchiveCompleted = enabled) }
        }
    }

    fun setShowOverdueOnHome(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(showOverdueOnHome = enabled) }
        }
    }

    fun setConfirmBeforeDelete(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(confirmBeforeDelete = enabled) }
        }
    }

    // --- Güvenlik (PIN & Biyometrik) ---
    fun setupOrUpdatePin(pin: String): Boolean {
        if (!AppSecurityHelper.isPinFormatValid(pin)) return false
        val salt = AppSecurityHelper.generateSalt()
        val hash = AppSecurityHelper.hashPin(pin, salt)
        viewModelScope.launch {
            userPreferencesRepository.update {
                it.copy(
                    appLockEnabled = true,
                    pinSalt = salt,
                    pinHash = hash
                )
            }
            _messages.tryEmit("PIN kilidi etkinleştirildi")
        }
        return true
    }

    fun disableAppLock() {
        viewModelScope.launch {
            userPreferencesRepository.update {
                it.copy(
                    appLockEnabled = false,
                    biometricEnabled = false,
                    pinSalt = null,
                    pinHash = null
                )
            }
            _isAppLocked.value = false
            _messages.tryEmit("Uygulama kilidi kapatıldı")
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.update { it.copy(biometricEnabled = enabled) }
        }
    }

    fun verifyPinAndUnlock(pin: String): Boolean {
        val prefs = userPreferences.value
        val valid = AppSecurityHelper.verifyPin(pin, prefs.pinSalt, prefs.pinHash)
        if (valid) {
            _isAppLocked.value = false
        }
        return valid
    }

    fun unlockViaBiometric() {
        _isAppLocked.value = false
    }

    fun lockNowIfEnabled() {
        val prefs = userPreferences.value
        if (prefs.appLockEnabled && prefs.hasPinConfigured) {
            _isAppLocked.value = true
        }
    }

    // --- Yedekleme ve Geri Yükleme ---
    suspend fun exportBackupToUri(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        val tasks = taskRepository.getAllTasksSync()
        val categories = taskRepository.categoriesFlow.first()
        val json = TaskBackupManager.serializeToJson(tasks, categories)
        TaskBackupManager.writeBackupToUri(appContext, uri, json).map { tasks.size }
    }

    fun createLocalBackupSnapshot() {
        viewModelScope.launch(Dispatchers.IO) {
            val tasks = taskRepository.getAllTasksSync()
            val categories = taskRepository.categoriesFlow.first()
            val json = TaskBackupManager.serializeToJson(tasks, categories)
            val result = TaskBackupManager.saveInternalBackupSnapshot(appContext, json)
            refreshLocalBackupSnapshots()
            if (result.isSuccess) {
                _messages.tryEmit("Yerel yedek dosyası oluşturuldu (${tasks.size} görev)")
            } else {
                _messages.tryEmit("Yedek dosyası oluşturulamadı")
            }
        }
    }

    suspend fun inspectBackupFromUri(uri: Uri): Result<BackupValidationPreview> =
        withContext(Dispatchers.IO) {
            val raw = TaskBackupManager.readBackupFromUri(appContext, uri).getOrElse {
                return@withContext Result.failure(it)
            }
            val existingTasks = taskRepository.getAllTasksSync()
            val existingCats = taskRepository.categoriesFlow.first()
            TaskBackupManager.parseAndValidate(raw, existingTasks, existingCats)
        }

    suspend fun inspectLocalBackupFile(file: File): Result<BackupValidationPreview> =
        withContext(Dispatchers.IO) {
            runCatching { file.readText(Charsets.UTF_8) }.fold(
                onSuccess = { raw ->
                    val existingTasks = taskRepository.getAllTasksSync()
                    val existingCats = taskRepository.categoriesFlow.first()
                    TaskBackupManager.parseAndValidate(raw, existingTasks, existingCats)
                },
                onFailure = { Result.failure(it) }
            )
        }

    fun confirmRestoreBackup(document: BackupDocument, onDone: (BackupRestoreSummary) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val summary = taskRepository.restoreFromBackup(document)
            withContext(Dispatchers.Main) {
                _messages.tryEmit(
                    "Geri yüklendi: ${summary.importedTasksCount} yeni görev (${summary.skippedDuplicatesCount} mükerrer atlandı)"
                )
                onDone(summary)
            }
        }
    }

    fun refreshLocalBackupSnapshots() {
        _localBackupFiles.value = TaskBackupManager.listInternalBackupSnapshots(appContext)
    }

    // --- Sıfırlama ve Kişisel Veri Silme ---
    fun resetNotificationSettingsOnly() {
        viewModelScope.launch(Dispatchers.IO) {
            notificationPreferencesRepository.updateSettings {
                com.example.core.model.NotificationSettings(
                    channelConfigVersion = it.channelConfigVersion + 1
                )
            }
            val snap = notificationPreferencesRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            AndroidTaskReminderScheduler.create(appContext).syncAll()
            _messages.tryEmit("Bildirim ayarları varsayılana sıfırlandı")
        }
    }

    fun resetAppearanceSettingsOnly() {
        viewModelScope.launch {
            themePreferencesRepository.setThemeMode(ThemeMode.DARK)
            userPreferencesRepository.resetAppearanceSettings()
            _messages.tryEmit("Görünüm ayarları varsayılana sıfırlandı")
        }
    }

    fun resetAllPreferences() {
        viewModelScope.launch(Dispatchers.IO) {
            themePreferencesRepository.setThemeMode(ThemeMode.DARK)
            userPreferencesRepository.resetAllPreferences(keepAvatar = false)
            notificationPreferencesRepository.updateSettings {
                com.example.core.model.NotificationSettings(
                    channelConfigVersion = it.channelConfigVersion + 1
                )
            }
            runCatching { File(appContext.filesDir, "profile_avatar.jpg").delete() }
            val snap = notificationPreferencesRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            AndroidTaskReminderScheduler.create(appContext).syncAll()
            _isAppLocked.value = false
            _messages.tryEmit("Bütün uygulama tercihleri varsayılana döndürüldü")
        }
    }

    fun deleteAllPersonalData() {
        viewModelScope.launch(Dispatchers.IO) {
            taskRepository.deleteAllUserData()
            runCatching { File(appContext.filesDir, "profile_avatar.jpg").delete() }
            runCatching { File(appContext.filesDir, "backups").deleteRecursively() }
            userPreferencesRepository.update {
                it.copy(
                    userName = "Divam Kullanıcısı",
                    avatarLocalPath = null
                )
            }
            refreshLocalBackupSnapshots()
            _messages.tryEmit("Tüm görevler, bildirim kayıtları ve profil verileri silindi")
        }
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
                val appCtx = context.applicationContext
                val db = DivamDatabase.getInstance(appCtx)
                val notifPrefs = NotificationPreferencesRepository(appCtx)
                val scheduler = AndroidTaskReminderScheduler.create(appCtx)
                return AppViewModel(
                    appContext = appCtx,
                    themePreferencesRepository = ThemePreferencesRepository(appCtx),
                    userPreferencesRepository = UserPreferencesRepository(appCtx),
                    notificationPreferencesRepository = notifPrefs,
                    taskRepository = TaskRepository(
                        taskDao = db.taskDao(),
                        notificationDao = db.notificationDao(),
                        reminderScheduler = scheduler
                    )
                ) as T
            }
            throw IllegalArgumentException("Bilinmeyen ViewModel sınıfı: ${modelClass.name}")
        }
    }
}
