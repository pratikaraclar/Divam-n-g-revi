package com.example.core.model

import androidx.compose.runtime.Immutable

enum class AppFontScale(val turkishLabel: String, val multiplier: Float) {
    COMPACT("Küçük (%92)", 0.92f),
    NORMAL("Standart (%100)", 1.0f),
    LARGE("Büyük (%112)", 1.12f),
    EXTRA_LARGE("Çok Büyük (%124)", 1.24f);

    companion object {
        fun fromName(name: String?): AppFontScale =
            entries.firstOrNull { it.name == name } ?: NORMAL
    }
}

enum class CardDisplayStyle(val turkishLabel: String, val description: String) {
    COMFORTABLE("Rahat", "Dengeli boşluklar ve okunaklı detaylar"),
    COMPACT("Kompakt", "Tek ekranda daha fazla görev sığdırır"),
    DETAILED("Ayrıntılı", "Özel not ve tüm etiketleri vurgular");

    companion object {
        fun fromName(name: String?): CardDisplayStyle =
            entries.firstOrNull { it.name == name } ?: COMFORTABLE
    }
}

enum class DateFormatStyle(val turkishLabel: String, val pattern: String, val example: String) {
    SHORT_MONTH("17 Kas 2026", "d MMM yyyy", "17 Kas 2026"),
    NUMERIC_DOT("17.11.2026", "dd.MM.yyyy", "17.11.2026"),
    FULL_MONTH("17 Kasım 2026", "d MMMM yyyy", "17 Kasım 2026");

    companion object {
        fun fromName(name: String?): DateFormatStyle =
            entries.firstOrNull { it.name == name } ?: SHORT_MONTH
    }
}

enum class WeekStartDay(val turkishLabel: String, val calendarConstant: Int) {
    MONDAY("Pazartesi", java.util.Calendar.MONDAY),
    SUNDAY("Pazar", java.util.Calendar.SUNDAY);

    companion object {
        fun fromName(name: String?): WeekStartDay =
            entries.firstOrNull { it.name == name } ?: MONDAY
    }
}

@Immutable
data class UserPreferences(
    val userName: String = "Divam Kullanıcısı",
    val avatarLocalPath: String? = null,
    val dailyTaskGoal: Int = 5,
    val weeklyTaskGoal: Int = 25,
    val goldAccentsEnabled: Boolean = true,
    val fontScale: AppFontScale = AppFontScale.NORMAL,
    val cardDisplayStyle: CardDisplayStyle = CardDisplayStyle.COMFORTABLE,
    val use24HourFormat: Boolean = true,
    val dateFormatStyle: DateFormatStyle = DateFormatStyle.SHORT_MONTH,
    val weekStartDay: WeekStartDay = WeekStartDay.MONDAY,
    val defaultPriority: TaskPriority = TaskPriority.NORMAL,
    val defaultCategoryId: String = "cat_is",
    val defaultTaskBoxFilter: TaskBoxFilter = TaskBoxFilter.ACTIVE,
    val autoArchiveCompleted: Boolean = false,
    val showOverdueOnHome: Boolean = true,
    val confirmBeforeDelete: Boolean = true,
    val appLockEnabled: Boolean = false,
    val biometricEnabled: Boolean = false,
    val pinSalt: String? = null,
    val pinHash: String? = null
) {
    val hasPinConfigured: Boolean
        get() = !pinSalt.isNullOrBlank() && !pinHash.isNullOrBlank()
}
