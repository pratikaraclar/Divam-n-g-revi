package com.example.core.navigation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.core.designsystem.components.DivamLogoMark
import com.example.core.designsystem.components.DivamLuxuryBackground
import com.example.core.model.WindowWidthClass
import com.example.core.viewmodel.AppViewModel
import com.example.feature.calendar.CalendarScreen
import com.example.feature.home.HomeScreen
import com.example.feature.notifications.NotificationViewModel
import com.example.feature.notifications.NotificationsScreen
import com.example.feature.profile.ProfileScreen
import com.example.feature.security.AppLockScreen
import com.example.feature.settings.SettingsScreen
import com.example.feature.splash.SplashScreen
import com.example.feature.stats.StatsScreen
import com.example.feature.tasks.TaskEditorScreen
import com.example.feature.tasks.TaskViewModel
import com.example.feature.tasks.TasksScreen
import com.example.ui.theme.DivamTheme
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.launch

@Composable
fun DivamAppShell(
    appViewModel: AppViewModel,
    taskViewModel: TaskViewModel,
    notificationViewModel: NotificationViewModel,
    pendingLaunchRoute: String?,
    pendingLaunchTaskId: Long,
    onConsumePendingLaunch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val themeMode by appViewModel.themeMode.collectAsStateWithLifecycle()
    val userPreferences by appViewModel.userPreferences.collectAsStateWithLifecycle()
    val isSplashVisible by appViewModel.isSplashVisible.collectAsStateWithLifecycle()
    val isAppLocked by appViewModel.isAppLocked.collectAsStateWithLifecycle()

    val screenPhase = when {
        isSplashVisible -> 0
        isAppLocked -> 1
        else -> 2
    }

    AnimatedContent(
        targetState = screenPhase,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "splash_lock_main_transition",
        modifier = modifier.fillMaxSize()
    ) { phase ->
        when (phase) {
            0 -> SplashScreen(onSplashFinished = appViewModel::dismissSplash)
            1 -> AppLockScreen(
                biometricEnabled = userPreferences.biometricEnabled,
                onVerifyPin = appViewModel::verifyPinAndUnlock,
                onBiometricUnlocked = appViewModel::unlockViaBiometric
            )
            else -> MainAdaptiveNavigationShell(
                themeMode = themeMode,
                appViewModel = appViewModel,
                taskViewModel = taskViewModel,
                notificationViewModel = notificationViewModel,
                pendingLaunchRoute = pendingLaunchRoute,
                pendingLaunchTaskId = pendingLaunchTaskId,
                onConsumePendingLaunch = onConsumePendingLaunch
            )
        }
    }
}

@Composable
private fun MainAdaptiveNavigationShell(
    themeMode: ThemeMode,
    appViewModel: AppViewModel,
    taskViewModel: TaskViewModel,
    notificationViewModel: NotificationViewModel,
    pendingLaunchRoute: String?,
    pendingLaunchTaskId: Long,
    onConsumePendingLaunch: () -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val isTopLevelRoute = TopLevelDestination.fromRoute(currentRoute) != null

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(taskViewModel, notificationViewModel, appViewModel) {
        launch {
            taskViewModel.snackbarMessages.collect { message ->
                snackbarHostState.showSnackbar(message)
            }
        }
        launch {
            notificationViewModel.messages.collect { message ->
                snackbarHostState.showSnackbar(message)
            }
        }
        launch {
            appViewModel.messages.collect { message ->
                snackbarHostState.showSnackbar(message)
            }
        }
    }

    val navigateToRoute: (String) -> Unit = { route ->
        if (
            route == AppRoutes.SETTINGS ||
            route == AppRoutes.NOTIFICATIONS ||
            route.startsWith(AppRoutes.TASK_EDITOR_BASE)
        ) {
            navController.navigate(route) {
                launchSingleTop = true
            }
        } else {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    LaunchedEffect(pendingLaunchRoute, pendingLaunchTaskId) {
        if (pendingLaunchTaskId > 0L) {
            navController.navigate(AppRoutes.taskEditorRoute(taskId = pendingLaunchTaskId)) {
                launchSingleTop = true
            }
            onConsumePendingLaunch()
        } else if (!pendingLaunchRoute.isNullOrBlank()) {
            navigateToRoute(pendingLaunchRoute)
            onConsumePendingLaunch()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val widthClass = WindowWidthClass.fromWidth(maxWidth)
        val useNavigationRail = widthClass.isTabletOrWide

        DivamLuxuryBackground {
            if (useNavigationRail) {
                Scaffold(
                    containerColor = Color.Transparent,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
                ) { _ ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        if (isTopLevelRoute) {
                            DivamNavigationRail(
                                currentRoute = currentRoute,
                                onNavigate = navigateToRoute
                            )
                            VerticalDivider(
                                thickness = 1.dp,
                                color = DivamTheme.extendedColors.cardBorderSubtle
                            )
                        }
                        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                            DivamNavHost(
                                navController = navController,
                                widthClass = widthClass,
                                themeMode = themeMode,
                                appViewModel = appViewModel,
                                taskViewModel = taskViewModel,
                                notificationViewModel = notificationViewModel,
                                onNavigateToRoute = navigateToRoute
                            )
                        }
                    }
                }
            } else {
                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets.statusBars,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    bottomBar = {
                        if (isTopLevelRoute) {
                            DivamBottomNavigationBar(
                                currentRoute = currentRoute,
                                onNavigate = navigateToRoute
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .then(
                                if (!isTopLevelRoute) {
                                    Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                                } else {
                                    Modifier
                                }
                            )
                    ) {
                        DivamNavHost(
                            navController = navController,
                            widthClass = widthClass,
                            themeMode = themeMode,
                            appViewModel = appViewModel,
                            taskViewModel = taskViewModel,
                            notificationViewModel = notificationViewModel,
                            onNavigateToRoute = navigateToRoute
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DivamNavHost(
    navController: NavHostController,
    widthClass: WindowWidthClass,
    themeMode: ThemeMode,
    appViewModel: AppViewModel,
    taskViewModel: TaskViewModel,
    notificationViewModel: NotificationViewModel,
    onNavigateToRoute: (String) -> Unit
) {
    val allTasks by taskViewModel.allTasks.collectAsStateWithLifecycle()
    val categories by taskViewModel.categories.collectAsStateWithLifecycle()
    val boxCounts by taskViewModel.boxCounts.collectAsStateWithLifecycle()
    val userPreferences by appViewModel.userPreferences.collectAsStateWithLifecycle()
    val scheduledReminders by notificationViewModel.scheduledReminders.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = AppRoutes.HOME
    ) {
        composable(AppRoutes.HOME) {
            HomeScreen(
                widthClass = widthClass,
                themeMode = themeMode,
                userPreferences = userPreferences,
                tasks = allTasks,
                boxCounts = boxCounts,
                scheduledRemindersCount = scheduledReminders.size,
                onCreateNewTask = {
                    navController.navigate(AppRoutes.taskEditorRoute())
                },
                onNavigateToRoute = onNavigateToRoute,
                onEditTask = { id ->
                    navController.navigate(AppRoutes.taskEditorRoute(taskId = id))
                }
            )
        }
        composable(AppRoutes.TASKS) {
            TasksScreen(
                widthClass = widthClass,
                taskViewModel = taskViewModel,
                onCreateNewTask = {
                    navController.navigate(AppRoutes.taskEditorRoute())
                },
                onEditTask = { id ->
                    navController.navigate(AppRoutes.taskEditorRoute(taskId = id))
                }
            )
        }
        composable(AppRoutes.CALENDAR) {
            CalendarScreen(
                widthClass = widthClass,
                tasks = allTasks,
                categories = categories,
                onToggleTaskComplete = taskViewModel::toggleCompleted,
                onOpenTaskEditor = { id ->
                    navController.navigate(AppRoutes.taskEditorRoute(taskId = id))
                },
                onCreateTaskForDate = { dayMillis ->
                    navController.navigate(AppRoutes.taskEditorRoute(initialDateMillis = dayMillis))
                },
                onRescheduleTask = taskViewModel::rescheduleTask
            )
        }
        composable(AppRoutes.STATS) {
            StatsScreen(
                widthClass = widthClass,
                tasks = allTasks,
                categories = categories,
                userPreferences = userPreferences
            )
        }
        composable(AppRoutes.PROFILE) {
            ProfileScreen(
                widthClass = widthClass,
                themeMode = themeMode,
                userPreferences = userPreferences,
                tasks = allTasks,
                onOpenSettings = {
                    navController.navigate(AppRoutes.SETTINGS) {
                        launchSingleTop = true
                    }
                },
                onOpenNotifications = {
                    navController.navigate(AppRoutes.NOTIFICATIONS) {
                        launchSingleTop = true
                    }
                },
                onUpdateUserName = appViewModel::updateUserName,
                onSaveAvatarUri = appViewModel::saveAvatarFromUri,
                onRemoveAvatar = appViewModel::removeAvatar,
                onUpdateGoals = appViewModel::updateGoals,
                onDeleteAllPersonalData = appViewModel::deleteAllPersonalData
            )
        }
        composable(AppRoutes.SETTINGS) {
            SettingsScreen(
                widthClass = widthClass,
                themeMode = themeMode,
                categories = categories,
                appViewModel = appViewModel,
                onOpenNotifications = {
                    navController.navigate(AppRoutes.NOTIFICATIONS) {
                        launchSingleTop = true
                    }
                },
                onBack = { navController.navigateUp() }
            )
        }
        composable(AppRoutes.NOTIFICATIONS) {
            NotificationsScreen(
                widthClass = widthClass,
                notificationViewModel = notificationViewModel,
                onBack = { navController.navigateUp() }
            )
        }
        composable(
            route = AppRoutes.TASK_EDITOR_PATTERN,
            arguments = listOf(
                navArgument(AppRoutes.ARG_TASK_ID) {
                    type = NavType.LongType
                    defaultValue = -1L
                },
                navArgument(AppRoutes.ARG_INITIAL_DATE) {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { entry ->
            val taskId = entry.arguments?.getLong(AppRoutes.ARG_TASK_ID) ?: -1L
            val initialDate = entry.arguments?.getLong(AppRoutes.ARG_INITIAL_DATE) ?: -1L
            TaskEditorScreen(
                taskId = taskId,
                initialDateMillis = initialDate,
                widthClass = widthClass,
                taskViewModel = taskViewModel,
                onBack = { navController.navigateUp() }
            )
        }
    }
}

@Composable
private fun DivamBottomNavigationBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    val extended = DivamTheme.extendedColors

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(extended.navBarSurface)
    ) {
        HorizontalDivider(
            thickness = 1.dp,
            color = extended.cardBorderGold.copy(alpha = 0.35f)
        )
        NavigationBar(
            containerColor = extended.navBarSurface,
            tonalElevation = 0.dp,
            windowInsets = WindowInsets.navigationBars,
            modifier = Modifier.testTag("bottom_navigation_bar")
        ) {
            TopLevelDestination.entries.forEach { destination ->
                val selected = currentRoute == destination.route
                NavigationBarItem(
                    selected = selected,
                    onClick = { onNavigate(destination.route) },
                    modifier = Modifier.testTag(destination.testTag),
                    icon = {
                        Icon(
                            imageVector = if (selected) {
                                destination.selectedIcon
                            } else {
                                destination.unselectedIcon
                            },
                            contentDescription = destination.label
                        )
                    },
                    label = {
                        Text(
                            text = destination.label,
                            fontSize = 10.5.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    alwaysShowLabel = true,
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = extended.goldMid,
                        selectedTextColor = extended.goldMid,
                        indicatorColor = extended.navIndicatorFill,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }
    }
}

@Composable
private fun DivamNavigationRail(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    val extended = DivamTheme.extendedColors

    NavigationRail(
        containerColor = extended.navBarSurface,
        modifier = Modifier
            .fillMaxHeight()
            .testTag("tablet_navigation_rail"),
        header = {
            Spacer(modifier = Modifier.height(12.dp))
            DivamLogoMark(size = 44.dp)
            Spacer(modifier = Modifier.height(12.dp))
        }
    ) {
        TopLevelDestination.entries.forEach { destination ->
            val selected = currentRoute == destination.route
            NavigationRailItem(
                selected = selected,
                onClick = { onNavigate(destination.route) },
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .testTag(destination.testTag),
                icon = {
                    Icon(
                        imageVector = if (selected) {
                            destination.selectedIcon
                        } else {
                            destination.unselectedIcon
                        },
                        contentDescription = destination.label
                    )
                },
                label = {
                    Text(
                        text = destination.label,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                alwaysShowLabel = true,
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = extended.goldMid,
                    selectedTextColor = extended.goldMid,
                    indicatorColor = extended.navIndicatorFill,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}
