package com.example.core.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.AlarmManagerCompat
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.NotificationDao
import com.example.core.data.local.NotificationHistoryEntity
import com.example.core.data.local.ScheduledReminderEntity
import com.example.core.data.local.TaskDao
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationDeliveryStatus
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationType
import com.example.core.model.TaskDateTimeUtils

interface ReminderSchedulerHook {
    suspend fun onTaskChanged(taskId: Long)
    suspend fun onTaskRemoved(taskId: Long)
    suspend fun syncAll()
    suspend fun syncDailyDigests()
}

class AndroidTaskReminderScheduler(
    private val context: Context,
    private val taskDao: TaskDao,
    private val notificationDao: NotificationDao,
    private val prefsRepository: NotificationPreferencesRepository
) : ReminderSchedulerHook {

    private val appContext = context.applicationContext
    private val alarmManager: AlarmManager?
        get() = appContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    override suspend fun onTaskChanged(taskId: Long) {
        val settings = prefsRepository.getSettingsSnapshot()
        NotificationChannelHelper.ensureChannelsSynced(appContext, settings)
        syncTaskInternal(taskId, settings)
    }

    override suspend fun onTaskRemoved(taskId: Long) {
        cancelTaskAlarmsOnly(taskId)
        notificationDao.deleteScheduledRemindersForTask(taskId)
    }

    override suspend fun syncAll() {
        val settings = prefsRepository.getSettingsSnapshot()
        NotificationChannelHelper.ensureChannelsSynced(appContext, settings)

        val existingScheduled = notificationDao.getAllScheduledRemindersSync()
        val allTasks = taskDao.getAllTasksSync().map { it.toDomain() }
        val activeIds = allTasks.map { it.id }.toSet()

        // Veritabanında artık olmayan görevlerin alarmlarını temizle
        existingScheduled
            .filter { it.taskId !in activeIds }
            .forEach { stale ->
                cancelAlarmPendingIntent(
                    TaskReminderReceiver.buildIntent(
                        context = appContext,
                        taskId = stale.taskId,
                        offsetMinutes = stale.offsetMinutes,
                        occurrenceDayMillis = stale.occurrenceDayMillis
                    ),
                    stale.requestCode
                )
            }

        allTasks.forEach { task ->
            syncTaskInternal(task.id, settings)
        }
        syncDailyDigestsInternal(settings)
    }

    override suspend fun syncDailyDigests() {
        val settings = prefsRepository.getSettingsSnapshot()
        NotificationChannelHelper.ensureChannelsSynced(appContext, settings)
        syncDailyDigestsInternal(settings)
    }

    private suspend fun syncTaskInternal(taskId: Long, settings: NotificationSettings) {
        cancelTaskAlarmsOnly(taskId)
        notificationDao.deleteScheduledRemindersForTask(taskId)

        if (!settings.notificationsEnabled) return
        val task = taskDao.getTaskById(taskId)?.toDomain() ?: return
        if (!ReminderScheduleCalculator.isTaskEligibleForReminder(task)) return

        val now = System.currentTimeMillis()
        task.reminderOffsetsMinutes.distinct().forEach { offset ->
            val planned = ReminderScheduleCalculator.computeNextTrigger(
                task = task,
                offsetMinutes = offset,
                nowMillis = now
            )
            if (planned != null) {
                val intent = TaskReminderReceiver.buildIntent(
                    context = appContext,
                    taskId = planned.taskId,
                    offsetMinutes = planned.offsetMinutes,
                    occurrenceDayMillis = planned.occurrenceDayMillis
                )
                scheduleAlarmExactOrFallback(planned.requestCode, intent, planned.triggerAtMillis)
                notificationDao.upsertScheduledReminder(
                    ScheduledReminderEntity(
                        taskId = planned.taskId,
                        taskTitle = planned.taskTitle,
                        offsetMinutes = planned.offsetMinutes,
                        occurrenceDayMillis = planned.occurrenceDayMillis,
                        triggerAtMillis = planned.triggerAtMillis,
                        requestCode = planned.requestCode,
                        updatedAtMillis = now
                    )
                )
            }
        }
    }

    private suspend fun cancelTaskAlarmsOnly(taskId: Long) {
        val scheduled = notificationDao.getScheduledRemindersForTaskSync(taskId)
        scheduled.forEach { item ->
            cancelAlarmPendingIntent(
                TaskReminderReceiver.buildIntent(
                    context = appContext,
                    taskId = item.taskId,
                    offsetMinutes = item.offsetMinutes,
                    occurrenceDayMillis = item.occurrenceDayMillis
                ),
                item.requestCode
            )
        }
        NotificationSettings.PRESET_OFFSETS_MINUTES.forEach { presetOffset ->
            val code = ReminderScheduleCalculator.reminderRequestCode(taskId, presetOffset)
            cancelAlarmPendingIntent(
                TaskReminderReceiver.buildIntent(
                    context = appContext,
                    taskId = taskId,
                    offsetMinutes = presetOffset,
                    occurrenceDayMillis = 0L
                ),
                code
            )
        }
    }

    private fun syncDailyDigestsInternal(settings: NotificationSettings) {
        val now = System.currentTimeMillis()

        val morningIntent = DailyDigestReceiver.buildIntent(
            context = appContext,
            kind = DailyDigestReceiver.KIND_MORNING_SUMMARY
        )
        cancelAlarmPendingIntent(morningIntent, DailyDigestReceiver.REQUEST_CODE_MORNING)
        if (settings.notificationsEnabled && settings.morningSummaryEnabled) {
            val triggerAt = ReminderScheduleCalculator.computeNextDailyDigestTimeMillis(
                minuteOfDay = settings.morningSummaryMinutes,
                nowMillis = now
            )
            scheduleAlarmExactOrFallback(
                DailyDigestReceiver.REQUEST_CODE_MORNING,
                morningIntent,
                triggerAt
            )
        }

        val eveningIntent = DailyDigestReceiver.buildIntent(
            context = appContext,
            kind = DailyDigestReceiver.KIND_EVENING_INCOMPLETE
        )
        cancelAlarmPendingIntent(eveningIntent, DailyDigestReceiver.REQUEST_CODE_EVENING)
        if (settings.notificationsEnabled && settings.eveningIncompleteEnabled) {
            val triggerAt = ReminderScheduleCalculator.computeNextDailyDigestTimeMillis(
                minuteOfDay = settings.eveningIncompleteMinutes,
                nowMillis = now
            )
            scheduleAlarmExactOrFallback(
                DailyDigestReceiver.REQUEST_CODE_EVENING,
                eveningIntent,
                triggerAt
            )
        }
    }

    private fun scheduleAlarmExactOrFallback(
        requestCode: Int,
        intent: Intent,
        triggerAtMillis: Long
    ) {
        val manager = alarmManager ?: return
        val pi = PendingIntent.getBroadcast(
            appContext,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (NotificationChannelHelper.canScheduleExactAlarms(appContext)) {
            runCatching {
                AlarmManagerCompat.setExactAndAllowWhileIdle(
                    manager,
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pi
                )
            }.onFailure {
                AlarmManagerCompat.setAndAllowWhileIdle(
                    manager,
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pi
                )
            }
        } else {
            AlarmManagerCompat.setAndAllowWhileIdle(
                manager,
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pi
            )
        }
    }

    private fun cancelAlarmPendingIntent(intent: Intent, requestCode: Int) {
        val manager = alarmManager ?: return
        val existing = PendingIntent.getBroadcast(
            appContext,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (existing != null) {
            manager.cancel(existing)
            existing.cancel()
        }
    }

    suspend fun sendTestNotificationNow(
        channelKind: NotificationChannelKind = NotificationChannelKind.TEST_ALERTS,
        respectQuietHours: Boolean = false
    ): NotificationDeliveryStatus {
        val settings = prefsRepository.getSettingsSnapshot()
        NotificationChannelHelper.ensureChannelsSynced(appContext, settings)
        val now = System.currentTimeMillis()
        val behavior = settings.resolveBehavior(
            kind = channelKind,
            atEpochMillis = now,
            respectQuietHours = respectQuietHours
        )

        val title = "Divamın Görevi • Bildirim Testi"
        val channelLabel = channelKind.turkishTitle
        val modeSummary = when {
            behavior.suppressCompletely -> "Sessiz saatlerde engellendi"
            behavior.useSilentMode -> "Sessiz modda teslim edildi"
            behavior.effectiveSoundEnabled && behavior.effectiveVibrationEnabled -> "Sesli ve titreşimli"
            behavior.effectiveSoundEnabled -> "Sesli (titreşimsiz)"
            behavior.effectiveVibrationEnabled -> "Titreşimli (sessiz)"
            else -> "Sessiz teslimat"
        }
        val message = "$channelLabel kanalı test edildi • $modeSummary (${TaskDateTimeUtils.formatDateTimeTurkish(now)})"

        val status = when {
            !NotificationChannelHelper.hasPostNotificationPermission(appContext) ->
                NotificationDeliveryStatus.SKIPPED_NO_PERMISSION
            behavior.suppressCompletely ->
                NotificationDeliveryStatus.SUPPRESSED_QUIET_HOURS
            else -> {
                val posted = NotificationChannelHelper.postNotification(
                    context = appContext,
                    notificationId = TEST_NOTIFICATION_ID_BASE + (now % 1000).toInt(),
                    title = title,
                    message = message,
                    settings = settings,
                    behavior = behavior
                )
                if (!posted) {
                    NotificationDeliveryStatus.SKIPPED_NO_PERMISSION
                } else if (behavior.useSilentMode) {
                    NotificationDeliveryStatus.SENT_SILENT
                } else {
                    NotificationDeliveryStatus.SENT
                }
            }
        }

        notificationDao.insertNotificationHistory(
            NotificationHistoryEntity(
                taskId = null,
                taskTitle = channelLabel,
                title = title,
                message = message,
                type = NotificationType.TEST.name,
                deliveryStatus = status.name,
                offsetMinutes = null,
                triggeredAtMillis = now,
                dedupKey = null
            )
        )
        return status
    }

    companion object {
        private const val TEST_NOTIFICATION_ID_BASE = 880_000

        fun create(context: Context): AndroidTaskReminderScheduler {
            val db = DivamDatabase.getInstance(context.applicationContext)
            return AndroidTaskReminderScheduler(
                context = context.applicationContext,
                taskDao = db.taskDao(),
                notificationDao = db.notificationDao(),
                prefsRepository = NotificationPreferencesRepository(context.applicationContext)
            )
        }
    }
}
