package com.example.core.model

import androidx.compose.runtime.Immutable
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class TaskPriority(val turkishLabel: String, val sortWeight: Int) {
    LOW("Düşük", 1),
    NORMAL("Normal", 2),
    HIGH("Yüksek", 3);

    companion object {
        fun fromName(name: String?): TaskPriority =
            entries.firstOrNull { it.name == name } ?: NORMAL
    }
}

enum class TaskStatus(val turkishLabel: String) {
    PENDING("Bekliyor"),
    IN_PROGRESS("Devam Ediyor"),
    COMPLETED("Tamamlandı"),
    POSTPONED("Ertelendi"),
    CANCELLED("İptal Edildi");

    companion object {
        fun fromName(name: String?): TaskStatus =
            entries.firstOrNull { it.name == name } ?: PENDING
    }
}

enum class TaskSortOption(val turkishLabel: String) {
    DATE_ASC("Tarih (Yakından Uzağa)"),
    DATE_DESC("Tarih (Uzaktan Yakına)"),
    PRIORITY_DESC("Öncelik (Yüksekten Düşüğe)"),
    PRIORITY_ASC("Öncelik (Düşükten Yükseğe)"),
    CREATED_DESC("En Yeni Eklenen")
}

enum class TaskBoxFilter(val turkishLabel: String) {
    ACTIVE("Aktif"),
    FAVORITES("Favoriler"),
    ARCHIVED("Arşiv"),
    TRASH("Çöp Kutusu")
}

enum class TaskRecurrence(val turkishLabel: String) {
    NONE("Tek Seferlik"),
    DAILY("Her Gün"),
    WEEKDAYS("Hafta İçi"),
    WEEKLY("Her Hafta"),
    MONTHLY("Her Ay");

    companion object {
        fun fromName(name: String?): TaskRecurrence =
            entries.firstOrNull { it.name == name } ?: NONE
    }
}

@Immutable
data class TaskCategory(
    val id: String,
    val name: String,
    val isDefault: Boolean,
    val createdAtMillis: Long
)

@Immutable
data class TaskItem(
    val id: Long,
    val title: String,
    val description: String,
    val note: String,
    val startDateMillis: Long?,
    val endDateMillis: Long?,
    val startTimeMinutes: Int?,
    val endTimeMinutes: Int?,
    val priority: TaskPriority,
    val categoryId: String,
    val categoryName: String,
    val status: TaskStatus,
    val isFavorite: Boolean,
    val isArchived: Boolean,
    val isDeleted: Boolean,
    val deletedAtMillis: Long?,
    val completedAtMillis: Long?,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val reminderEnabled: Boolean = true,
    val reminderOffsetsMinutes: List<Int> = listOf(15),
    val recurrence: TaskRecurrence = TaskRecurrence.NONE
)

object TaskDateTimeUtils {
    private val trLocale: Locale = Locale.forLanguageTag("tr-TR")

    fun formatDateTurkish(
        localDayMillis: Long,
        style: DateFormatStyle = DateFormatStyle.SHORT_MONTH
    ): String {
        val formatter = SimpleDateFormat(style.pattern, trLocale)
        return formatter.format(Date(localDayMillis))
    }

    fun formatDateLongTurkish(localDayMillis: Long): String {
        val formatter = SimpleDateFormat("d MMMM yyyy, EEEE", trLocale)
        return formatter.format(Date(localDayMillis))
    }

    fun formatDateTimeTurkish(epochMillis: Long, use24Hour: Boolean = true): String {
        val pattern = if (use24Hour) "d MMM yyyy • HH:mm" else "d MMM yyyy • hh:mm a"
        val formatter = SimpleDateFormat(pattern, trLocale)
        return formatter.format(Date(epochMillis))
    }

    fun formatTimeMinutes(minutes: Int, use24Hour: Boolean = true): String {
        val clamped = minutes.coerceIn(0, 23 * 60 + 59)
        val hour = clamped / 60
        val minute = clamped % 60
        return if (use24Hour) {
            String.format(trLocale, "%02d:%02d", hour, minute)
        } else {
            val isPm = hour >= 12
            val h12 = when {
                hour == 0 -> 12
                hour > 12 -> hour - 12
                else -> hour
            }
            val suffix = if (isPm) "ÖS" else "ÖÖ"
            String.format(trLocale, "%02d:%02d %s", h12, minute, suffix)
        }
    }

    fun formatReminderOffsetTurkish(offsetMinutes: Int): String {
        return when {
            offsetMinutes <= 0 -> "Görev saatinde"
            offsetMinutes % 1440 == 0 -> "${offsetMinutes / 1440} gün önce"
            offsetMinutes % 60 == 0 -> "${offsetMinutes / 60} saat önce"
            else -> "$offsetMinutes dk önce"
        }
    }

    fun combineLocalDayAndMinutes(localDayMillis: Long, minuteOfDay: Int): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = localDayMillis
            set(Calendar.HOUR_OF_DAY, (minuteOfDay / 60).coerceIn(0, 23))
            set(Calendar.MINUTE, (minuteOfDay % 60).coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun todayLocalDayMillis(): Long {
        val cal = Calendar.getInstance()
        return localDayMillis(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun localDayMillis(year: Int, month: Int, dayOfMonth: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, dayOfMonth)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun utcPickerMillisToLocalDayMillis(utcMillis: Long): Long {
        val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            timeInMillis = utcMillis
        }
        return localDayMillis(
            utcCal.get(Calendar.YEAR),
            utcCal.get(Calendar.MONTH),
            utcCal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun localDayMillisToUtcPickerMillis(localDayMillis: Long): Long {
        val localCal = Calendar.getInstance().apply {
            timeInMillis = localDayMillis
        }
        val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            set(Calendar.YEAR, localCal.get(Calendar.YEAR))
            set(Calendar.MONTH, localCal.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, localCal.get(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return utcCal.timeInMillis
    }

    fun addDaysToLocalDayMillis(localDayMillis: Long, days: Int): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = localDayMillis
            add(Calendar.DAY_OF_MONTH, days)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun isTaskOnDay(task: TaskItem, dayMillis: Long): Boolean {
        val start = task.startDateMillis
        val end = task.endDateMillis
        return when {
            start != null && end != null -> dayMillis in start..end
            start != null -> start == dayMillis
            end != null -> end == dayMillis
            else -> false
        }
    }
}

data class TaskValidationResult(
    val titleError: String? = null,
    val scheduleError: String? = null
) {
    val isValid: Boolean
        get() = titleError == null && scheduleError == null
}

object TaskScheduleValidator {
    fun validate(
        title: String,
        startDateMillis: Long?,
        endDateMillis: Long?,
        startTimeMinutes: Int?,
        endTimeMinutes: Int?,
        requireTitle: Boolean = true
    ): TaskValidationResult {
        val titleErr = if (requireTitle && title.trim().isEmpty()) {
            "Görev başlığı boş bırakılamaz."
        } else {
            null
        }
        val invalidRangeStartTime = startTimeMinutes != null && startTimeMinutes !in 0..1439
        val invalidRangeEndTime = endTimeMinutes != null && endTimeMinutes !in 0..1439
        val invalidDates = startDateMillis != null && endDateMillis != null && endDateMillis < startDateMillis
        val sameDayInvalidTimes = (startDateMillis == null ||
            endDateMillis == null ||
            startDateMillis == endDateMillis) &&
            startTimeMinutes != null &&
            endTimeMinutes != null &&
            endTimeMinutes < startTimeMinutes

        val scheduleErr = when {
            invalidRangeStartTime || invalidRangeEndTime ->
                "Saat değeri 00:00 ile 23:59 arasında olmalıdır."
            invalidDates ->
                "Bitiş tarihi başlangıç tarihinden önce olamaz."
            sameDayInvalidTimes ->
                "Aynı günde bitiş saati başlangıç saatinden önce olamaz."
            else -> null
        }

        return TaskValidationResult(titleError = titleErr, scheduleError = scheduleErr)
    }
}
