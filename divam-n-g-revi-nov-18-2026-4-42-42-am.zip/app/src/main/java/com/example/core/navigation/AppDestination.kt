package com.example.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.ui.graphics.vector.ImageVector

object AppRoutes {
    const val HOME = "ana_sayfa"
    const val TASKS = "gorevler"
    const val CALENDAR = "takvim"
    const val STATS = "istatistikler"
    const val PROFILE = "profil"
    const val SETTINGS = "ayarlar"
    const val NOTIFICATIONS = "bildirimler"

    const val TASK_EDITOR_BASE = "gorev_duzenle"
    const val ARG_TASK_ID = "taskId"
    const val ARG_INITIAL_DATE = "initialDate"
    const val TASK_EDITOR_PATTERN = "$TASK_EDITOR_BASE?$ARG_TASK_ID={$ARG_TASK_ID}&$ARG_INITIAL_DATE={$ARG_INITIAL_DATE}"

    fun taskEditorRoute(taskId: Long = -1L, initialDateMillis: Long = -1L): String =
        "$TASK_EDITOR_BASE?$ARG_TASK_ID=$taskId&$ARG_INITIAL_DATE=$initialDateMillis"
}

enum class TopLevelDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME(
        route = AppRoutes.HOME,
        label = "Ana Sayfa",
        selectedIcon = Icons.Rounded.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_item_ana_sayfa"
    ),
    TASKS(
        route = AppRoutes.TASKS,
        label = "Görevler",
        selectedIcon = Icons.Rounded.CheckCircle,
        unselectedIcon = Icons.Outlined.CheckCircle,
        testTag = "nav_item_gorevler"
    ),
    CALENDAR(
        route = AppRoutes.CALENDAR,
        label = "Takvim",
        selectedIcon = Icons.Rounded.CalendarMonth,
        unselectedIcon = Icons.Outlined.CalendarMonth,
        testTag = "nav_item_takvim"
    ),
    STATS(
        route = AppRoutes.STATS,
        label = "İstatistikler",
        selectedIcon = Icons.Rounded.BarChart,
        unselectedIcon = Icons.Outlined.BarChart,
        testTag = "nav_item_istatistikler"
    ),
    PROFILE(
        route = AppRoutes.PROFILE,
        label = "Profil",
        selectedIcon = Icons.Rounded.Person,
        unselectedIcon = Icons.Outlined.Person,
        testTag = "nav_item_profil"
    );

    companion object {
        fun fromRoute(route: String?): TopLevelDestination? =
            entries.firstOrNull { it.route == route }
    }
}
