package com.example.core.data.local

import com.example.core.backup.BackupDocument
import com.example.core.backup.BackupRestoreSummary
import com.example.core.backup.TaskBackupManager
import com.example.core.model.TaskCategory
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import com.example.core.notifications.ReminderSchedulerHook
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Locale
import java.util.UUID

data class TaskDraft(
    val title: String,
    val description: String,
    val note: String,
    val startDateMillis: Long?,
    val endDateMillis: Long?,
    val startTimeMinutes: Int?,
    val endTimeMinutes: Int?,
    val priority: TaskPriority,
    val categoryId: String,
    val categoryName: String,
    val status: TaskStatus,
    val isFavorite: Boolean,
    val reminderEnabled: Boolean = true,
    val reminderOffsetsMinutes: List<Int> = listOf(15),
    val recurrence: TaskRecurrence = TaskRecurrence.NONE
)

class TaskRepository(
    private val taskDao: TaskDao,
    private val notificationDao: NotificationDao? = null,
    private val reminderScheduler: ReminderSchedulerHook? = null
) {

    val tasksFlow: Flow<List<TaskItem>> = taskDao.observeAllTasks().map { entities ->
        entities.map { it.toDomain() }
    }

    val categoriesFlow: Flow<List<TaskCategory>> = taskDao.observeAllCategories().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun ensureDefaultCategories() {
        val baseTime = 1L
        val defaults = listOf(
            CategoryEntity("cat_is", "İş", isDefault = true, createdAtMillis = baseTime),
            CategoryEntity("cat_kisisel", "Kişisel", isDefault = true, createdAtMillis = baseTime + 1),
            CategoryEntity("cat_egitim", "Eğitim", isDefault = true, createdAtMillis = baseTime + 2),
            CategoryEntity("cat_alisveris", "Alışveriş", isDefault = true, createdAtMillis = baseTime + 3),
            CategoryEntity("cat_saglik", "Sağlık", isDefault = true, createdAtMillis = baseTime + 4),
            CategoryEntity("cat_ev_isleri", "Ev İşleri", isDefault = true, createdAtMillis = baseTime + 5),
            CategoryEntity("cat_spor", "Spor", isDefault = true, createdAtMillis = baseTime + 6),
            CategoryEntity("cat_diger", "Diğer", isDefault = true, createdAtMillis = baseTime + 7)
        )
        taskDao.insertCategoriesIgnore(defaults)
    }

    suspend fun getTaskById(taskId: Long): TaskItem? =
        taskDao.getTaskById(taskId)?.toDomain()

    suspend fun getAllTasksSync(): List<TaskItem> =
        taskDao.getAllTasksSync().map { it.toDomain() }

    suspend fun createTask(draft: TaskDraft, autoArchiveIfCompleted: Boolean = false): Long {
        val now = System.currentTimeMillis()
        val isCompleted = draft.status == TaskStatus.COMPLETED
        val entity = TaskEntity(
            title = draft.title.trim(),
            description = draft.description.trim(),
            note = draft.note.trim(),
            startDateMillis = draft.startDateMillis,
            endDateMillis = draft.endDateMillis,
            startTimeMinutes = draft.startTimeMinutes,
            endTimeMinutes = draft.endTimeMinutes,
            priority = draft.priority.name,
            categoryId = draft.categoryId,
            categoryName = draft.categoryName,
            status = draft.status.name,
            isFavorite = draft.isFavorite,
            isArchived = isCompleted && autoArchiveIfCompleted,
            isDeleted = false,
            deletedAtMillis = null,
            completedAtMillis = if (isCompleted) now else null,
            createdAtMillis = now,
            updatedAtMillis = now,
            reminderEnabled = draft.reminderEnabled,
            reminderOffsetsCsv = ReminderOffsetsCodec.encode(draft.reminderOffsetsMinutes),
            recurrence = draft.recurrence.name
        )
        val newId = taskDao.insertTask(entity)
        reminderScheduler?.onTaskChanged(newId)
        return newId
    }

    suspend fun updateTask(
        taskId: Long,
        draft: TaskDraft,
        autoArchiveIfCompleted: Boolean = false
    ) {
        val existing = taskDao.getTaskById(taskId) ?: return
        val now = System.currentTimeMillis()
        val completedAt = when {
            draft.status == TaskStatus.COMPLETED && existing.completedAtMillis == null -> now
            draft.status != TaskStatus.COMPLETED -> null
            else -> existing.completedAtMillis
        }
        val nextArchived = if (draft.status == TaskStatus.COMPLETED && autoArchiveIfCompleted) {
            true
        } else {
            existing.isArchived
        }
        taskDao.updateTask(
            existing.copy(
                title = draft.title.trim(),
                description = draft.description.trim(),
                note = draft.note.trim(),
                startDateMillis = draft.startDateMillis,
                endDateMillis = draft.endDateMillis,
                startTimeMinutes = draft.startTimeMinutes,
                endTimeMinutes = draft.endTimeMinutes,
                priority = draft.priority.name,
                categoryId = draft.categoryId,
                categoryName = draft.categoryName,
                status = draft.status.name,
                isFavorite = draft.isFavorite,
                isArchived = nextArchived,
                completedAtMillis = completedAt,
                updatedAtMillis = now,
                reminderEnabled = draft.reminderEnabled,
                reminderOffsetsCsv = ReminderOffsetsCodec.encode(draft.reminderOffsetsMinutes),
                recurrence = draft.recurrence.name
            )
        )
        reminderScheduler?.onTaskChanged(taskId)
    }

    suspend fun duplicateTask(taskId: Long): Long? {
        val existing = taskDao.getTaskById(taskId) ?: return null
        val now = System.currentTimeMillis()
        val copyEntity = existing.copy(
            id = 0L,
            title = "${existing.title} (Kopya)",
            status = TaskStatus.PENDING.name,
            isArchived = false,
            isDeleted = false,
            deletedAtMillis = null,
            completedAtMillis = null,
            createdAtMillis = now,
            updatedAtMillis = now
        )
        val copyId = taskDao.insertTask(copyEntity)
        reminderScheduler?.onTaskChanged(copyId)
        return copyId
    }

    suspend fun toggleCompleted(
        taskId: Long,
        autoArchiveIfCompleted: Boolean = false
    ): Boolean {
        val existing = taskDao.getTaskById(taskId) ?: return false
        val now = System.currentTimeMillis()
        val currentlyCompleted = TaskStatus.fromName(existing.status) == TaskStatus.COMPLETED
        val nextStatus = if (currentlyCompleted) TaskStatus.PENDING else TaskStatus.COMPLETED
        val becameCompleted = nextStatus == TaskStatus.COMPLETED
        val nextArchived = if (becameCompleted && autoArchiveIfCompleted) true else existing.isArchived

        taskDao.updateTask(
            existing.copy(
                status = nextStatus.name,
                isArchived = nextArchived,
                completedAtMillis = if (becameCompleted) now else null,
                updatedAtMillis = now
            )
        )
        if (becameCompleted) {
            reminderScheduler?.onTaskRemoved(taskId)
        } else {
            reminderScheduler?.onTaskChanged(taskId)
        }
        return becameCompleted
    }

    suspend fun setStatus(
        taskId: Long,
        status: TaskStatus,
        autoArchiveIfCompleted: Boolean = false
    ) {
        val existing = taskDao.getTaskById(taskId) ?: return
        val now = System.currentTimeMillis()
        val isDone = status == TaskStatus.COMPLETED || status == TaskStatus.CANCELLED
        val nextArchived = if (status == TaskStatus.COMPLETED && autoArchiveIfCompleted) {
            true
        } else {
            existing.isArchived
        }
        taskDao.updateTask(
            existing.copy(
                status = status.name,
                isArchived = nextArchived,
                completedAtMillis = if (status == TaskStatus.COMPLETED) {
                    existing.completedAtMillis ?: now
                } else {
                    null
                },
                updatedAtMillis = now
            )
        )
        if (isDone) {
            reminderScheduler?.onTaskRemoved(taskId)
        } else {
            reminderScheduler?.onTaskChanged(taskId)
        }
    }

    suspend fun postponeTask(taskId: Long, days: Int) {
        val existing = taskDao.getTaskById(taskId) ?: return
        val now = System.currentTimeMillis()
        val baseDay = existing.startDateMillis ?: TaskDateTimeUtils.todayLocalDayMillis()
        val nextStart = TaskDateTimeUtils.addDaysToLocalDayMillis(baseDay, days)
        val nextEnd = existing.endDateMillis?.let { end ->
            TaskDateTimeUtils.addDaysToLocalDayMillis(end, days)
        }
        taskDao.updateTask(
            existing.copy(
                startDateMillis = nextStart,
                endDateMillis = nextEnd,
                status = TaskStatus.POSTPONED.name,
                completedAtMillis = null,
                updatedAtMillis = now
            )
        )
        reminderScheduler?.onTaskChanged(taskId)
    }

    suspend fun rescheduleTask(
        taskId: Long,
        startDateMillis: Long?,
        endDateMillis: Long?,
        startTimeMinutes: Int?,
        endTimeMinutes: Int?
    ) {
        val existing = taskDao.getTaskById(taskId) ?: return
        taskDao.updateTask(
            existing.copy(
                startDateMillis = startDateMillis,
                endDateMillis = endDateMillis,
                startTimeMinutes = startTimeMinutes,
                endTimeMinutes = endTimeMinutes,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
        reminderScheduler?.onTaskChanged(taskId)
    }

    suspend fun toggleFavorite(taskId: Long) {
        val existing = taskDao.getTaskById(taskId) ?: return
        taskDao.updateTask(
            existing.copy(
                isFavorite = !existing.isFavorite,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun setArchived(taskId: Long, archived: Boolean) {
        val existing = taskDao.getTaskById(taskId) ?: return
        taskDao.updateTask(
            existing.copy(
                isArchived = archived,
                isDeleted = false,
                deletedAtMillis = null,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
        if (archived) {
            reminderScheduler?.onTaskRemoved(taskId)
        } else {
            reminderScheduler?.onTaskChanged(taskId)
        }
    }

    suspend fun moveToTrash(taskId: Long) {
        val existing = taskDao.getTaskById(taskId) ?: return
        val now = System.currentTimeMillis()
        taskDao.updateTask(
            existing.copy(
                isDeleted = true,
                deletedAtMillis = now,
                updatedAtMillis = now
            )
        )
        reminderScheduler?.onTaskRemoved(taskId)
    }

    suspend fun restoreFromTrash(taskId: Long) {
        val existing = taskDao.getTaskById(taskId) ?: return
        taskDao.updateTask(
            existing.copy(
                isDeleted = false,
                deletedAtMillis = null,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
        reminderScheduler?.onTaskChanged(taskId)
    }

    suspend fun deletePermanently(taskId: Long) {
        reminderScheduler?.onTaskRemoved(taskId)
        taskDao.deleteTaskPermanently(taskId)
    }

    suspend fun emptyTrash() {
        val trashIds = taskDao.getTrashTaskIdsSync()
        trashIds.forEach { reminderScheduler?.onTaskRemoved(it) }
        taskDao.emptyTrash()
    }

    suspend fun createCustomCategory(rawName: String): Result<TaskCategory> {
        val trimmed = rawName.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Kategori adı boş bırakılamaz."))
        }
        if (trimmed.length > 32) {
            return Result.failure(IllegalArgumentException("Kategori adı en fazla 32 karakter olabilir."))
        }
        val duplicate = taskDao.findCategoryByName(trimmed)
        if (duplicate != null) {
            return Result.failure(IllegalArgumentException("Bu kategori zaten mevcut."))
        }
        val entity = CategoryEntity(
            id = "cat_custom_${UUID.randomUUID()}",
            name = trimmed,
            isDefault = false,
            createdAtMillis = System.currentTimeMillis()
        )
        taskDao.insertCategory(entity)
        return Result.success(entity.toDomain())
    }

    suspend fun deleteCustomCategory(categoryId: String) {
        taskDao.deleteCustomCategory(categoryId)
    }

    suspend fun restoreFromBackup(document: BackupDocument): BackupRestoreSummary {
        ensureDefaultCategories()
        val trLocale = Locale.forLanguageTag("tr-TR")
        val existingTasks = taskDao.getAllTasksSync().map { it.toDomain() }
        val existingSignatures = existingTasks.map(TaskBackupManager::taskDeduplicationSignature).toMutableSet()

        val catNameMap = mutableMapOf<String, TaskCategory>()
        val existingCats = taskDao.getCategoryCount()
        if (existingCats >= 0) {
            // Mevcut kategorileri isimle eşle
            document.categories.forEach { cat ->
                val found = taskDao.findCategoryByName(cat.name)
                if (found != null) {
                    catNameMap[cat.name.trim().lowercase(trLocale)] = found.toDomain()
                }
            }
        }

        var importedCats = 0
        document.categories.forEach { cat ->
            val key = cat.name.trim().lowercase(trLocale)
            val existing = taskDao.findCategoryByName(cat.name)
            if (existing != null) {
                catNameMap[key] = existing.toDomain()
            } else if (!cat.isDefault) {
                val created = CategoryEntity(
                    id = "cat_custom_${UUID.randomUUID()}",
                    name = cat.name.trim(),
                    isDefault = false,
                    createdAtMillis = cat.createdAtMillis
                )
                taskDao.insertCategory(created)
                catNameMap[key] = created.toDomain()
                importedCats++
            }
        }

        var importedTasks = 0
        var skippedDuplicates = 0
        document.tasks.forEach { record ->
            val signature = TaskBackupManager.taskDeduplicationSignature(record)
            if (!existingSignatures.add(signature)) {
                skippedDuplicates++
                return@forEach
            }

            val catKey = record.categoryName.trim().lowercase(trLocale)
            val resolvedCat = catNameMap[catKey] ?: taskDao.findCategoryByName(record.categoryName)?.toDomain()
            val finalCatId = resolvedCat?.id ?: record.categoryId
            val finalCatName = resolvedCat?.name ?: record.categoryName

            val insertedId = taskDao.insertTask(
                TaskEntity(
                    title = record.title,
                    description = record.description,
                    note = record.note,
                    startDateMillis = record.startDateMillis,
                    endDateMillis = record.endDateMillis,
                    startTimeMinutes = record.startTimeMinutes,
                    endTimeMinutes = record.endTimeMinutes,
                    priority = record.priority.name,
                    categoryId = finalCatId,
                    categoryName = finalCatName,
                    status = record.status.name,
                    isFavorite = record.isFavorite,
                    isArchived = record.isArchived,
                    isDeleted = record.isDeleted,
                    deletedAtMillis = record.deletedAtMillis,
                    completedAtMillis = record.completedAtMillis,
                    createdAtMillis = record.createdAtMillis,
                    updatedAtMillis = record.updatedAtMillis,
                    reminderEnabled = record.reminderEnabled,
                    reminderOffsetsCsv = ReminderOffsetsCodec.encode(record.reminderOffsetsMinutes),
                    recurrence = record.recurrence.name
                )
            )
            importedTasks++
            if (!record.isDeleted && !record.isArchived &&
                record.status != TaskStatus.COMPLETED && record.status != TaskStatus.CANCELLED
            ) {
                reminderScheduler?.onTaskChanged(insertedId)
            }
        }

        return BackupRestoreSummary(
            importedTasksCount = importedTasks,
            skippedDuplicatesCount = skippedDuplicates,
            importedCategoriesCount = importedCats
        )
    }

    suspend fun deleteAllUserData() {
        val all = taskDao.getAllTasksSync()
        all.forEach { reminderScheduler?.onTaskRemoved(it.id) }
        all.forEach { taskDao.deleteTaskPermanently(it.id) }
        notificationDao?.clearAllScheduledReminders()
        notificationDao?.clearNotificationHistory()
        reminderScheduler?.syncAll()
    }
}
