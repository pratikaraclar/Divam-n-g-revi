package com.example.core.designsystem.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.model.ModuleReadiness
import com.example.ui.theme.DivamTheme

@Composable
fun DivamLuxuryBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val bgColor = MaterialTheme.colorScheme.background
    val purpleAura = DivamTheme.extendedColors.purpleAura
    val goldAura = DivamTheme.extendedColors.goldMid.copy(
        alpha = if (DivamTheme.extendedColors.isDark) 0.08f else 0.06f
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgColor)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(purpleAura, bgColor.copy(alpha = 0f)),
                        center = Offset(size.width * 0.85f, size.height * 0.08f),
                        radius = size.maxDimension * 0.55f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(goldAura, bgColor.copy(alpha = 0f)),
                        center = Offset(size.width * 0.12f, size.height * 0.45f),
                        radius = size.maxDimension * 0.42f
                    )
                )
            },
        content = content
    )
}

@Composable
fun DivamLogoMark(
    size: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    val goldBrush = DivamTheme.extendedColors.metallicGoldBrush
    val glowColor = DivamTheme.extendedColors.purpleAura

    Box(
        modifier = modifier
            .size(size)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glowColor, glowColor.copy(alpha = 0f))
                    ),
                    radius = this.size.maxDimension * 0.72f
                )
            }
            .clip(CircleShape)
            .border(width = 1.5.dp, brush = goldBrush, shape = CircleShape)
            .padding(2.dp)
            .clip(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_emblem),
            contentDescription = stringResource(id = R.string.cd_app_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun DivamCrestWordmarkLogo(
    crestSize: Dp = 76.dp,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        DivamLogoMark(size = crestSize)
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = stringResource(id = R.string.app_name),
            style = MaterialTheme.typography.headlineLarge.copy(
                brush = extended.metallicGoldBrush,
                fontWeight = FontWeight.Bold
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DivamCard(
    modifier: Modifier = Modifier,
    highlightGoldBorder: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences
    val showGold = highlightGoldBorder && userPrefs.goldAccentsEnabled
    val borderColor = if (showGold) extended.cardBorderGold else extended.cardBorderSubtle
    val containerColor = if (showGold) {
        MaterialTheme.colorScheme.surfaceContainerHigh
    } else {
        MaterialTheme.colorScheme.surface
    }
    val innerPadding = when (userPrefs.cardDisplayStyle) {
        com.example.core.model.CardDisplayStyle.COMPACT -> 11.dp
        com.example.core.model.CardDisplayStyle.COMFORTABLE -> 16.dp
        com.example.core.model.CardDisplayStyle.DETAILED -> 18.dp
    }

    if (onClick != null) {
        Surface(
            onClick = onClick,
            modifier = modifier.minimumInteractiveComponentSize(),
            shape = MaterialTheme.shapes.large,
            color = containerColor,
            tonalElevation = 2.dp,
            border = BorderStroke(1.dp, borderColor)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(innerPadding),
                content = content
            )
        }
    } else {
        Surface(
            modifier = modifier,
            shape = MaterialTheme.shapes.large,
            color = containerColor,
            tonalElevation = 1.dp,
            border = BorderStroke(1.dp, borderColor)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(innerPadding),
                content = content
            )
        }
    }
}

@Composable
fun ModuleStatusBadge(
    readiness: ModuleReadiness,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val accentColor = when (readiness) {
        ModuleReadiness.ACTIVE -> extended.statusActive
        ModuleReadiness.FOUNDATION_READY -> extended.goldMid
        ModuleReadiness.PLANNED -> extended.statusPlanned
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = accentColor.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.42f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(accentColor)
            )
            Text(
                text = readiness.turkishLabel,
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun DivamSectionTitle(
    title: String,
    subtitle: String? = null,
    badge: ModuleReadiness? = null,
    modifier: Modifier = Modifier
) {
    val goldBrush = DivamTheme.extendedColors.metallicGoldBrush

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            if (badge != null) {
                Spacer(modifier = Modifier.width(10.dp))
                ModuleStatusBadge(readiness = badge)
            }
        }
        if (!subtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .width(56.dp)
                .height(2.dp)
                .clip(CircleShape)
                .background(goldBrush)
        )
    }
}
