package com.example.core.model

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class WindowWidthClass(val turkishLabel: String) {
    COMPACT("Telefon / Kompakt"),
    MEDIUM("Tablet / Orta Ekran"),
    EXPANDED("Tablet / Geniş Ekran");

    val isTabletOrWide: Boolean
        get() = this != COMPACT

    companion object {
        fun fromWidth(maxWidth: Dp): WindowWidthClass = when {
            maxWidth < 600.dp -> COMPACT
            maxWidth < 840.dp -> MEDIUM
            else -> EXPANDED
        }
    }
}

enum class ModuleReadiness(val turkishLabel: String, val isOperational: Boolean) {
    ACTIVE(turkishLabel = "Aktif", isOperational = true),
    FOUNDATION_READY(turkishLabel = "Altyapı Hazır", isOperational = false),
    PLANNED(turkishLabel = "Planlandı", isOperational = false)
}

@Immutable
data class ModuleOverviewItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val readiness: ModuleReadiness,
    val targetRoute: String?
)
