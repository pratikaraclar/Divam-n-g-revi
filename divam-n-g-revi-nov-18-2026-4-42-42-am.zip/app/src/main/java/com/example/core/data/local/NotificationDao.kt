package com.example.core.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Query("SELECT * FROM scheduled_reminders ORDER BY triggerAtMillis ASC")
    fun observeScheduledReminders(): Flow<List<ScheduledReminderEntity>>

    @Query("SELECT * FROM scheduled_reminders ORDER BY triggerAtMillis ASC")
    suspend fun getAllScheduledRemindersSync(): List<ScheduledReminderEntity>

    @Query("SELECT * FROM scheduled_reminders WHERE taskId = :taskId")
    suspend fun getScheduledRemindersForTaskSync(taskId: Long): List<ScheduledReminderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertScheduledReminder(entity: ScheduledReminderEntity): Long

    @Query("DELETE FROM scheduled_reminders WHERE taskId = :taskId")
    suspend fun deleteScheduledRemindersForTask(taskId: Long)

    @Query("DELETE FROM scheduled_reminders WHERE taskId = :taskId AND offsetMinutes = :offsetMinutes")
    suspend fun deleteScheduledReminder(taskId: Long, offsetMinutes: Int)

    @Query("DELETE FROM scheduled_reminders")
    suspend fun clearAllScheduledReminders()

    @Query("SELECT * FROM notification_history ORDER BY triggeredAtMillis DESC LIMIT 200")
    fun observeNotificationHistory(): Flow<List<NotificationHistoryEntity>>

    @Query("SELECT * FROM notification_history ORDER BY triggeredAtMillis DESC")
    suspend fun getAllNotificationHistorySync(): List<NotificationHistoryEntity>

    @Query("SELECT COUNT(*) FROM notification_history WHERE dedupKey = :dedupKey")
    suspend fun countHistoryByDedupKey(dedupKey: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertNotificationHistory(entity: NotificationHistoryEntity): Long

    @Query("DELETE FROM notification_history")
    suspend fun clearNotificationHistory()
}
