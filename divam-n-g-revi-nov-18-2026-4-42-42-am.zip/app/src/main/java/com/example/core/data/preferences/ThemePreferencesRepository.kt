package com.example.core.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.divamPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "divamin_gorevi_preferences"
)

class ThemePreferencesRepository(private val context: Context) {

    private val themeModeKey = stringPreferencesKey("theme_mode")

    val themeModeFlow: Flow<ThemeMode> = context.divamPreferencesDataStore.data.map { prefs ->
        ThemeMode.fromKey(prefs[themeModeKey])
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.divamPreferencesDataStore.edit { prefs ->
            prefs[themeModeKey] = mode.storageKey
        }
    }
}
