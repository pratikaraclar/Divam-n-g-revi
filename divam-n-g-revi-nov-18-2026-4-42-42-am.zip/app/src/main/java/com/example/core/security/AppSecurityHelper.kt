package com.example.core.security

import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.util.Base64
import androidx.core.content.ContextCompat
import java.security.MessageDigest
import java.security.SecureRandom

object AppSecurityHelper {

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val input = "$salt:$pin:divam_pin_v1".toByteArray(Charsets.UTF_8)
        val hashed = digest.digest(input)
        return Base64.encodeToString(hashed, Base64.NO_WRAP)
    }

    fun verifyPin(candidatePin: String, salt: String?, expectedHash: String?): Boolean {
        if (salt.isNullOrBlank() || expectedHash.isNullOrBlank()) return false
        val actualHash = hashPin(candidatePin, salt)
        return MessageDigest.isEqual(
            actualHash.toByteArray(Charsets.UTF_8),
            expectedHash.toByteArray(Charsets.UTF_8)
        )
    }

    fun isPinFormatValid(pin: String): Boolean =
        pin.length in 4..6 && pin.all { it.isDigit() }

    fun canUseBiometricAuthentication(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val manager = context.getSystemService(BiometricManager::class.java) ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val status = manager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            status == BiometricManager.BIOMETRIC_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            manager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
        }
    }

    fun biometricAvailabilityLabel(context: Context): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return "Biyometrik kilit Android 9 ve üzeri cihazlarda desteklenir."
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return "Donanım destekliyorsa biyometrik doğrulama kullanılabilir."
        }
        val manager = context.getSystemService(BiometricManager::class.java)
            ?: return "Biyometrik yöneticiye erişilemedi."
        val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            manager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
        } else {
            @Suppress("DEPRECATION")
            manager.canAuthenticate()
        }
        return when (code) {
            BiometricManager.BIOMETRIC_SUCCESS -> "Parmak izi veya yüz tanıma doğrulaması hazır."
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "Cihaz ayarlarında kayıtlı biyometrik veri bulunmuyor."
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "Bu cihazda biyometrik donanım bulunmuyor."
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "Biyometrik donanım şu an kullanılamıyor."
            else -> "Biyometrik doğrulama kullanılamıyor."
        }
    }

    fun authenticateWithBiometric(
        context: Context,
        title: String = "Divamın Görevi Kilidi",
        subtitle: String = "Devam etmek için biyometrik kimliğinizi doğrulayın",
        negativeButtonText: String = "PIN ile Giriş",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            onError("Bu Android sürümünde biyometrik doğrulama desteklenmiyor.")
            return
        }
        val executor = ContextCompat.getMainExecutor(context)
        val cancellationSignal = CancellationSignal()
        val prompt = BiometricPrompt.Builder(context)
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButton(negativeButtonText, executor) { _, _ -> }
            .build()

        prompt.authenticate(
            cancellationSignal,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    if (errorCode != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                    ) {
                        onError(errString?.toString() ?: "Biyometrik doğrulama başarısız.")
                    }
                }

                override fun onAuthenticationFailed() {
                    onError("Kimlik doğrulanamadı. Tekrar deneyin veya PIN girin.")
                }
            }
        )
    }
}
