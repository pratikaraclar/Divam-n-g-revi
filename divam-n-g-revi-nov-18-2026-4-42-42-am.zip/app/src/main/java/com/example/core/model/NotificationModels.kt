package com.example.core.model

import androidx.compose.runtime.Immutable
import java.util.Calendar

enum class NotificationType(val turkishLabel: String) {
    TASK_REMINDER("Görev Hatırlatıcısı"),
    MORNING_SUMMARY("Sabah Özeti"),
    EVENING_INCOMPLETE("Akşam Tamamlanmamışlar"),
    TEST("Test Bildirimi");

    companion object {
        fun fromName(name: String?): NotificationType =
            entries.firstOrNull { it.name == name } ?: TASK_REMINDER
    }
}

enum class NotificationDeliveryStatus(val turkishLabel: String) {
    SENT("Gönderildi"),
    SENT_SILENT("Sessiz Gönderildi"),
    SUPPRESSED_QUIET_HOURS("Sessiz Saatte Susturuldu"),
    SKIPPED_NO_PERMISSION("İzin Olmadığı İçin Atlandı"),
    CANCELLED("İptal Edildi");

    companion object {
        fun fromName(name: String?): NotificationDeliveryStatus =
            entries.firstOrNull { it.name == name } ?: SENT
    }
}

enum class NotificationChannelKind(
    val baseId: String,
    val turkishTitle: String,
    val turkishDescription: String
) {
    TASK_REMINDERS(
        baseId = "divam_task_reminders",
        turkishTitle = "Görev Hatırlatıcıları",
        turkishDescription = "Görev başlangıç zamanı ve öncesi hatırlatma bildirimleri"
    ),
    DAILY_DIGEST(
        baseId = "divam_daily_digest",
        turkishTitle = "Günlük Özet Bildirimleri",
        turkishDescription = "Sabah günlük plan özeti ve akşam tamamlanmamış görev uyarısı"
    ),
    TEST_ALERTS(
        baseId = "divam_test_alerts",
        turkishTitle = "Bildirim Testleri",
        turkishDescription = "Seçilen ses ve titreşim ayarlarıyla yapılan test bildirimleri"
    )
}

enum class QuietHoursPolicy(val turkishLabel: String, val description: String) {
    SILENT_DELIVERY(
        turkishLabel = "Sessiz ve Titreşimsiz Göster",
        description = "Bildirim sessiz kanalda ses ve titreşim olmadan görünür."
    ),
    SUPPRESS_COMPLETELY(
        turkishLabel = "Bildirimi Tamamen Sustur",
        description = "Sessiz saatlerde bildirim gösterilmez ve geçmişe kaydedilir."
    );

    companion object {
        fun fromName(name: String?): QuietHoursPolicy =
            entries.firstOrNull { it.name == name } ?: SILENT_DELIVERY
    }
}

@Immutable
data class NotificationSoundOption(
    val id: String,
    val title: String,
    val description: String,
    val isSystemDefault: Boolean = false,
    val systemUriString: String? = null
)

object NotificationSoundCatalog {
    const val ID_SYSTEM_DEFAULT = "system_default"
    const val ID_GOLD_CHIME = "raw_gold_chime"
    const val ID_CRYSTAL_ECHO = "raw_crystal_echo"
    const val ID_ROYAL_PURPLE = "raw_royal_purple"
    const val ID_GENTLE_DROP = "raw_gentle_drop"
    const val CUSTOM_URI_PREFIX = "system_uri:"

    val BUILT_IN_SOUNDS: List<NotificationSoundOption> = listOf(
        NotificationSoundOption(
            id = ID_SYSTEM_DEFAULT,
            title = "Varsayılan Sistem Sesi",
            description = "Cihazınızın standart bildirim zil sesi",
            isSystemDefault = true
        ),
        NotificationSoundOption(
            id = ID_GOLD_CHIME,
            title = "Altın Çan",
            description = "Sıcak ve belirgin iki notalı zarif çan sesi"
        ),
        NotificationSoundOption(
            id = ID_CRYSTAL_ECHO,
            title = "Kristal Yankı",
            description = "Berrak üç notalı yüksek netlikte melodi"
        ),
        NotificationSoundOption(
            id = ID_ROYAL_PURPLE,
            title = "Mor Harmoni",
            description = "Yumuşak ve derin akor tınısı"
        ),
        NotificationSoundOption(
            id = ID_GENTLE_DROP,
            title = "Zarif Damla",
            description = "Kısa ve dikkat çekici tek nota uyarısı"
        )
    )

    fun customDeviceToneId(uriString: String): String = "$CUSTOM_URI_PREFIX$uriString"

    fun extractDeviceUri(soundId: String): String? =
        if (soundId.startsWith(CUSTOM_URI_PREFIX)) soundId.removePrefix(CUSTOM_URI_PREFIX) else null

    fun labelForSoundId(soundId: String, deviceSounds: List<NotificationSoundOption> = emptyList()): String {
        BUILT_IN_SOUNDS.firstOrNull { it.id == soundId }?.let { return it.title }
        deviceSounds.firstOrNull { it.id == soundId }?.let { return it.title }
        return if (soundId.startsWith(CUSTOM_URI_PREFIX)) "Cihaz Bildirim Sesi" else "Varsayılan Sistem Sesi"
    }
}

@Immutable
data class ChannelSoundConfig(
    val soundId: String = NotificationSoundCatalog.ID_SYSTEM_DEFAULT,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val silentMode: Boolean = false
)

@Immutable
data class EffectiveChannelBehavior(
    val kind: NotificationChannelKind,
    val isQuietHoursActive: Boolean,
    val suppressCompletely: Boolean,
    val useSilentMode: Boolean,
    val effectiveSoundEnabled: Boolean,
    val effectiveVibrationEnabled: Boolean,
    val effectiveSoundId: String
)

@Immutable
data class NotificationSettings(
    val notificationsEnabled: Boolean = true,
    val defaultReminderOffsets: List<Int> = listOf(15),
    val morningSummaryEnabled: Boolean = true,
    val morningSummaryMinutes: Int = 8 * 60 + 30,
    val eveningIncompleteEnabled: Boolean = true,
    val eveningIncompleteMinutes: Int = 20 * 60 + 30,
    val quietHoursEnabled: Boolean = true,
    val quietHoursStartMinutes: Int = 23 * 60,
    val quietHoursEndMinutes: Int = 7 * 60 + 30,
    val quietHoursPolicy: QuietHoursPolicy = QuietHoursPolicy.SILENT_DELIVERY,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val silentNotificationMode: Boolean = false,
    val completionSoundEnabled: Boolean = true,
    val taskReminderChannel: ChannelSoundConfig = ChannelSoundConfig(),
    val dailyDigestChannel: ChannelSoundConfig = ChannelSoundConfig(
        soundId = NotificationSoundCatalog.ID_GENTLE_DROP
    ),
    val testAlertChannel: ChannelSoundConfig = ChannelSoundConfig(),
    val channelConfigVersion: Int = 1
) {
    fun channelConfigFor(kind: NotificationChannelKind): ChannelSoundConfig = when (kind) {
        NotificationChannelKind.TASK_REMINDERS -> taskReminderChannel
        NotificationChannelKind.DAILY_DIGEST -> dailyDigestChannel
        NotificationChannelKind.TEST_ALERTS -> testAlertChannel
    }

    fun isInQuietHours(minuteOfDay: Int): Boolean {
        if (!quietHoursEnabled) return false
        val start = quietHoursStartMinutes.coerceIn(0, 23 * 60 + 59)
        val end = quietHoursEndMinutes.coerceIn(0, 23 * 60 + 59)
        if (start == end) return false
        return if (start < end) {
            minuteOfDay in start until end
        } else {
            minuteOfDay >= start || minuteOfDay < end
        }
    }

    fun isEpochInQuietHours(epochMillis: Long): Boolean {
        val cal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val minuteOfDay = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return isInQuietHours(minuteOfDay)
    }

    fun resolveBehavior(
        kind: NotificationChannelKind,
        atEpochMillis: Long,
        respectQuietHours: Boolean = true
    ): EffectiveChannelBehavior {
        val ch = channelConfigFor(kind)
        val inQuiet = respectQuietHours && isEpochInQuietHours(atEpochMillis)
        if (inQuiet && quietHoursPolicy == QuietHoursPolicy.SUPPRESS_COMPLETELY) {
            return EffectiveChannelBehavior(
                kind = kind,
                isQuietHoursActive = true,
                suppressCompletely = true,
                useSilentMode = true,
                effectiveSoundEnabled = false,
                effectiveVibrationEnabled = false,
                effectiveSoundId = ch.soundId
            )
        }
        val forceSilent = silentNotificationMode || ch.silentMode || inQuiet
        val finalSound = !forceSilent && soundEnabled && ch.soundEnabled
        val finalVibration = !forceSilent && vibrationEnabled && ch.vibrationEnabled
        return EffectiveChannelBehavior(
            kind = kind,
            isQuietHoursActive = inQuiet,
            suppressCompletely = false,
            useSilentMode = forceSilent || (!finalSound && !finalVibration),
            effectiveSoundEnabled = finalSound,
            effectiveVibrationEnabled = finalVibration,
            effectiveSoundId = ch.soundId
        )
    }

    fun shouldPlayCompletionFeedback(atEpochMillis: Long): Boolean {
        if (!completionSoundEnabled || silentNotificationMode || !soundEnabled) return false
        return !isEpochInQuietHours(atEpochMillis)
    }

    companion object {
        val PRESET_OFFSETS_MINUTES: List<Int> = listOf(0, 5, 10, 15, 30, 60, 1440)
    }
}

@Immutable
data class ChannelSystemInspection(
    val kind: NotificationChannelKind,
    val activeChannelId: String,
    val existsOnSystem: Boolean,
    val blockedBySystem: Boolean,
    val systemSoundMatchesSelected: Boolean,
    val systemVibrationMatchesSelected: Boolean
)

@Immutable
data class ScheduledReminderItem(
    val id: Long,
    val taskId: Long,
    val taskTitle: String,
    val offsetMinutes: Int,
    val occurrenceDayMillis: Long,
    val triggerAtMillis: Long,
    val requestCode: Int,
    val updatedAtMillis: Long
)

@Immutable
data class NotificationHistoryItem(
    val id: Long,
    val taskId: Long?,
    val taskTitle: String,
    val title: String,
    val message: String,
    val type: NotificationType,
    val deliveryStatus: NotificationDeliveryStatus,
    val offsetMinutes: Int?,
    val triggeredAtMillis: Long
)
