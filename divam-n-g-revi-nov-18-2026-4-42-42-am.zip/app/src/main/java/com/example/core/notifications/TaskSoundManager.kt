package com.example.core.notifications

import android.content.ContentResolver
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.annotation.RawRes
import com.example.R
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationSoundCatalog
import com.example.core.model.NotificationSoundOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SoundPreviewResult(
    val started: Boolean,
    val usedFallback: Boolean = false,
    val mediaVolumeZero: Boolean = false,
    val errorMessage: String? = null
)

object TaskSoundManager {

    const val ID_COMPLETION_SOUND = "raw_task_complete"

    private val BUNDLED_RAW_SOUND_IDS: List<Int> = listOf(
        R.raw.sound_gold_chime,
        R.raw.sound_crystal_echo,
        R.raw.sound_royal_purple,
        R.raw.sound_gentle_drop,
        R.raw.sound_task_complete
    )

    private val MEDIA_AUDIO_ATTRIBUTES: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private val _playingSoundId = MutableStateFlow<String?>(null)
    val playingSoundId: StateFlow<String?> = _playingSoundId.asStateFlow()

    private var activePlayer: MediaPlayer? = null
    private var activeAudioManager: AudioManager? = null
    private var activeFocusRequest: AudioFocusRequest? = null

    @RawRes
    fun rawResIdFor(soundId: String): Int? = when (soundId) {
        NotificationSoundCatalog.ID_GOLD_CHIME -> R.raw.sound_gold_chime
        NotificationSoundCatalog.ID_CRYSTAL_ECHO -> R.raw.sound_crystal_echo
        NotificationSoundCatalog.ID_ROYAL_PURPLE -> R.raw.sound_royal_purple
        NotificationSoundCatalog.ID_GENTLE_DROP -> R.raw.sound_gentle_drop
        ID_COMPLETION_SOUND -> R.raw.sound_task_complete
        else -> null
    }

    fun verifyBundledRawSounds(context: Context): Map<Int, Boolean> {
        val resources = context.resources
        return BUNDLED_RAW_SOUND_IDS.associateWith { resId ->
            runCatching {
                val hasValidWaveHeader = resources.openRawResource(resId).use { input ->
                    val header = ByteArray(12)
                    val read = input.read(header)
                    read == 12 &&
                        header[0] == 'R'.code.toByte() &&
                        header[1] == 'I'.code.toByte() &&
                        header[2] == 'F'.code.toByte() &&
                        header[3] == 'F'.code.toByte() &&
                        header[8] == 'W'.code.toByte() &&
                        header[9] == 'A'.code.toByte() &&
                        header[10] == 'V'.code.toByte() &&
                        header[11] == 'E'.code.toByte()
                }
                val fdValid = runCatching {
                    resources.openRawResourceFd(resId).use { afd -> afd.length > 44L }
                }.getOrDefault(hasValidWaveHeader)
                hasValidWaveHeader && fdValid
            }.getOrDefault(false)
        }
    }

    fun resolveSoundUri(context: Context, soundId: String): Uri? {
        val pkg = context.packageName
        rawResIdFor(soundId)?.let { resId ->
            return rawUri(pkg, resId)
        }
        return when (soundId) {
            NotificationSoundCatalog.ID_SYSTEM_DEFAULT ->
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    ?: rawUri(pkg, R.raw.sound_gold_chime)
            else -> {
                val customUri = NotificationSoundCatalog.extractDeviceUri(soundId)
                if (customUri != null) {
                    runCatching { Uri.parse(customUri) }.getOrNull()
                } else {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                        ?: rawUri(pkg, R.raw.sound_gold_chime)
                }
            }
        }
    }

    private fun rawUri(packageName: String, rawResId: Int): Uri =
        Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://$packageName/$rawResId")

    fun loadAvailableSounds(context: Context): List<NotificationSoundOption> {
        val result = NotificationSoundCatalog.BUILT_IN_SOUNDS.toMutableList()
        runCatching {
            val manager = RingtoneManager(context).apply {
                setType(RingtoneManager.TYPE_NOTIFICATION)
            }
            val cursor = manager.cursor
            var added = 0
            if (cursor != null) {
                cursor.use { c ->
                    while (c.moveToNext() && added < 8) {
                        val pos = c.position
                        val title = c.getString(RingtoneManager.TITLE_COLUMN_INDEX)?.trim()
                        val uri = manager.getRingtoneUri(pos)
                        if (!title.isNullOrEmpty() && uri != null) {
                            val id = NotificationSoundCatalog.customDeviceToneId(uri.toString())
                            if (result.none { it.id == id }) {
                                result.add(
                                    NotificationSoundOption(
                                        id = id,
                                        title = title,
                                        description = "Cihaz bildirim sesi",
                                        systemUriString = uri.toString()
                                    )
                                )
                                added++
                            }
                        }
                    }
                }
            }
        }
        return result
    }

    @Synchronized
    fun playPreview(context: Context, soundId: String): Boolean =
        playPreviewWithDiagnostics(context, soundId).started

    @Synchronized
    fun playPreviewWithDiagnostics(context: Context, soundId: String): SoundPreviewResult {
        stopPreview()
        val appContext = context.applicationContext
        val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val mediaVolumeZero = audioManager != null &&
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) <= 0

        requestMediaAudioFocus(audioManager)

        val bundledResId = rawResIdFor(soundId)
        if (bundledResId != null) {
            val rawAttempt = startMediaPreviewFromRaw(appContext, bundledResId, soundId)
            return if (rawAttempt.isSuccess) {
                SoundPreviewResult(
                    started = true,
                    usedFallback = false,
                    mediaVolumeZero = mediaVolumeZero
                )
            } else {
                stopPreview()
                SoundPreviewResult(
                    started = false,
                    mediaVolumeZero = mediaVolumeZero,
                    errorMessage = "Yerleşik ses dosyası çalınamadı (${rawAttempt.exceptionOrNull()?.localizedMessage ?: "bilinmeyen hata"})."
                )
            }
        }

        val candidateUris = buildList {
            if (soundId == NotificationSoundCatalog.ID_SYSTEM_DEFAULT) {
                runCatching {
                    RingtoneManager.getActualDefaultRingtoneUri(appContext, RingtoneManager.TYPE_NOTIFICATION)
                }.getOrNull()?.let { add(it) }
                runCatching {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }.getOrNull()?.let { add(it) }
            } else {
                NotificationSoundCatalog.extractDeviceUri(soundId)?.let { uriStr ->
                    runCatching { Uri.parse(uriStr) }.getOrNull()?.let { add(it) }
                }
            }
        }.distinct()

        for (candidateUri in candidateUris) {
            val uriAttempt = startMediaPreviewFromUri(appContext, candidateUri, soundId)
            if (uriAttempt.isSuccess) {
                return SoundPreviewResult(
                    started = true,
                    usedFallback = false,
                    mediaVolumeZero = mediaVolumeZero
                )
            }
        }

        val fallbackAttempt = startMediaPreviewFromRaw(
            appContext = appContext,
            rawResId = R.raw.sound_gold_chime,
            playingId = soundId
        )
        return if (fallbackAttempt.isSuccess) {
            SoundPreviewResult(
                started = true,
                usedFallback = true,
                mediaVolumeZero = mediaVolumeZero
            )
        } else {
            stopPreview()
            SoundPreviewResult(
                started = false,
                mediaVolumeZero = mediaVolumeZero,
                errorMessage = "Ses önizlemesi cihazda oynatılamadı."
            )
        }
    }

    private fun startMediaPreviewFromRaw(
        appContext: Context,
        @RawRes rawResId: Int,
        playingId: String
    ): Result<Unit> = runCatching {
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(MEDIA_AUDIO_ATTRIBUTES)
            appContext.resources.openRawResourceFd(rawResId).use { afd ->
                player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            }
            configureAndStartPreviewPlayer(player, playingId)
        } catch (t: Throwable) {
            runCatching { player.release() }
            throw t
        }
    }

    private fun startMediaPreviewFromUri(
        appContext: Context,
        uri: Uri,
        playingId: String
    ): Result<Unit> = runCatching {
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(MEDIA_AUDIO_ATTRIBUTES)
            player.setDataSource(appContext, uri)
            configureAndStartPreviewPlayer(player, playingId)
        } catch (t: Throwable) {
            runCatching { player.release() }
            throw t
        }
    }

    private fun configureAndStartPreviewPlayer(player: MediaPlayer, playingId: String) {
        player.isLooping = false
        player.setVolume(1.0f, 1.0f)
        player.setOnCompletionListener { mp ->
            cleanupCompletedOrErroredPlayer(mp)
        }
        player.setOnErrorListener { mp, _, _ ->
            cleanupCompletedOrErroredPlayer(mp)
            true
        }
        player.prepare()
        player.start()
        activePlayer = player
        _playingSoundId.value = playingId
    }

    @Synchronized
    private fun cleanupCompletedOrErroredPlayer(mp: MediaPlayer) {
        runCatching { mp.release() }
        if (activePlayer === mp) {
            activePlayer = null
            _playingSoundId.value = null
            abandonMediaAudioFocus()
        }
    }

    private fun requestMediaAudioFocus(audioManager: AudioManager?) {
        if (audioManager == null) return
        activeAudioManager = audioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(MEDIA_AUDIO_ATTRIBUTES)
                .setAcceptsDelayedFocusGain(false)
                .build()
            activeFocusRequest = request
            runCatching { audioManager.requestAudioFocus(request) }
        } else {
            @Suppress("DEPRECATION")
            runCatching {
                audioManager.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        }
    }

    private fun abandonMediaAudioFocus() {
        val audioManager = activeAudioManager ?: return
        val focusRequest = activeFocusRequest
        activeFocusRequest = null
        activeAudioManager = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
            runCatching { audioManager.abandonAudioFocusRequest(focusRequest) }
        } else {
            @Suppress("DEPRECATION")
            runCatching { audioManager.abandonAudioFocus(null) }
        }
    }

    @Synchronized
    fun stopPreview() {
        val current = activePlayer
        activePlayer = null
        _playingSoundId.value = null
        if (current != null) {
            runCatching {
                if (current.isPlaying) {
                    current.stop()
                }
            }
            runCatching { current.release() }
        }
        abandonMediaAudioFocus()
    }

    fun playTaskCompletedFeedback(context: Context, settings: NotificationSettings) {
        val now = System.currentTimeMillis()
        if (!settings.shouldPlayCompletionFeedback(now)) {
            return
        }
        val appContext = context.applicationContext
        runCatching {
            val player = MediaPlayer()
            try {
                player.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                appContext.resources.openRawResourceFd(R.raw.sound_task_complete).use { afd ->
                    player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                }
                player.setVolume(1.0f, 1.0f)
                player.setOnCompletionListener { mp -> runCatching { mp.release() } }
                player.setOnErrorListener { mp, _, _ ->
                    runCatching { mp.release() }
                    true
                }
                player.prepare()
                player.start()
            } catch (t: Throwable) {
                runCatching { player.release() }
                throw t
            }
        }
        if (settings.vibrationEnabled && !settings.isEpochInQuietHours(now)) {
            triggerShortHapticPulse(appContext)
        }
    }

    private fun triggerShortHapticPulse(context: Context) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(45L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createOneShot(45L, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(45L)
                }
            }
        }
    }
}
