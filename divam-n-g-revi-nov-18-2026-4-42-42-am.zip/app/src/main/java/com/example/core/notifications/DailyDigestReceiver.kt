package com.example.core.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.NotificationHistoryEntity
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationDeliveryStatus
import com.example.core.model.NotificationType
import com.example.core.model.TaskDateTimeUtils
import com.example.core.navigation.AppRoutes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DailyDigestReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(EXTRA_DIGEST_KIND) ?: return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                handleDigest(context.applicationContext, kind)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun handleDigest(context: Context, kind: String) {
        val db = DivamDatabase.getInstance(context)
        val taskDao = db.taskDao()
        val notificationDao = db.notificationDao()
        val prefs = NotificationPreferencesRepository(context)
        val settings = prefs.getSettingsSnapshot()
        val scheduler = AndroidTaskReminderScheduler.create(context)

        val todayDayMillis = TaskDateTimeUtils.todayLocalDayMillis()
        val now = System.currentTimeMillis()
        val tasks = taskDao.getAllTasksSync().map { it.toDomain() }

        if (settings.notificationsEnabled) {
            val isMorning = kind == KIND_MORNING_SUMMARY
            val featureEnabled = if (isMorning) settings.morningSummaryEnabled else settings.eveningIncompleteEnabled
            if (featureEnabled) {
                val content = if (isMorning) {
                    ReminderScheduleCalculator.buildMorningSummaryContent(tasks, todayDayMillis)
                } else {
                    ReminderScheduleCalculator.buildEveningIncompleteContent(tasks, todayDayMillis)
                }
                if (content != null) {
                    val dedupKey = "digest_${kind}_$todayDayMillis"
                    if (notificationDao.countHistoryByDedupKey(dedupKey) == 0) {
                        val behavior = settings.resolveBehavior(
                            kind = NotificationChannelKind.DAILY_DIGEST,
                            atEpochMillis = now,
                            respectQuietHours = true
                        )
                        val status = when {
                            !NotificationChannelHelper.hasPostNotificationPermission(context) ->
                                NotificationDeliveryStatus.SKIPPED_NO_PERMISSION
                            behavior.suppressCompletely ->
                                NotificationDeliveryStatus.SUPPRESSED_QUIET_HOURS
                            else -> {
                                val notifId = if (isMorning) REQUEST_CODE_MORNING else REQUEST_CODE_EVENING
                                val posted = NotificationChannelHelper.postNotification(
                                    context = context,
                                    notificationId = notifId,
                                    title = content.title,
                                    message = content.message,
                                    settings = settings,
                                    behavior = behavior,
                                    openRoute = AppRoutes.CALENDAR
                                )
                                if (!posted) {
                                    NotificationDeliveryStatus.SKIPPED_NO_PERMISSION
                                } else if (behavior.useSilentMode) {
                                    NotificationDeliveryStatus.SENT_SILENT
                                } else {
                                    NotificationDeliveryStatus.SENT
                                }
                            }
                        }

                        notificationDao.insertNotificationHistory(
                            NotificationHistoryEntity(
                                taskId = null,
                                taskTitle = if (isMorning) "Sabah Özeti" else "Akşam Kontrolü",
                                title = content.title,
                                message = content.message,
                                type = if (isMorning) {
                                    NotificationType.MORNING_SUMMARY.name
                                } else {
                                    NotificationType.EVENING_INCOMPLETE.name
                                },
                                deliveryStatus = status.name,
                                offsetMinutes = null,
                                triggeredAtMillis = now,
                                dedupKey = dedupKey
                            )
                        )
                    }
                }
            }
        }

        // Ertesi gün için günlük özet alarmlarını yenile
        scheduler.syncDailyDigests()
    }

    companion object {
        const val EXTRA_DIGEST_KIND = "extra_digest_kind"
        const val KIND_MORNING_SUMMARY = "morning_summary"
        const val KIND_EVENING_INCOMPLETE = "evening_incomplete"
        const val REQUEST_CODE_MORNING = 900_001
        const val REQUEST_CODE_EVENING = 900_002

        fun buildIntent(context: Context, kind: String): Intent =
            Intent(context, DailyDigestReceiver::class.java).apply {
                action = "com.example.action.DAILY_DIGEST_$kind"
                putExtra(EXTRA_DIGEST_KIND, kind)
            }
    }
}
