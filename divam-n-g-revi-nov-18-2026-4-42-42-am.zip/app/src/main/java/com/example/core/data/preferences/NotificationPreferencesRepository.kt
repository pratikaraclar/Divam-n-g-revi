package com.example.core.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.data.local.ReminderOffsetsCodec
import com.example.core.model.ChannelSoundConfig
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationSoundCatalog
import com.example.core.model.QuietHoursPolicy
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.divamNotificationDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "divam_notification_preferences"
)

class NotificationPreferencesRepository(private val context: Context) {

    private object Keys {
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val DEFAULT_OFFSETS_CSV = stringPreferencesKey("default_offsets_csv")
        val MORNING_SUMMARY_ENABLED = booleanPreferencesKey("morning_summary_enabled")
        val MORNING_SUMMARY_MINUTES = intPreferencesKey("morning_summary_minutes")
        val EVENING_INCOMPLETE_ENABLED = booleanPreferencesKey("evening_incomplete_enabled")
        val EVENING_INCOMPLETE_MINUTES = intPreferencesKey("evening_incomplete_minutes")
        val QUIET_HOURS_ENABLED = booleanPreferencesKey("quiet_hours_enabled")
        val QUIET_HOURS_START_MINUTES = intPreferencesKey("quiet_hours_start_minutes")
        val QUIET_HOURS_END_MINUTES = intPreferencesKey("quiet_hours_end_minutes")
        val QUIET_HOURS_POLICY = stringPreferencesKey("quiet_hours_policy")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val SILENT_NOTIFICATION_MODE = booleanPreferencesKey("silent_notification_mode")
        val COMPLETION_SOUND_ENABLED = booleanPreferencesKey("completion_sound_enabled")
        val CHANNEL_CONFIG_VERSION = intPreferencesKey("channel_config_version")

        val TASK_SOUND_ID = stringPreferencesKey("task_ch_sound_id")
        val TASK_SOUND_ENABLED = booleanPreferencesKey("task_ch_sound_enabled")
        val TASK_VIBRATION_ENABLED = booleanPreferencesKey("task_ch_vibration_enabled")
        val TASK_SILENT_MODE = booleanPreferencesKey("task_ch_silent_mode")

        val DIGEST_SOUND_ID = stringPreferencesKey("digest_ch_sound_id")
        val DIGEST_SOUND_ENABLED = booleanPreferencesKey("digest_ch_sound_enabled")
        val DIGEST_VIBRATION_ENABLED = booleanPreferencesKey("digest_ch_vibration_enabled")
        val DIGEST_SILENT_MODE = booleanPreferencesKey("digest_ch_silent_mode")

        val TEST_SOUND_ID = stringPreferencesKey("test_ch_sound_id")
        val TEST_SOUND_ENABLED = booleanPreferencesKey("test_ch_sound_enabled")
        val TEST_VIBRATION_ENABLED = booleanPreferencesKey("test_ch_vibration_enabled")
        val TEST_SILENT_MODE = booleanPreferencesKey("test_ch_silent_mode")
    }

    val settingsFlow: Flow<NotificationSettings> = context.divamNotificationDataStore.data.map { prefs ->
        decodePreferences(prefs)
    }

    suspend fun getSettingsSnapshot(): NotificationSettings = settingsFlow.first()

    suspend fun updateSettings(transform: (NotificationSettings) -> NotificationSettings) {
        context.divamNotificationDataStore.edit { prefs ->
            val current = decodePreferences(prefs)
            val next = transform(current)
            prefs[Keys.NOTIFICATIONS_ENABLED] = next.notificationsEnabled
            prefs[Keys.DEFAULT_OFFSETS_CSV] = ReminderOffsetsCodec.encode(next.defaultReminderOffsets)
            prefs[Keys.MORNING_SUMMARY_ENABLED] = next.morningSummaryEnabled
            prefs[Keys.MORNING_SUMMARY_MINUTES] = next.morningSummaryMinutes
            prefs[Keys.EVENING_INCOMPLETE_ENABLED] = next.eveningIncompleteEnabled
            prefs[Keys.EVENING_INCOMPLETE_MINUTES] = next.eveningIncompleteMinutes
            prefs[Keys.QUIET_HOURS_ENABLED] = next.quietHoursEnabled
            prefs[Keys.QUIET_HOURS_START_MINUTES] = next.quietHoursStartMinutes
            prefs[Keys.QUIET_HOURS_END_MINUTES] = next.quietHoursEndMinutes
            prefs[Keys.QUIET_HOURS_POLICY] = next.quietHoursPolicy.name
            prefs[Keys.SOUND_ENABLED] = next.soundEnabled
            prefs[Keys.VIBRATION_ENABLED] = next.vibrationEnabled
            prefs[Keys.SILENT_NOTIFICATION_MODE] = next.silentNotificationMode
            prefs[Keys.COMPLETION_SOUND_ENABLED] = next.completionSoundEnabled
            prefs[Keys.CHANNEL_CONFIG_VERSION] = next.channelConfigVersion

            prefs[Keys.TASK_SOUND_ID] = next.taskReminderChannel.soundId
            prefs[Keys.TASK_SOUND_ENABLED] = next.taskReminderChannel.soundEnabled
            prefs[Keys.TASK_VIBRATION_ENABLED] = next.taskReminderChannel.vibrationEnabled
            prefs[Keys.TASK_SILENT_MODE] = next.taskReminderChannel.silentMode

            prefs[Keys.DIGEST_SOUND_ID] = next.dailyDigestChannel.soundId
            prefs[Keys.DIGEST_SOUND_ENABLED] = next.dailyDigestChannel.soundEnabled
            prefs[Keys.DIGEST_VIBRATION_ENABLED] = next.dailyDigestChannel.vibrationEnabled
            prefs[Keys.DIGEST_SILENT_MODE] = next.dailyDigestChannel.silentMode

            prefs[Keys.TEST_SOUND_ID] = next.testAlertChannel.soundId
            prefs[Keys.TEST_SOUND_ENABLED] = next.testAlertChannel.soundEnabled
            prefs[Keys.TEST_VIBRATION_ENABLED] = next.testAlertChannel.vibrationEnabled
            prefs[Keys.TEST_SILENT_MODE] = next.testAlertChannel.silentMode
        }
    }

    suspend fun updateChannelConfig(
        kind: NotificationChannelKind,
        transform: (ChannelSoundConfig) -> ChannelSoundConfig
    ) {
        updateSettings { current ->
            val updated = when (kind) {
                NotificationChannelKind.TASK_REMINDERS ->
                    current.copy(taskReminderChannel = transform(current.taskReminderChannel))
                NotificationChannelKind.DAILY_DIGEST ->
                    current.copy(dailyDigestChannel = transform(current.dailyDigestChannel))
                NotificationChannelKind.TEST_ALERTS ->
                    current.copy(testAlertChannel = transform(current.testAlertChannel))
            }
            updated.copy(channelConfigVersion = current.channelConfigVersion + 1)
        }
    }

    suspend fun resetSoundsToDefault() {
        updateSettings { current ->
            current.copy(
                soundEnabled = true,
                vibrationEnabled = true,
                silentNotificationMode = false,
                completionSoundEnabled = true,
                taskReminderChannel = ChannelSoundConfig(),
                dailyDigestChannel = ChannelSoundConfig(soundId = NotificationSoundCatalog.ID_SYSTEM_DEFAULT),
                testAlertChannel = ChannelSoundConfig(),
                channelConfigVersion = current.channelConfigVersion + 1
            )
        }
    }

    private fun decodePreferences(prefs: Preferences): NotificationSettings {
        val rawCsv = prefs[Keys.DEFAULT_OFFSETS_CSV]
        val parsedOffsets = if (rawCsv == null) {
            listOf(15)
        } else {
            ReminderOffsetsCodec.decode(rawCsv)
        }
        return NotificationSettings(
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            defaultReminderOffsets = parsedOffsets,
            morningSummaryEnabled = prefs[Keys.MORNING_SUMMARY_ENABLED] ?: true,
            morningSummaryMinutes = (prefs[Keys.MORNING_SUMMARY_MINUTES] ?: (8 * 60 + 30)).coerceIn(0, 23 * 60 + 59),
            eveningIncompleteEnabled = prefs[Keys.EVENING_INCOMPLETE_ENABLED] ?: true,
            eveningIncompleteMinutes = (prefs[Keys.EVENING_INCOMPLETE_MINUTES] ?: (20 * 60 + 30)).coerceIn(0, 23 * 60 + 59),
            quietHoursEnabled = prefs[Keys.QUIET_HOURS_ENABLED] ?: true,
            quietHoursStartMinutes = (prefs[Keys.QUIET_HOURS_START_MINUTES] ?: (23 * 60)).coerceIn(0, 23 * 60 + 59),
            quietHoursEndMinutes = (prefs[Keys.QUIET_HOURS_END_MINUTES] ?: (7 * 60 + 30)).coerceIn(0, 23 * 60 + 59),
            quietHoursPolicy = QuietHoursPolicy.fromName(prefs[Keys.QUIET_HOURS_POLICY]),
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION_ENABLED] ?: true,
            silentNotificationMode = prefs[Keys.SILENT_NOTIFICATION_MODE] ?: false,
            completionSoundEnabled = prefs[Keys.COMPLETION_SOUND_ENABLED] ?: true,
            taskReminderChannel = ChannelSoundConfig(
                soundId = prefs[Keys.TASK_SOUND_ID] ?: NotificationSoundCatalog.ID_SYSTEM_DEFAULT,
                soundEnabled = prefs[Keys.TASK_SOUND_ENABLED] ?: true,
                vibrationEnabled = prefs[Keys.TASK_VIBRATION_ENABLED] ?: true,
                silentMode = prefs[Keys.TASK_SILENT_MODE] ?: false
            ),
            dailyDigestChannel = ChannelSoundConfig(
                soundId = prefs[Keys.DIGEST_SOUND_ID] ?: NotificationSoundCatalog.ID_GENTLE_DROP,
                soundEnabled = prefs[Keys.DIGEST_SOUND_ENABLED] ?: true,
                vibrationEnabled = prefs[Keys.DIGEST_VIBRATION_ENABLED] ?: true,
                silentMode = prefs[Keys.DIGEST_SILENT_MODE] ?: false
            ),
            testAlertChannel = ChannelSoundConfig(
                soundId = prefs[Keys.TEST_SOUND_ID] ?: NotificationSoundCatalog.ID_SYSTEM_DEFAULT,
                soundEnabled = prefs[Keys.TEST_SOUND_ENABLED] ?: true,
                vibrationEnabled = prefs[Keys.TEST_VIBRATION_ENABLED] ?: true,
                silentMode = prefs[Keys.TEST_SILENT_MODE] ?: false
            ),
            channelConfigVersion = (prefs[Keys.CHANNEL_CONFIG_VERSION] ?: 1).coerceAtLeast(1)
        )
    }
}
