package com.example.core.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.AppFontScale
import com.example.core.model.CardDisplayStyle
import com.example.core.model.DateFormatStyle
import com.example.core.model.TaskBoxFilter
import com.example.core.model.TaskPriority
import com.example.core.model.UserPreferences
import com.example.core.model.WeekStartDay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.divamUserDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "divam_user_preferences"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val AVATAR_PATH = stringPreferencesKey("avatar_local_path")
        val DAILY_GOAL = intPreferencesKey("daily_task_goal")
        val WEEKLY_GOAL = intPreferencesKey("weekly_task_goal")
        val GOLD_ACCENTS = booleanPreferencesKey("gold_accents_enabled")
        val FONT_SCALE = stringPreferencesKey("app_font_scale")
        val CARD_STYLE = stringPreferencesKey("card_display_style")
        val USE_24_HOUR = booleanPreferencesKey("use_24_hour_format")
        val DATE_FORMAT = stringPreferencesKey("date_format_style")
        val WEEK_START = stringPreferencesKey("week_start_day")
        val DEFAULT_PRIORITY = stringPreferencesKey("default_task_priority")
        val DEFAULT_CATEGORY_ID = stringPreferencesKey("default_task_category_id")
        val DEFAULT_TASK_BOX = stringPreferencesKey("default_task_box_filter")
        val AUTO_ARCHIVE = booleanPreferencesKey("auto_archive_completed")
        val SHOW_OVERDUE_HOME = booleanPreferencesKey("show_overdue_on_home")
        val CONFIRM_DELETE = booleanPreferencesKey("confirm_before_delete")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val PIN_HASH = stringPreferencesKey("pin_hash")
    }

    val preferencesFlow: Flow<UserPreferences> = context.divamUserDataStore.data.map { prefs ->
        decode(prefs)
    }

    suspend fun getSnapshot(): UserPreferences = preferencesFlow.first()

    suspend fun update(transform: (UserPreferences) -> UserPreferences) {
        context.divamUserDataStore.edit { prefs ->
            val current = decode(prefs)
            val next = transform(current)
            writeToPrefs(prefs, next)
        }
    }

    suspend fun resetAppearanceSettings() {
        update { current ->
            current.copy(
                goldAccentsEnabled = true,
                fontScale = AppFontScale.NORMAL,
                cardDisplayStyle = CardDisplayStyle.COMFORTABLE
            )
        }
    }

    suspend fun resetAllPreferences(keepAvatar: Boolean = false) {
        context.divamUserDataStore.edit { prefs ->
            val existingAvatar = if (keepAvatar) prefs[Keys.AVATAR_PATH] else null
            prefs.clear()
            if (existingAvatar != null) {
                prefs[Keys.AVATAR_PATH] = existingAvatar
            }
        }
    }

    private fun decode(prefs: Preferences): UserPreferences {
        return UserPreferences(
            userName = prefs[Keys.USER_NAME]?.takeIf { it.isNotBlank() } ?: "Divam Kullanıcısı",
            avatarLocalPath = prefs[Keys.AVATAR_PATH]?.takeIf { it.isNotBlank() },
            dailyTaskGoal = (prefs[Keys.DAILY_GOAL] ?: 5).coerceIn(1, 50),
            weeklyTaskGoal = (prefs[Keys.WEEKLY_GOAL] ?: 25).coerceIn(1, 300),
            goldAccentsEnabled = prefs[Keys.GOLD_ACCENTS] ?: true,
            fontScale = AppFontScale.fromName(prefs[Keys.FONT_SCALE]),
            cardDisplayStyle = CardDisplayStyle.fromName(prefs[Keys.CARD_STYLE]),
            use24HourFormat = prefs[Keys.USE_24_HOUR] ?: true,
            dateFormatStyle = DateFormatStyle.fromName(prefs[Keys.DATE_FORMAT]),
            weekStartDay = WeekStartDay.fromName(prefs[Keys.WEEK_START]),
            defaultPriority = TaskPriority.fromName(prefs[Keys.DEFAULT_PRIORITY]),
            defaultCategoryId = prefs[Keys.DEFAULT_CATEGORY_ID]?.takeIf { it.isNotBlank() } ?: "cat_is",
            defaultTaskBoxFilter = TaskBoxFilter.entries.firstOrNull {
                it.name == prefs[Keys.DEFAULT_TASK_BOX]
            } ?: TaskBoxFilter.ACTIVE,
            autoArchiveCompleted = prefs[Keys.AUTO_ARCHIVE] ?: false,
            showOverdueOnHome = prefs[Keys.SHOW_OVERDUE_HOME] ?: true,
            confirmBeforeDelete = prefs[Keys.CONFIRM_DELETE] ?: true,
            appLockEnabled = prefs[Keys.APP_LOCK_ENABLED] ?: false,
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            pinSalt = prefs[Keys.PIN_SALT],
            pinHash = prefs[Keys.PIN_HASH]
        )
    }

    private fun writeToPrefs(
        prefs: androidx.datastore.preferences.core.MutablePreferences,
        next: UserPreferences
    ) {
        prefs[Keys.USER_NAME] = next.userName.trim().ifEmpty { "Divam Kullanıcısı" }
        if (next.avatarLocalPath.isNullOrBlank()) {
            prefs.remove(Keys.AVATAR_PATH)
        } else {
            prefs[Keys.AVATAR_PATH] = next.avatarLocalPath
        }
        prefs[Keys.DAILY_GOAL] = next.dailyTaskGoal.coerceIn(1, 50)
        prefs[Keys.WEEKLY_GOAL] = next.weeklyTaskGoal.coerceIn(1, 300)
        prefs[Keys.GOLD_ACCENTS] = next.goldAccentsEnabled
        prefs[Keys.FONT_SCALE] = next.fontScale.name
        prefs[Keys.CARD_STYLE] = next.cardDisplayStyle.name
        prefs[Keys.USE_24_HOUR] = next.use24HourFormat
        prefs[Keys.DATE_FORMAT] = next.dateFormatStyle.name
        prefs[Keys.WEEK_START] = next.weekStartDay.name
        prefs[Keys.DEFAULT_PRIORITY] = next.defaultPriority.name
        prefs[Keys.DEFAULT_CATEGORY_ID] = next.defaultCategoryId
        prefs[Keys.DEFAULT_TASK_BOX] = next.defaultTaskBoxFilter.name
        prefs[Keys.AUTO_ARCHIVE] = next.autoArchiveCompleted
        prefs[Keys.SHOW_OVERDUE_HOME] = next.showOverdueOnHome
        prefs[Keys.CONFIRM_DELETE] = next.confirmBeforeDelete
        prefs[Keys.APP_LOCK_ENABLED] = next.appLockEnabled
        prefs[Keys.BIOMETRIC_ENABLED] = next.biometricEnabled
        if (next.pinSalt.isNullOrBlank()) prefs.remove(Keys.PIN_SALT) else prefs[Keys.PIN_SALT] = next.pinSalt
        if (next.pinHash.isNullOrBlank()) prefs.remove(Keys.PIN_HASH) else prefs[Keys.PIN_HASH] = next.pinHash
    }
}
