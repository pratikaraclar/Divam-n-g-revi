package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

enum class ThemeMode(val storageKey: String, val turkishLabel: String, val turkishDescription: String) {
    DARK(
        storageKey = "dark",
        turkishLabel = "Koyu Tema",
        turkishDescription = "Obsidyen siyahı, koyu mor ve metalik altın gece görünümü"
    ),
    LIGHT(
        storageKey = "light",
        turkishLabel = "Açık Tema",
        turkishDescription = "Fildişi zemin üzerinde koyu mor ve parlak altın vurgular"
    ),
    SYSTEM(
        storageKey = "system",
        turkishLabel = "Sistem Varsayılanı",
        turkishDescription = "Cihazın sistem tema ayarını otomatik olarak izler"
    );

    companion object {
        fun fromKey(key: String?): ThemeMode =
            entries.firstOrNull { it.storageKey == key } ?: DARK
    }
}

@Immutable
data class DivamExtendedColors(
    val isDark: Boolean,
    val goldStart: Color,
    val goldMid: Color,
    val goldEnd: Color,
    val purpleAura: Color,
    val cardBorderGold: Color,
    val cardBorderSubtle: Color,
    val statusActive: Color,
    val statusPlanned: Color,
    val navBarSurface: Color,
    val navIndicatorFill: Color,
    val swatchBlack: Color,
    val swatchPurple: Color,
    val swatchGold: Color
) {
    val metallicGoldBrush: Brush
        get() = Brush.linearGradient(listOf(goldStart, goldMid, goldEnd))
}

private val DarkExtendedColors = DivamExtendedColors(
    isDark = true,
    goldStart = GoldHighlight,
    goldMid = GoldMetallic,
    goldEnd = GoldBurnished,
    purpleAura = ImperialPurpleVibrant.copy(alpha = 0.34f),
    cardBorderGold = GoldMetallic.copy(alpha = 0.42f),
    cardBorderSubtle = ImperialPurpleVibrant.copy(alpha = 0.45f),
    statusActive = StatusEmeraldDark,
    statusPlanned = StatusAmberDark,
    navBarSurface = ObsidianBase,
    navIndicatorFill = ImperialPurple,
    swatchBlack = ObsidianVoid,
    swatchPurple = ImperialPurple,
    swatchGold = GoldMetallic
)

private val LightExtendedColors = DivamExtendedColors(
    isDark = false,
    goldStart = GoldMetallic,
    goldMid = GoldBurnished,
    goldEnd = GoldAntique,
    purpleAura = ImperialPurpleSoft.copy(alpha = 0.14f),
    cardBorderGold = GoldBurnished.copy(alpha = 0.40f),
    cardBorderSubtle = ImperialPurple.copy(alpha = 0.14f),
    statusActive = StatusEmeraldLight,
    statusPlanned = StatusAmberLight,
    navBarSurface = PearlSurface,
    navIndicatorFill = GoldWashLight,
    swatchBlack = ObsidianInk,
    swatchPurple = ImperialPurpleVibrant,
    swatchGold = GoldBurnished
)

val LocalDivamExtendedColors = staticCompositionLocalOf { DarkExtendedColors }
val LocalUserPreferences = staticCompositionLocalOf { com.example.core.model.UserPreferences() }

private val DivamDarkColorScheme = darkColorScheme(
    primary = GoldMetallic,
    onPrimary = ObsidianVoid,
    primaryContainer = GoldWashDark,
    onPrimaryContainer = GoldHighlight,
    secondary = ImperialPurpleSoft,
    onSecondary = PearlSurface,
    secondaryContainer = ImperialPurple,
    onSecondaryContainer = LavenderMist,
    tertiary = GoldChampagne,
    onTertiary = ObsidianVoid,
    tertiaryContainer = ImperialPurpleDeep,
    onTertiaryContainer = GoldHighlight,
    background = ObsidianVoid,
    onBackground = PearlSurface,
    surface = ObsidianSurface,
    onSurface = PearlSurface,
    surfaceVariant = ObsidianSurfaceHigh,
    onSurfaceVariant = LavenderMuted,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = ObsidianBase,
    surfaceContainer = ObsidianSurface,
    surfaceContainerHigh = ObsidianSurfaceHigh,
    surfaceContainerHighest = ObsidianSurfaceHighest,
    outline = GoldBurnished.copy(alpha = 0.45f),
    outlineVariant = ImperialPurpleVibrant.copy(alpha = 0.38f),
    error = ErrorCrimsonDark,
    onError = ObsidianVoid
)

private val DivamLightColorScheme = lightColorScheme(
    primary = ImperialPurpleVibrant,
    onPrimary = PearlSurface,
    primaryContainer = LilacTintHigh,
    onPrimaryContainer = ImperialPurpleDeep,
    secondary = GoldBurnished,
    onSecondary = PearlSurface,
    secondaryContainer = GoldWashLight,
    onSecondaryContainer = ObsidianInk,
    tertiary = GoldAntique,
    onTertiary = PearlSurface,
    tertiaryContainer = GoldWashLight,
    onTertiaryContainer = GoldAntique,
    background = AlabasterCanvas,
    onBackground = ObsidianInk,
    surface = PearlSurface,
    onSurface = ObsidianInk,
    surfaceVariant = LilacTintSurface,
    onSurfaceVariant = PlumSlateInk,
    surfaceContainerLowest = PearlSurface,
    surfaceContainerLow = AlabasterCanvas,
    surfaceContainer = LilacTintSurface,
    surfaceContainerHigh = LilacTintHigh,
    surfaceContainerHighest = LilacTintHigh,
    outline = GoldBurnished.copy(alpha = 0.50f),
    outlineVariant = ImperialPurple.copy(alpha = 0.16f),
    error = ErrorCrimsonLight,
    onError = PearlSurface
)

val DivamShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

object DivamTheme {
    val extendedColors: DivamExtendedColors
        @Composable
        get() = LocalDivamExtendedColors.current

    val userPreferences: com.example.core.model.UserPreferences
        @Composable
        get() = LocalUserPreferences.current
}

@Composable
fun DivaminGoreviTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    userPreferences: com.example.core.model.UserPreferences = com.example.core.model.UserPreferences(),
    systemDarkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val useDarkTheme = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDarkTheme
    }

    val baseScheme = if (useDarkTheme) DivamDarkColorScheme else DivamLightColorScheme
    val colorScheme = if (userPreferences.goldAccentsEnabled) {
        baseScheme
    } else {
        baseScheme.copy(
            primary = ImperialPurpleSoft,
            secondary = ImperialPurpleVibrant,
            tertiary = LavenderMuted
        )
    }

    val baseExtended = if (useDarkTheme) DarkExtendedColors else LightExtendedColors
    val extendedColors = if (userPreferences.goldAccentsEnabled) {
        baseExtended
    } else {
        baseExtended.copy(
            goldStart = if (useDarkTheme) LavenderMist else ImperialPurpleVibrant,
            goldMid = if (useDarkTheme) ImperialPurpleSoft else ImperialPurple,
            goldEnd = if (useDarkTheme) ImperialPurpleVibrant else ImperialPurpleDeep,
            cardBorderGold = ImperialPurpleSoft.copy(alpha = 0.42f),
            swatchGold = ImperialPurpleSoft
        )
    }

    val typography = scaledDivamTypography(userPreferences.fontScale.multiplier)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !useDarkTheme
                controller.isAppearanceLightNavigationBars = !useDarkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalDivamExtendedColors provides extendedColors,
        LocalUserPreferences provides userPreferences
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = DivamShapes,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    DivaminGoreviTheme(
        themeMode = if (darkTheme) ThemeMode.DARK else ThemeMode.LIGHT,
        content = content
    )
}
