package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Marka Ana Renkleri: Siyah, Koyu Mor ve Metalik Altın ---

// Siyah / Obsidyen Tonları
val ObsidianVoid = Color(0xFF09080D)
val ObsidianBase = Color(0xFF0D0A13)
val ObsidianSurface = Color(0xFF14101E)
val ObsidianSurfaceHigh = Color(0xFF1C1629)
val ObsidianSurfaceHighest = Color(0xFF251D37)

// Koyu Mor Tonları
val ImperialPurpleDeep = Color(0xFF1E1236)
val ImperialPurple = Color(0xFF2F1B54)
val ImperialPurpleVibrant = Color(0xFF4C2B85)
val ImperialPurpleSoft = Color(0xFF6F48B5)
val LavenderMist = Color(0xFFD9C7F7)
val LavenderMuted = Color(0xFFA99BC2)

// Metalik Altın Tonları
val GoldHighlight = Color(0xFFF6DF95)
val GoldChampagne = Color(0xFFE7C766)
val GoldMetallic = Color(0xFFD4AF37)
val GoldBurnished = Color(0xFFB38B1F)
val GoldAntique = Color(0xFF8C6912)
val GoldWashDark = Color(0xFF2E2411)

// Açık Tema Yüzey ve Mürekkep Tonları
val AlabasterCanvas = Color(0xFFFAF7FD)
val PearlSurface = Color(0xFFFFFFFF)
val LilacTintSurface = Color(0xFFF3EDF9)
val LilacTintHigh = Color(0xFFEAE1F5)
val ObsidianInk = Color(0xFF130F1D)
val PlumSlateInk = Color(0xFF564B6B)
val GoldWashLight = Color(0xFFFBF1D3)

// Durum Renkleri
val StatusEmeraldDark = Color(0xFF5BD39A)
val StatusEmeraldLight = Color(0xFF157A4C)
val StatusAmberDark = Color(0xFFE6BE5A)
val StatusAmberLight = Color(0xFF9C6F0B)
val ErrorCrimsonDark = Color(0xFFF28B82)
val ErrorCrimsonLight = Color(0xFFB3261E)
