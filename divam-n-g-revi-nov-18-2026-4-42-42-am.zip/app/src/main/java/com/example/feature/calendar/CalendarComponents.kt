package com.example.feature.calendar

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.TaskCategory
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskStatus
import com.example.ui.theme.DivamTheme

@Composable
fun CalendarViewModeSwitcher(
    selectedMode: CalendarViewMode,
    onModeSelected: (CalendarViewMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, extended.cardBorderSubtle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CalendarViewMode.entries.forEach { mode ->
                val selected = mode == selectedMode
                Surface(
                    onClick = { onModeSelected(mode) },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("calendar_mode_${mode.name.lowercase()}"),
                    shape = RoundedCornerShape(10.dp),
                    color = if (selected) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        Color.Transparent
                    },
                    border = if (selected) {
                        BorderStroke(1.dp, extended.goldMid)
                    } else {
                        null
                    }
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode.turkishLabel,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) extended.goldStart else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarFilterBar(
    categories: List<TaskCategory>,
    selectedCategoryId: String?,
    selectedStatus: TaskStatus?,
    onCategorySelected: (String?) -> Unit,
    onStatusSelected: (TaskStatus?) -> Unit,
    onClearFilters: () -> Unit,
    onTodayClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val hasActiveFilter = selectedCategoryId != null || selectedStatus != null
    val extended = DivamTheme.extendedColors

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onTodayClick,
                modifier = Modifier.testTag("calendar_jump_today_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, extended.cardBorderGold)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Today,
                    contentDescription = null,
                    tint = extended.goldMid,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Bugün",
                    color = extended.goldMid,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            OutlinedButton(
                onClick = { expanded = !expanded },
                modifier = Modifier
                    .weight(1f)
                    .testTag("calendar_filter_toggle_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (hasActiveFilter || expanded) extended.goldMid else extended.cardBorderSubtle
                )
            ) {
                Icon(
                    imageVector = Icons.Rounded.FilterList,
                    contentDescription = null,
                    tint = if (hasActiveFilter) extended.goldMid else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (hasActiveFilter) "Filtre Aktif" else "Kategori & Durum Filtresi",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelMedium
                )
            }

            if (hasActiveFilter) {
                IconButton(
                    onClick = onClearFilters,
                    modifier = Modifier.testTag("calendar_clear_filters_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Clear,
                        contentDescription = "Filtreleri temizle",
                        tint = extended.goldMid
                    )
                }
            }
        }

        AnimatedVisibility(visible = expanded) {
            DivamCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Görev Durumu",
                    style = MaterialTheme.typography.labelMedium,
                    color = extended.goldMid
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TaskStatus.entries.forEach { status ->
                        val selected = selectedStatus == status
                        FilterChip(
                            selected = selected,
                            onClick = { onStatusSelected(if (selected) null else status) },
                            label = { Text(status.turkishLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                selectedLabelColor = extended.goldStart
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Kategori",
                    style = MaterialTheme.typography.labelMedium,
                    color = extended.goldMid
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEach { category ->
                        val selected = selectedCategoryId == category.id
                        FilterChip(
                            selected = selected,
                            onClick = { onCategorySelected(if (selected) null else category.id) },
                            label = { Text(category.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                selectedLabelColor = extended.goldStart
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DailyDensityCard(
    density: DayDensitySummary,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    DivamCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Günlük Görev Yoğunluğu",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Surface(
                shape = RoundedCornerShape(50),
                color = extended.goldMid.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, extended.cardBorderGold)
            ) {
                Text(
                    text = "${density.densityLabel} • ${density.totalCount} Görev",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = extended.goldMid,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DensityCountPill("Tamamlanan", density.completedCount, extended.statusActive, Modifier.weight(1f))
            DensityCountPill("Bekleyen", density.pendingCount, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            DensityCountPill("Ertelenen", density.postponedCount, extended.statusPlanned, Modifier.weight(1f))
            DensityCountPill("Yüksek", density.highPriorityCount, extended.goldMid, Modifier.weight(1f))
        }
    }
}

@Composable
fun WeeklyDensityCard(
    weekDensities: List<DayDensitySummary>,
    selectedDayMillis: Long,
    onSelectDay: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val maxLoad = (weekDensities.maxOfOrNull { it.totalCount } ?: 1).coerceAtLeast(1)
    val totalWeekTasks = weekDensities.sumOf { it.totalCount }

    DivamCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Haftalık Görev Yoğunluğu",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Toplam $totalWeekTasks görev",
                style = MaterialTheme.typography.labelMedium,
                color = extended.goldMid
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            weekDensities.forEach { day ->
                val isSelected = day.dayMillis == selectedDayMillis
                val ratio = if (day.totalCount == 0) 0.08f else (day.totalCount.toFloat() / maxLoad.toFloat()).coerceIn(0.2f, 1f)
                val barColor = when {
                    day.highPriorityCount > 0 -> extended.goldMid
                    day.totalCount > 0 -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outlineVariant
                }
                Surface(
                    onClick = { onSelectDay(day.dayMillis) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                    } else {
                        Color.Transparent
                    },
                    border = if (isSelected) BorderStroke(1.dp, extended.goldMid) else null
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = day.totalCount.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (day.totalCount > 0) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(14.dp)
                                .height(46.dp),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(12.dp)
                                    .fillMaxHeight(ratio)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(barColor)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = day.shortDayName,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) extended.goldStart else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DensityCountPill(
    label: String,
    count: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = accent.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TimeSlotClusterCard(
    cluster: TimeSlotCluster,
    isTabletOrWide: Boolean,
    onToggleComplete: (Long) -> Unit,
    onEditTask: (Long) -> Unit,
    onRescheduleTask: (TaskItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors

    DivamCard(
        modifier = modifier.fillMaxWidth(),
        highlightGoldBorder = cluster.hasOverlap
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Schedule,
                    contentDescription = null,
                    tint = extended.goldMid,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = cluster.slotLabel,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = extended.goldMid
                )
            }
            if (cluster.hasOverlap) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = extended.goldMid.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, extended.cardBorderGold)
                ) {
                    Text(
                        text = "Aynı Saatte ${cluster.tasks.size} Görev",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = extended.goldStart,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (isTabletOrWide && cluster.tasks.size > 1) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                cluster.tasks.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        pair.forEach { task ->
                            CalendarTaskCard(
                                task = task,
                                onToggleComplete = { onToggleComplete(task.id) },
                                onEdit = { onEditTask(task.id) },
                                onReschedule = { onRescheduleTask(task) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                cluster.tasks.forEach { task ->
                    CalendarTaskCard(
                        task = task,
                        onToggleComplete = { onToggleComplete(task.id) },
                        onEdit = { onEditTask(task.id) },
                        onReschedule = { onRescheduleTask(task) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarTaskCard(
    task: TaskItem,
    onToggleComplete: () -> Unit,
    onEdit: () -> Unit,
    onReschedule: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val isCompleted = task.status == TaskStatus.COMPLETED
    val isHighPriority = task.priority == TaskPriority.HIGH

    val statusColor = when (task.status) {
        TaskStatus.COMPLETED -> extended.statusActive
        TaskStatus.POSTPONED -> extended.statusPlanned
        TaskStatus.IN_PROGRESS -> extended.goldMid
        TaskStatus.CANCELLED -> MaterialTheme.colorScheme.error
        TaskStatus.PENDING -> MaterialTheme.colorScheme.primary
    }

    val containerColor = when {
        isCompleted -> MaterialTheme.colorScheme.surfaceContainerLow
        isHighPriority -> MaterialTheme.colorScheme.surfaceContainerHigh
        else -> MaterialTheme.colorScheme.surface
    }

    val borderColor = when {
        isHighPriority && !isCompleted -> extended.goldMid
        task.status == TaskStatus.POSTPONED -> extended.statusPlanned.copy(alpha = 0.55f)
        isCompleted -> extended.statusActive.copy(alpha = 0.45f)
        else -> extended.cardBorderSubtle
    }

    Surface(
        onClick = onEdit,
        modifier = modifier
            .fillMaxWidth()
            .testTag("calendar_task_card_${task.id}"),
        shape = RoundedCornerShape(14.dp),
        color = containerColor,
        border = BorderStroke(if (isHighPriority && !isCompleted) 1.5.dp else 1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
        ) {
            // Yüksek öncelik veya durum görsel şeridi
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(if (isHighPriority && !isCompleted) extended.goldMid else statusColor)
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onToggleComplete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (isCompleted) {
                                Icons.Rounded.CheckCircle
                            } else {
                                Icons.Outlined.RadioButtonUnchecked
                            },
                            contentDescription = "Tamamlandı durumunu değiştir",
                            tint = if (isCompleted) extended.statusActive else extended.goldMid
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                textDecoration = if (isCompleted) {
                                    TextDecoration.LineThrough
                                } else {
                                    TextDecoration.None
                                }
                            ),
                            color = if (isCompleted) {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            },
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (task.description.isNotBlank()) {
                            Text(
                                text = task.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CalendarMiniPill(text = task.status.turkishLabel, color = statusColor)
                    if (isHighPriority) {
                        CalendarMiniPill(
                            text = "Yüksek Öncelik",
                            color = extended.goldMid,
                            icon = Icons.Rounded.Flag
                        )
                    } else {
                        CalendarMiniPill(
                            text = task.priority.turkishLabel,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    CalendarMiniPill(
                        text = task.categoryName,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    val userPrefs = DivamTheme.userPreferences
                    val timePart = listOfNotNull(
                        task.startTimeMinutes?.let {
                            TaskDateTimeUtils.formatTimeMinutes(it, userPrefs.use24HourFormat)
                        },
                        task.endTimeMinutes?.let {
                            TaskDateTimeUtils.formatTimeMinutes(it, userPrefs.use24HourFormat)
                        }
                    ).joinToString(" - ")
                    if (timePart.isNotEmpty()) {
                        CalendarMiniPill(
                            text = timePart,
                            color = extended.goldStart,
                            icon = Icons.Rounded.Schedule
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onReschedule,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("calendar_reschedule_button_${task.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Update,
                            contentDescription = null,
                            tint = extended.goldMid,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tarih/Saat", color = extended.goldMid)
                    }
                    TextButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("calendar_edit_button_${task.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Düzenle")
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarMiniPill(
    text: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.13f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.38f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RescheduleTaskDialog(
    task: TaskItem,
    onDismiss: () -> Unit,
    onSave: (startDateMillis: Long?, endDateMillis: Long?, startTimeMinutes: Int?, endTimeMinutes: Int?) -> Unit
) {
    var startDate by remember(task.id) { mutableStateOf(task.startDateMillis) }
    var endDate by remember(task.id) { mutableStateOf(task.endDateMillis) }
    var startTime by remember(task.id) { mutableStateOf(task.startTimeMinutes) }
    var endTime by remember(task.id) { mutableStateOf(task.endTimeMinutes) }
    var errorText by remember { mutableStateOf<String?>(null) }

    var pickStartDate by remember { mutableStateOf(false) }
    var pickEndDate by remember { mutableStateOf(false) }
    var pickStartTime by remember { mutableStateOf(false) }
    var pickEndTime by remember { mutableStateOf(false) }

    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Tarih ve Saati Değiştir",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = extended.goldMid,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                RescheduleFieldRow(
                    label = "Başlangıç Tarihi",
                    value = startDate?.let {
                        TaskDateTimeUtils.formatDateTurkish(it, userPrefs.dateFormatStyle)
                    } ?: "Seçilmedi",
                    onPick = { pickStartDate = true },
                    onClear = if (startDate != null) {
                        { startDate = null; errorText = null }
                    } else null
                )
                RescheduleFieldRow(
                    label = "Bitiş Tarihi",
                    value = endDate?.let {
                        TaskDateTimeUtils.formatDateTurkish(it, userPrefs.dateFormatStyle)
                    } ?: "Seçilmedi",
                    onPick = { pickEndDate = true },
                    onClear = if (endDate != null) {
                        { endDate = null; errorText = null }
                    } else null
                )
                RescheduleFieldRow(
                    label = "Başlangıç Saati",
                    value = startTime?.let {
                        TaskDateTimeUtils.formatTimeMinutes(it, userPrefs.use24HourFormat)
                    } ?: "Seçilmedi",
                    onPick = { pickStartTime = true },
                    onClear = if (startTime != null) {
                        { startTime = null; errorText = null }
                    } else null
                )
                RescheduleFieldRow(
                    label = "Bitiş Saati",
                    value = endTime?.let {
                        TaskDateTimeUtils.formatTimeMinutes(it, userPrefs.use24HourFormat)
                    } ?: "Seçilmedi",
                    onPick = { pickEndTime = true },
                    onClear = if (endTime != null) {
                        { endTime = null; errorText = null }
                    } else null
                )

                if (errorText != null) {
                    Text(
                        text = errorText!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val validation = com.example.core.model.TaskScheduleValidator.validate(
                        title = task.title,
                        startDateMillis = startDate,
                        endDateMillis = endDate,
                        startTimeMinutes = startTime,
                        endTimeMinutes = endTime,
                        requireTitle = false
                    )
                    if (!validation.isValid) {
                        errorText = validation.scheduleError
                    } else {
                        onSave(startDate, endDate, startTime, endTime)
                    }
                }
            ) {
                Text("Kaydet", color = extended.goldMid, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Vazgeç")
            }
        }
    )

    if (pickStartDate || pickEndDate) {
        val isStart = pickStartDate
        val initial = (if (isStart) startDate else endDate ?: startDate)
            ?: TaskDateTimeUtils.todayLocalDayMillis()
        val state = rememberDatePickerState(
            initialSelectedDateMillis = TaskDateTimeUtils.localDayMillisToUtcPickerMillis(initial)
        )
        DatePickerDialog(
            onDismissRequest = { pickStartDate = false; pickEndDate = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { utc ->
                            val local = TaskDateTimeUtils.utcPickerMillisToLocalDayMillis(utc)
                            if (isStart) {
                                startDate = local
                                if (endDate != null && endDate!! < local) endDate = local
                            } else {
                                endDate = local
                            }
                            errorText = null
                        }
                        pickStartDate = false
                        pickEndDate = false
                    }
                ) {
                    Text("Seç", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { pickStartDate = false; pickEndDate = false }) {
                    Text("İptal")
                }
            }
        ) {
            DatePicker(state = state)
        }
    }

    if (pickStartTime || pickEndTime) {
        val isStart = pickStartTime
        val initMins = (if (isStart) startTime else endTime ?: startTime) ?: (9 * 60)
        val timeState = rememberTimePickerState(
            initialHour = initMins / 60,
            initialMinute = initMins % 60,
            is24Hour = userPrefs.use24HourFormat
        )
        AlertDialog(
            onDismissRequest = { pickStartTime = false; pickEndTime = false },
            title = { Text(if (isStart) "Başlangıç Saati" else "Bitiş Saati") },
            text = {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TimePicker(state = timeState)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val mins = timeState.hour * 60 + timeState.minute
                        if (isStart) startTime = mins else endTime = mins
                        errorText = null
                        pickStartTime = false
                        pickEndTime = false
                    }
                ) {
                    Text("Tamam", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { pickStartTime = false; pickEndTime = false }) {
                    Text("İptal")
                }
            }
        )
    }
}

@Composable
private fun RescheduleFieldRow(
    label: String,
    value: String,
    onPick: () -> Unit,
    onClear: (() -> Unit)?
) {
    Surface(
        onClick = onPick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, DivamTheme.extendedColors.cardBorderSubtle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            if (onClear != null) {
                IconButton(onClick = onClear, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.Clear,
                        contentDescription = "$label temizle",
                        modifier = Modifier.size(16.dp)
                    )
                }
            } else {
                Icon(
                    imageVector = Icons.Rounded.CalendarToday,
                    contentDescription = null,
                    tint = DivamTheme.extendedColors.goldMid,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
