package com.example.feature.notifications

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryAlert
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SettingsApplications
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.ChannelSystemInspection
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationDeliveryStatus
import com.example.core.model.NotificationHistoryItem
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationSoundCatalog
import com.example.core.model.NotificationSoundOption
import com.example.core.model.TaskDateTimeUtils
import com.example.ui.theme.DivamTheme

@Composable
fun PermissionAndSystemCard(
    hasPostPermission: Boolean,
    canExactAlarm: Boolean,
    scheduledCount: Int,
    onRequestPostPermission: () -> Unit,
    onOpenExactAlarmSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAppNotificationSettings: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (hasPostPermission) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
                    contentDescription = null,
                    tint = if (hasPostPermission) extended.statusActive else extended.statusPlanned
                )
                Text(
                    text = "Sistem İzinleri ve Arka Plan",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = "$scheduledCount planlı alarm",
                style = MaterialTheme.typography.labelMedium,
                color = extended.goldMid
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = if (hasPostPermission) {
                "Bildirim izni etkin. Planlanan alarmlar cihaz yeniden başlatıldığında otomatik yeniden kurulur."
            } else {
                "Görev hatırlatmalarının görünebilmesi için Android bildirim iznine ihtiyaç vardır."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(10.dp))

        if (!hasPostPermission) {
            Button(
                onClick = onRequestPostPermission,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("notifications_request_permission_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.NotificationsActive, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bildirim İzni Ver", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onOpenExactAlarmSettings,
                modifier = Modifier
                    .weight(1f)
                    .testTag("notifications_exact_alarm_settings_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (canExactAlarm) extended.cardBorderSubtle else extended.statusPlanned
                )
            ) {
                Text(
                    text = if (canExactAlarm) "Tam Zamanlı Alarm: Açık" else "Tam Zamanlı Alarm İzni",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            OutlinedButton(
                onClick = onOpenBatterySettings,
                modifier = Modifier
                    .weight(1f)
                    .testTag("notifications_battery_settings_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.BatteryAlert,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Pil Ayarı",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        TextButton(
            onClick = onOpenAppNotificationSettings,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("notifications_device_settings_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.SettingsApplications,
                contentDescription = null,
                tint = extended.goldMid,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Cihazın Bildirim Ayarlarını Aç", color = extended.goldMid)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SoundAndChannelStudioCard(
    settings: NotificationSettings,
    selectedChannelKind: NotificationChannelKind,
    availableSounds: List<NotificationSoundOption>,
    playingSoundId: String?,
    inspections: List<ChannelSystemInspection>,
    onSelectChannelKind: (NotificationChannelKind) -> Unit,
    onGlobalSoundChange: (Boolean) -> Unit,
    onGlobalVibrationChange: (Boolean) -> Unit,
    onGlobalSilentChange: (Boolean) -> Unit,
    onCompletionSoundChange: (Boolean) -> Unit,
    onSelectChannelSound: (NotificationChannelKind, String) -> Unit,
    onChannelSoundToggle: (NotificationChannelKind, Boolean) -> Unit,
    onChannelVibrationToggle: (NotificationChannelKind, Boolean) -> Unit,
    onChannelSilentToggle: (NotificationChannelKind, Boolean) -> Unit,
    onPlayPreview: (String) -> Unit,
    onPlayCompletionPreview: () -> Unit,
    onStopPreview: () -> Unit,
    onOpenChannelSettings: (String) -> Unit,
    onResetSounds: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    val channelCfg = settings.channelConfigFor(selectedChannelKind)
    val inspection = inspections.firstOrNull { it.kind == selectedChannelKind }

    DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.VolumeUp, contentDescription = null, tint = extended.goldMid)
                Text(
                    text = "Sesler, Titreşim ve Kanallar",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            TextButton(
                onClick = onResetSounds,
                modifier = Modifier.testTag("notifications_reset_sounds_button")
            ) {
                Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Varsayılan")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        SettingSwitchRow(
            title = "Bildirim Sesi",
            subtitle = "Tüm bildirim kanalları için genel ses anahtarı",
            checked = settings.soundEnabled,
            onCheckedChange = onGlobalSoundChange,
            testTag = "switch_global_sound"
        )
        SettingSwitchRow(
            title = "Bildirim Titreşimi",
            subtitle = "Bildirim geldiğinde titreşim geri bildirimi",
            checked = settings.vibrationEnabled,
            onCheckedChange = onGlobalVibrationChange,
            testTag = "switch_global_vibration"
        )
        SettingSwitchRow(
            title = "Sessiz Bildirim Modu",
            subtitle = "Bildirimleri ses ve titreşim olmadan göster",
            checked = settings.silentNotificationMode,
            onCheckedChange = onGlobalSilentChange,
            testTag = "switch_global_silent"
        )
        SettingSwitchRow(
            title = "Görev Tamamlama Sesi",
            subtitle = "Görev tamamlandı işaretlendiğinde kısa ses çal",
            checked = settings.completionSoundEnabled,
            onCheckedChange = onCompletionSoundChange,
            testTag = "switch_completion_sound"
        )
        val isCompletionPlaying = playingSoundId == com.example.core.notifications.TaskSoundManager.ID_COMPLETION_SOUND
        TextButton(
            onClick = { if (isCompletionPlaying) onStopPreview() else onPlayCompletionPreview() },
            modifier = Modifier.testTag("sound_test_completion_button")
        ) {
            Icon(
                imageVector = if (isCompletionPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                contentDescription = null,
                tint = extended.goldMid,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isCompletionPlaying) "Tamamlama Sesini Durdur" else "Tamamlama Sesini Dinle",
                color = extended.goldMid
            )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

        Text(
            text = "Kanal Bazlı Ses Ayarı",
            style = MaterialTheme.typography.titleSmall,
            color = extended.goldMid
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            NotificationChannelKind.entries.forEach { kind ->
                FilterChip(
                    selected = kind == selectedChannelKind,
                    onClick = { onSelectChannelKind(kind) },
                    label = { Text(kind.turkishTitle, maxLines = 1) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        selectedLabelColor = extended.goldStart
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        SettingSwitchRow(
            title = "${selectedChannelKind.turkishTitle} Sesi",
            subtitle = null,
            checked = channelCfg.soundEnabled,
            onCheckedChange = { onChannelSoundToggle(selectedChannelKind, it) }
        )
        SettingSwitchRow(
            title = "${selectedChannelKind.turkishTitle} Titreşimi",
            subtitle = null,
            checked = channelCfg.vibrationEnabled,
            onCheckedChange = { onChannelVibrationToggle(selectedChannelKind, it) }
        )
        SettingSwitchRow(
            title = "Bu Kanalı Sessize Al",
            subtitle = null,
            checked = channelCfg.silentMode,
            onCheckedChange = { onChannelSilentToggle(selectedChannelKind, it) }
        )

        if (inspection != null) {
            val activeChannelId = inspection.activeChannelId
            if (inspection.blockedBySystem || !inspection.systemSoundMatchesSelected || !inspection.systemVibrationMatchesSelected) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = extended.statusPlanned.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, extended.statusPlanned.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = if (inspection.blockedBySystem) {
                                "Bu bildirim kanalı cihaz ayarlarından engellenmiş görünüyor."
                            } else {
                                "Android kanal ayarları sistem tarafından kilitlenmiş olabilir; gerekirse cihaz kanal ayarından da onaylayın."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        TextButton(onClick = { onOpenChannelSettings(activeChannelId) }) {
                            Text("Cihaz Kanal Ayarını Aç", color = extended.goldMid)
                        }
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(4.dp))
                TextButton(
                    onClick = { onOpenChannelSettings(activeChannelId) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "${selectedChannelKind.turkishTitle} Cihaz Kanal Ayarını Aç",
                        color = extended.goldMid,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        val selectedSoundLabel = NotificationSoundCatalog.labelForSoundId(channelCfg.soundId, availableSounds)
        val isSelectedSoundPlaying = playingSoundId == channelCfg.soundId
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Bildirim Sesi Seç ve Dinle ($selectedSoundLabel)",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Önizleme medya sesi üzerinden çalar; telefon sessiz veya titreşim modundayken bile seçili sesi duyabilirsiniz.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                if (isSelectedSoundPlaying) onStopPreview() else onPlayPreview(channelCfg.soundId)
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("sound_studio_test_selected_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isSelectedSoundPlaying) {
                    MaterialTheme.colorScheme.secondaryContainer
                } else {
                    extended.goldMid
                },
                contentColor = if (isSelectedSoundPlaying) {
                    extended.goldStart
                } else {
                    MaterialTheme.colorScheme.onPrimary
                }
            )
        ) {
            Icon(
                imageVector = if (isSelectedSoundPlaying) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isSelectedSoundPlaying) {
                    "Ses Önizlemesini Durdur"
                } else {
                    "Seçili Sesi Test Et ($selectedSoundLabel)"
                },
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            availableSounds.forEach { sound ->
                val isSelected = channelCfg.soundId == sound.id
                val isPlaying = playingSoundId == sound.id
                Surface(
                    onClick = { onSelectChannelSound(selectedChannelKind, sound.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("sound_option_${sound.id}"),
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerLow
                    },
                    border = BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) extended.goldMid else extended.cardBorderSubtle
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MusicNote,
                            contentDescription = null,
                            tint = if (isSelected) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = sound.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = sound.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = {
                                if (isPlaying) onStopPreview() else onPlayPreview(sound.id)
                            },
                            modifier = Modifier.testTag("sound_preview_toggle_${sound.id}")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                contentDescription = if (isPlaying) "Önizlemeyi durdur" else "${sound.title} sesini dinle",
                                tint = extended.goldMid
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String? = null
) {
    val extended = DivamTheme.extendedColors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = extended.goldMid
            ),
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
fun NotificationHistoryCard(
    history: List<NotificationHistoryItem>,
    use24Hour: Boolean,
    onClearHistory: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    DivamCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.History, contentDescription = null, tint = extended.goldMid)
                Text(
                    text = "Bildirim Geçmişi (${history.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            if (history.isNotEmpty()) {
                TextButton(
                    onClick = onClearHistory,
                    modifier = Modifier.testTag("notifications_clear_history_button")
                ) {
                    Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Temizle")
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (history.isEmpty()) {
            Text(
                text = "Henüz gönderilmiş veya test edilmiş bildirim kaydı bulunmuyor.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                history.take(30).forEach { item ->
                    val statusColor = when (item.deliveryStatus) {
                        NotificationDeliveryStatus.SENT -> extended.statusActive
                        NotificationDeliveryStatus.SENT_SILENT -> extended.goldMid
                        NotificationDeliveryStatus.SUPPRESSED_QUIET_HOURS -> MaterialTheme.colorScheme.primary
                        NotificationDeliveryStatus.SKIPPED_NO_PERMISSION -> MaterialTheme.colorScheme.error
                        NotificationDeliveryStatus.CANCELLED -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, extended.cardBorderSubtle)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = item.deliveryStatus.turkishLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${item.type.turkishLabel} • ${TaskDateTimeUtils.formatDateTimeTurkish(item.triggeredAtMillis, use24Hour)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = extended.goldMid
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationTimePickerDialog(
    title: String,
    initialMinutes: Int,
    is24Hour: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val extended = DivamTheme.extendedColors
    val state = rememberTimePickerState(
        initialHour = (initialMinutes / 60).coerceIn(0, 23),
        initialMinute = (initialMinutes % 60).coerceIn(0, 59),
        is24Hour = is24Hour
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                TimePicker(state = state)
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) {
                Text("Kaydet", color = extended.goldMid, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}
