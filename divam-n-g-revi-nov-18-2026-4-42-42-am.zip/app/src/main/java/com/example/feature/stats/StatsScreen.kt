package com.example.feature.stats

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TrendingDown
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.designsystem.components.DivamSectionTitle
import com.example.core.model.ModuleReadiness
import com.example.core.model.TaskCategory
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskStatus
import com.example.core.model.UserPreferences
import com.example.core.model.WindowWidthClass
import com.example.ui.theme.DivamTheme

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StatsScreen(
    widthClass: WindowWidthClass,
    tasks: List<TaskItem>,
    categories: List<TaskCategory>,
    userPreferences: UserPreferences,
    modifier: Modifier = Modifier
) {
    var rangePreset by remember { mutableStateOf(StatsDateRangePreset.LAST_7_DAYS) }
    var customStartDay by remember {
        mutableStateOf<Long?>(
            TaskDateTimeUtils.addDaysToLocalDayMillis(TaskDateTimeUtils.todayLocalDayMillis(), -6)
        )
    }
    var customEndDay by remember { mutableStateOf<Long?>(TaskDateTimeUtils.todayLocalDayMillis()) }
    var categoryFilterId by remember { mutableStateOf<String?>(null) }
    var refreshNonce by remember { mutableIntStateOf(0) }
    var pickCustomDateKind by remember { mutableStateOf<Int?>(null) } // 1=start, 2=end

    val todayDayMillis = remember(refreshNonce) { TaskDateTimeUtils.todayLocalDayMillis() }

    val snapshot = remember(
        tasks,
        todayDayMillis,
        rangePreset,
        customStartDay,
        customEndDay,
        categoryFilterId,
        userPreferences.weekStartDay,
        userPreferences.dailyTaskGoal,
        userPreferences.weeklyTaskGoal,
        refreshNonce
    ) {
        StatsCalculator.calculate(
            allTasks = tasks,
            todayDayMillis = todayDayMillis,
            rangePreset = rangePreset,
            customStartDayMillis = customStartDay,
            customEndDayMillis = customEndDay,
            categoryFilterId = categoryFilterId,
            weekStartDay = userPreferences.weekStartDay,
            dailyGoalTarget = userPreferences.dailyTaskGoal,
            weeklyGoalTarget = userPreferences.weeklyTaskGoal
        )
    }

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp
    val extended = DivamTheme.extendedColors

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_istatistikler"),
        contentPadding = PaddingValues(
            start = horizontalPadding,
            end = horizontalPadding,
            top = 16.dp,
            bottom = 32.dp
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 1100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DivamSectionTitle(
                        title = "İstatistikler ve Raporlar",
                        subtitle = "Yalnızca gerçek görev kayıtlarından hesaplanır",
                        badge = ModuleReadiness.ACTIVE,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { refreshNonce++ },
                        modifier = Modifier.testTag("stats_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "İstatistikleri yenile",
                            tint = extended.goldMid
                        )
                    }
                }

                // Tarih Aralığı & Kategori Rapor Filtresi
                DivamCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Rapor Dönemi ve Kategori",
                        style = MaterialTheme.typography.titleSmall,
                        color = extended.goldMid
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(StatsDateRangePreset.entries) { preset ->
                            FilterChip(
                                selected = rangePreset == preset,
                                onClick = { rangePreset = preset },
                                label = { Text(preset.turkishLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor = extended.goldStart
                                ),
                                modifier = Modifier.testTag("stats_preset_${preset.name.lowercase()}")
                            )
                        }
                    }

                    if (rangePreset == StatsDateRangePreset.CUSTOM) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { pickCustomDateKind = 1 },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "Başlangıç: ${
                                        TaskDateTimeUtils.formatDateTurkish(
                                            snapshot.rangeStartMillis,
                                            userPreferences.dateFormatStyle
                                        )
                                    }",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1
                                )
                            }
                            OutlinedButton(
                                onClick = { pickCustomDateKind = 2 },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "Bitiş: ${
                                        TaskDateTimeUtils.formatDateTurkish(
                                            snapshot.rangeEndMillis,
                                            userPreferences.dateFormatStyle
                                        )
                                    }",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = categoryFilterId == null,
                                onClick = { categoryFilterId = null },
                                label = { Text("Tüm Kategoriler") }
                            )
                        }
                        items(categories, key = { it.id }) { cat ->
                            FilterChip(
                                selected = categoryFilterId == cat.id,
                                onClick = {
                                    categoryFilterId = if (categoryFilterId == cat.id) null else cat.id
                                },
                                label = { Text(cat.name) }
                            )
                        }
                    }
                }

                // Günlük Anlık Metrikler (1, 2, 3, 6)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatsKpiTile(
                        title = "Bugün Tamamlanan",
                        value = snapshot.dailyCompletedCount.toString(),
                        subtitle = "%${snapshot.dailyCompletionPercent} günlük oran",
                        accent = extended.statusActive,
                        icon = Icons.Rounded.CheckCircle,
                        modifier = Modifier.weight(1f)
                    )
                    StatsKpiTile(
                        title = "Bugün Bekleyen",
                        value = snapshot.dailyPendingCount.toString(),
                        subtitle = "Aktif planlı görev",
                        accent = MaterialTheme.colorScheme.primary,
                        icon = Icons.Rounded.Schedule,
                        modifier = Modifier.weight(1f)
                    )
                    StatsKpiTile(
                        title = "Geciken",
                        value = snapshot.dailyOverdueCount.toString(),
                        subtitle = "Vadesi geçmiş",
                        accent = extended.statusPlanned,
                        icon = Icons.Rounded.WarningAmber,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Haftalık & Aylık Özet + Dönem Karşılaştırma (4, 5, 7, 8, 15, 16)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ComparisonSummaryCard(
                        title = "Bu Hafta Tamamlanan",
                        completedCount = snapshot.weeklyCompletedCount,
                        percent = snapshot.weeklyCompletionPercent,
                        comparison = snapshot.weekComparison,
                        prevLabel = "önceki haftaya göre",
                        modifier = Modifier.weight(1f)
                    )
                    ComparisonSummaryCard(
                        title = "Bu Ay Tamamlanan",
                        completedCount = snapshot.monthlyCompletedCount,
                        percent = snapshot.monthlyCompletionPercent,
                        comparison = snapshot.monthComparison,
                        prevLabel = "önceki aya göre",
                        modifier = Modifier.weight(1f)
                    )
                }

                // Günlük & Haftalık Hedef Takibi (17, 18)
                DivamCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Kişisel Görev Hedefi Takibi",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    GoalBarRow(
                        label = "Günlük Hedef",
                        goal = snapshot.dailyGoal,
                        accent = extended.goldMid
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    GoalBarRow(
                        label = "Haftalık Hedef",
                        goal = snapshot.weeklyGoal,
                        accent = MaterialTheme.colorScheme.primary
                    )
                }

                if (snapshot.totalActiveRecords == 0) {
                    DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
                        Icon(
                            imageVector = Icons.Rounded.Insights,
                            contentDescription = null,
                            tint = extended.goldMid
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Henüz İstatistik İçin Görev Verisi Yok",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sahte veya tahmini veri üretilmez. Görev ekleyip tamamladıkça çizgi, sütun ve halka grafikleri gerçek kayıtlarla güncellenir.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    // Halka Grafik (11)
                    CompletionDonutChartCard(
                        completedCount = snapshot.rangeCompletedCount,
                        incompleteCount = snapshot.rangeIncompleteCount,
                        cancelledCount = snapshot.rangeCancelledCount,
                        completionPercent = snapshot.rangeCompletionPercent
                    )

                    // Çizgi Grafik (12) + Sütun Grafikler (13, 14)
                    DailyProgressLineChartCard(series = snapshot.dailyProgressSeries)

                    if (widthClass.isTabletOrWide) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            PerformanceColumnChartCard(
                                title = "Haftalık Performans",
                                subtitle = "Sütun Grafik",
                                bars = snapshot.weeklyPerformanceBars,
                                modifier = Modifier.weight(1f)
                            )
                            PerformanceColumnChartCard(
                                title = "Aylık Performans",
                                subtitle = "Haftalık Dilimler",
                                bars = snapshot.monthlyPerformanceBars,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        PerformanceColumnChartCard(
                            title = "Haftalık Performans",
                            subtitle = "Sütun Grafik",
                            bars = snapshot.weeklyPerformanceBars
                        )
                        PerformanceColumnChartCard(
                            title = "Aylık Performans",
                            subtitle = "Haftalık Dilimler",
                            bars = snapshot.monthlyPerformanceBars
                        )
                    }

                    // Kategori (9) & Öncelik Dağılımı (10)
                    CategoriesAndPrioritiesCard(
                        topCategories = snapshot.topCategories,
                        priorities = snapshot.priorityDistribution,
                        totalInRange = snapshot.rangeFilteredTotalCount
                    )

                    // En Verimli Günler (19)
                    if (snapshot.mostProductiveDays.isNotEmpty()) {
                        DivamCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Rounded.EmojiEvents, contentDescription = null, tint = extended.goldMid)
                                Text(
                                    text = "En Verimli Günler",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                snapshot.mostProductiveDays.forEachIndexed { idx, day ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${idx + 1}. ${day.dateLabel}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${day.completedCount} görev tamamlandı",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = extended.goldMid,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Görev Geçmişi (20)
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.History, contentDescription = null, tint = extended.goldMid)
                            Text(
                                text = "Görev Geçmişi (${snapshot.historyFeed.size})",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        if (snapshot.historyFeed.isEmpty()) {
                            Text(
                                text = "Seçilen tarih aralığı veya kategori için görev kaydı bulunmuyor.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                snapshot.historyFeed.take(15).forEach { task ->
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                                        border = BorderStroke(1.dp, extended.cardBorderSubtle)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = task.title,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                val refDate = task.completedAtMillis?.let {
                                                    TaskDateTimeUtils.formatDateTimeTurkish(
                                                        it,
                                                        userPreferences.use24HourFormat
                                                    )
                                                } ?: task.startDateMillis?.let {
                                                    TaskDateTimeUtils.formatDateTurkish(
                                                        it,
                                                        userPreferences.dateFormatStyle
                                                    )
                                                } ?: ""
                                                Text(
                                                    text = "${task.categoryName} • $refDate",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1
                                                )
                                            }
                                            Text(
                                                text = task.status.turkishLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (task.status == TaskStatus.COMPLETED) {
                                                    extended.statusActive
                                                } else {
                                                    extended.goldMid
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pickCustomDateKind?.let { target ->
        val initLocal = if (target == 1) customStartDay else customEndDay
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = TaskDateTimeUtils.localDayMillisToUtcPickerMillis(
                initLocal ?: todayDayMillis
            )
        )
        DatePickerDialog(
            onDismissRequest = { pickCustomDateKind = null },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let { utc ->
                            val local = TaskDateTimeUtils.utcPickerMillisToLocalDayMillis(utc)
                            if (target == 1) customStartDay = local else customEndDay = local
                        }
                        pickCustomDateKind = null
                    }
                ) {
                    Text("Seç", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { pickCustomDateKind = null }) { Text("İptal") }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
private fun StatsKpiTile(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    DivamCard(modifier = modifier.fillMaxWidth()) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = accent
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ComparisonSummaryCard(
    title: String,
    completedCount: Int,
    percent: Int,
    comparison: PeriodComparison,
    prevLabel: String,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val isUp = comparison.deltaCount >= 0
    val deltaPrefix = if (comparison.deltaCount > 0) "+" else ""
    val deltaDetail = if (comparison.deltaPercent != null) {
        "$deltaPrefix${comparison.deltaCount} (%$deltaPrefix${comparison.deltaPercent})"
    } else {
        "$deltaPrefix${comparison.deltaCount} görev"
    }

    DivamCard(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = completedCount.toString(),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = extended.goldMid
            )
            Text(
                text = "%$percent",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (isUp) Icons.Rounded.TrendingUp else Icons.Rounded.TrendingDown,
                contentDescription = null,
                tint = if (isUp) extended.statusActive else MaterialTheme.colorScheme.error,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "$deltaDetail $prevLabel",
                style = MaterialTheme.typography.labelSmall,
                color = if (isUp) extended.statusActive else MaterialTheme.colorScheme.error,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GoalBarRow(label: String, goal: GoalProgress, accent: Color) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${goal.completed} / ${goal.target} (%${goal.percent})",
                style = MaterialTheme.typography.labelLarge,
                color = accent
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { goal.ratio },
            color = accent,
            trackColor = MaterialTheme.colorScheme.surfaceContainerLow,
            strokeCap = StrokeCap.Round,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
        )
    }
}

@Composable
private fun CategoriesAndPrioritiesCard(
    topCategories: List<CategoryStatItem>,
    priorities: List<PriorityStatItem>,
    totalInRange: Int
) {
    val extended = DivamTheme.extendedColors
    DivamCard(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "En Çok Kullanılan Kategoriler",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        if (topCategories.isEmpty()) {
            Text(
                text = "Seçili dönemde kategori verisi yok.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            val safeTotal = totalInRange.coerceAtLeast(1)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                topCategories.take(6).forEach { cat ->
                    val ratio = (cat.totalCount.toFloat() / safeTotal.toFloat()).coerceIn(0f, 1f)
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = cat.categoryName,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${cat.completedCount}/${cat.totalCount} tamamlandı",
                                style = MaterialTheme.typography.labelMedium,
                                color = extended.goldMid
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { ratio },
                            color = extended.goldMid,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerLow,
                            strokeCap = StrokeCap.Round,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Öncelik Seviyelerine Göre Dağılım",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        val safeTotal = totalInRange.coerceAtLeast(1)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            priorities.forEach { item ->
                val ratio = (item.totalCount.toFloat() / safeTotal.toFloat()).coerceIn(0f, 1f)
                val barColor = if (item.priority == TaskPriority.HIGH) {
                    extended.goldMid
                } else {
                    MaterialTheme.colorScheme.primary
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = item.priority.turkishLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.widthIn(min = 66.dp)
                    )
                    LinearProgressIndicator(
                        progress = { ratio },
                        color = barColor,
                        trackColor = MaterialTheme.colorScheme.surfaceContainerLow,
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .weight(1f)
                            .height(8.dp)
                    )
                    Text(
                        text = "${item.totalCount} (${item.completedCount} ✓)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
