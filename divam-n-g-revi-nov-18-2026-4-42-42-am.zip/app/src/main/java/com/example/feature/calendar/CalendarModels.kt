package com.example.feature.calendar

import androidx.compose.runtime.Immutable
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskStatus
import com.example.core.model.WeekStartDay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class CalendarViewMode(val turkishLabel: String) {
    DAILY("Günlük"),
    WEEKLY("Haftalık"),
    MONTHLY("Aylık")
}

@Immutable
data class CalendarDayCell(
    val dayOfMonth: Int,
    val year: Int,
    val month: Int,
    val dayMillis: Long,
    val isToday: Boolean,
    val isSelected: Boolean,
    val taskCount: Int,
    val hasHighPriority: Boolean,
    val hasCompleted: Boolean,
    val hasPending: Boolean,
    val hasPostponed: Boolean
)

@Immutable
data class DayDensitySummary(
    val dayMillis: Long,
    val shortDayName: String,
    val dayNumber: Int,
    val totalCount: Int,
    val completedCount: Int,
    val pendingCount: Int,
    val postponedCount: Int,
    val highPriorityCount: Int
) {
    val densityLabel: String
        get() = when {
            totalCount == 0 -> "Boş"
            totalCount <= 2 -> "Hafif"
            totalCount <= 4 -> "Orta"
            else -> "Yoğun"
        }
}

@Immutable
data class TimeSlotCluster(
    val slotLabel: String,
    val startMinutes: Int,
    val tasks: List<TaskItem>
) {
    val hasOverlap: Boolean
        get() = tasks.size > 1
}

@Immutable
data class DailyScheduleBreakdown(
    val timedClusters: List<TimeSlotCluster>,
    val untimedTasks: List<TaskItem>
)

object CalendarLogic {
    private val trLocale: Locale = Locale.forLanguageTag("tr-TR")

    fun filterTasksForCalendar(
        tasks: List<TaskItem>,
        categoryFilterId: String?,
        statusFilter: TaskStatus?
    ): List<TaskItem> {
        return tasks.filter { task ->
            if (task.isDeleted || task.isArchived) return@filter false
            if (categoryFilterId != null && task.categoryId != categoryFilterId) return@filter false
            if (statusFilter != null && task.status != statusFilter) return@filter false
            true
        }
    }

    fun tasksForDay(tasks: List<TaskItem>, dayMillis: Long): List<TaskItem> {
        return tasks
            .filter { TaskDateTimeUtils.isTaskOnDay(it, dayMillis) }
            .sortedWith(
                compareBy<TaskItem>(
                    { it.startTimeMinutes ?: Int.MAX_VALUE },
                    { -it.priority.sortWeight },
                    { it.createdAtMillis }
                )
            )
    }

    fun buildDailySchedule(
        tasksForDay: List<TaskItem>,
        use24HourFormat: Boolean = true
    ): DailyScheduleBreakdown {
        val timed = tasksForDay
            .filter { it.startTimeMinutes != null }
            .sortedWith(
                compareBy<TaskItem>(
                    { it.startTimeMinutes!! },
                    { it.endTimeMinutes ?: (it.startTimeMinutes!! + 60) },
                    { -it.priority.sortWeight }
                )
            )
        val untimed = tasksForDay.filter { it.startTimeMinutes == null }

        if (timed.isEmpty()) {
            return DailyScheduleBreakdown(timedClusters = emptyList(), untimedTasks = untimed)
        }

        // Çakışan veya aynı saate denk gelen görevleri kümelendir
        val clusters = mutableListOf<TimeSlotCluster>()
        var currentGroup = mutableListOf<TaskItem>()
        var groupStart = timed.first().startTimeMinutes!!
        var groupMaxEnd = effectiveEndMinutes(timed.first())

        for (task in timed) {
            val taskStart = task.startTimeMinutes!!
            val taskEnd = effectiveEndMinutes(task)
            if (currentGroup.isEmpty()) {
                currentGroup.add(task)
                groupStart = taskStart
                groupMaxEnd = taskEnd
            } else if (taskStart == groupStart || taskStart < groupMaxEnd) {
                currentGroup.add(task)
                if (taskEnd > groupMaxEnd) {
                    groupMaxEnd = taskEnd
                }
            } else {
                clusters.add(buildCluster(groupStart, groupMaxEnd, currentGroup, use24HourFormat))
                currentGroup = mutableListOf(task)
                groupStart = taskStart
                groupMaxEnd = taskEnd
            }
        }
        if (currentGroup.isNotEmpty()) {
            clusters.add(buildCluster(groupStart, groupMaxEnd, currentGroup, use24HourFormat))
        }

        return DailyScheduleBreakdown(timedClusters = clusters, untimedTasks = untimed)
    }

    private fun effectiveEndMinutes(task: TaskItem): Int {
        val start = task.startTimeMinutes ?: 0
        val end = task.endTimeMinutes
        return if (end != null && end > start) end else (start + 60).coerceAtMost(24 * 60)
    }

    private fun buildCluster(
        startMin: Int,
        endMin: Int,
        tasks: List<TaskItem>,
        use24HourFormat: Boolean = true
    ): TimeSlotCluster {
        val startStr = TaskDateTimeUtils.formatTimeMinutes(startMin, use24HourFormat)
        val label = if (tasks.size == 1 && tasks.first().endTimeMinutes == null) {
            startStr
        } else {
            val clampedEnd = endMin.coerceAtMost(23 * 60 + 59)
            "$startStr - ${TaskDateTimeUtils.formatTimeMinutes(clampedEnd, use24HourFormat)}"
        }
        return TimeSlotCluster(
            slotLabel = label,
            startMinutes = startMin,
            tasks = tasks.toList()
        )
    }

    fun weekdayHeaders(weekStartDay: WeekStartDay = WeekStartDay.MONDAY): List<String> = when (weekStartDay) {
        WeekStartDay.MONDAY -> listOf("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz")
        WeekStartDay.SUNDAY -> listOf("Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt")
    }

    fun weekDaysFor(
        dayMillis: Long,
        weekStartDay: WeekStartDay = WeekStartDay.MONDAY
    ): List<Long> {
        val cal = Calendar.getInstance().apply {
            timeInMillis = dayMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val offsetFromStart = (cal.get(Calendar.DAY_OF_WEEK) - weekStartDay.calendarConstant + 7) % 7
        cal.add(Calendar.DAY_OF_MONTH, -offsetFromStart)
        return (0 until 7).map {
            val dayMs = cal.timeInMillis
            cal.add(Calendar.DAY_OF_MONTH, 1)
            dayMs
        }
    }

    fun buildDayDensity(dayMillis: Long, filteredTasks: List<TaskItem>): DayDensitySummary {
        val cal = Calendar.getInstance().apply { timeInMillis = dayMillis }
        val dayNum = cal.get(Calendar.DAY_OF_MONTH)
        val shortName = SimpleDateFormat("EEE", trLocale).format(Date(dayMillis))
            .replace(".", "")
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(trLocale) else it.toString() }
        val dayTasks = tasksForDay(filteredTasks, dayMillis)
        return DayDensitySummary(
            dayMillis = dayMillis,
            shortDayName = shortName,
            dayNumber = dayNum,
            totalCount = dayTasks.size,
            completedCount = dayTasks.count { it.status == TaskStatus.COMPLETED },
            pendingCount = dayTasks.count {
                it.status == TaskStatus.PENDING || it.status == TaskStatus.IN_PROGRESS
            },
            postponedCount = dayTasks.count { it.status == TaskStatus.POSTPONED },
            highPriorityCount = dayTasks.count { it.priority == TaskPriority.HIGH }
        )
    }

    fun buildMonthGrid(
        year: Int,
        month: Int,
        todayDayMillis: Long,
        selectedDayMillis: Long,
        filteredTasks: List<TaskItem>,
        weekStartDay: WeekStartDay = WeekStartDay.MONDAY
    ): List<CalendarDayCell?> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val firstDayOffset = (cal.get(Calendar.DAY_OF_WEEK) - weekStartDay.calendarConstant + 7) % 7

        val result = mutableListOf<CalendarDayCell?>()
        repeat(firstDayOffset) { result.add(null) }
        for (day in 1..daysInMonth) {
            val dayMillis = TaskDateTimeUtils.localDayMillis(year, month, day)
            val dayTasks = tasksForDay(filteredTasks, dayMillis)
            result.add(
                CalendarDayCell(
                    dayOfMonth = day,
                    year = year,
                    month = month,
                    dayMillis = dayMillis,
                    isToday = dayMillis == todayDayMillis,
                    isSelected = dayMillis == selectedDayMillis,
                    taskCount = dayTasks.size,
                    hasHighPriority = dayTasks.any { it.priority == TaskPriority.HIGH },
                    hasCompleted = dayTasks.any { it.status == TaskStatus.COMPLETED },
                    hasPending = dayTasks.any {
                        it.status == TaskStatus.PENDING || it.status == TaskStatus.IN_PROGRESS
                    },
                    hasPostponed = dayTasks.any { it.status == TaskStatus.POSTPONED }
                )
            )
        }
        while (result.size % 7 != 0) {
            result.add(null)
        }
        return result
    }

    fun formatMonthTitle(year: Int, month: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return SimpleDateFormat("MMMM yyyy", trLocale)
            .format(cal.time)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(trLocale) else it.toString() }
    }

    fun formatWeekRangeTitle(weekDays: List<Long>): String {
        if (weekDays.isEmpty()) return ""
        val first = weekDays.first()
        val last = weekDays.last()
        val fmtShort = SimpleDateFormat("d MMM", trLocale)
        val fmtYear = SimpleDateFormat("d MMM yyyy", trLocale)
        return "${fmtShort.format(Date(first))} – ${fmtYear.format(Date(last))}"
    }
}
