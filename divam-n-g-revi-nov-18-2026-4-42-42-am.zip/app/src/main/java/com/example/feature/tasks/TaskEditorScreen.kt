package com.example.feature.tasks

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.data.local.TaskDraft
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.WindowWidthClass
import com.example.ui.theme.DivamTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskEditorScreen(
    taskId: Long,
    initialDateMillis: Long,
    widthClass: WindowWidthClass,
    taskViewModel: TaskViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val categories by taskViewModel.categories.collectAsStateWithLifecycle()
    val userPrefs = DivamTheme.userPreferences
    val isEditing = taskId > 0L

    var formState by remember(taskId, initialDateMillis) {
        val defaultCat = categories.firstOrNull { it.id == userPrefs.defaultCategoryId }
        mutableStateOf(
            TaskFormState(
                startDateMillis = if (initialDateMillis > 0L) {
                    initialDateMillis
                } else {
                    TaskDateTimeUtils.todayLocalDayMillis()
                },
                priority = userPrefs.defaultPriority,
                categoryId = defaultCat?.id ?: userPrefs.defaultCategoryId,
                categoryName = defaultCat?.name ?: "İş"
            )
        )
    }

    LaunchedEffect(taskId) {
        if (isEditing) {
            val existing = taskViewModel.getTaskById(taskId)
            if (existing != null) {
                formState = TaskFormState(
                    title = existing.title,
                    description = existing.description,
                    note = existing.note,
                    startDateMillis = existing.startDateMillis,
                    endDateMillis = existing.endDateMillis,
                    startTimeMinutes = existing.startTimeMinutes,
                    endTimeMinutes = existing.endTimeMinutes,
                    priority = existing.priority,
                    categoryId = existing.categoryId,
                    categoryName = existing.categoryName,
                    status = existing.status,
                    isFavorite = existing.isFavorite,
                    reminderEnabled = existing.reminderEnabled,
                    reminderOffsetsMinutes = existing.reminderOffsetsMinutes,
                    recurrence = existing.recurrence
                )
            }
        } else {
            val defaultOffsets = taskViewModel.getDefaultReminderOffsets()
            formState = formState.copy(reminderOffsetsMinutes = defaultOffsets)
        }
    }

    // İlk kategori otomatik seçimi senkronize kalsın
    LaunchedEffect(categories) {
        if (categories.isNotEmpty()) {
            val preferred = categories.firstOrNull { it.id == formState.categoryId }
                ?: categories.firstOrNull { it.id == userPrefs.defaultCategoryId }
                ?: categories.first()
            if (preferred.id != formState.categoryId || preferred.name != formState.categoryName) {
                formState = formState.copy(categoryId = preferred.id, categoryName = preferred.name)
            }
        }
    }

    val submitAction: () -> Unit = {
        val trimmedTitle = formState.title.trim()
        val validation = com.example.core.model.TaskScheduleValidator.validate(
            title = trimmedTitle,
            startDateMillis = formState.startDateMillis,
            endDateMillis = formState.endDateMillis,
            startTimeMinutes = formState.startTimeMinutes,
            endTimeMinutes = formState.endTimeMinutes,
            requireTitle = true
        )

        if (!validation.isValid) {
            formState = formState.copy(
                titleError = validation.titleError,
                scheduleError = validation.scheduleError
            )
        } else {
                val resolvedCategory = categories.firstOrNull { it.id == formState.categoryId }
                val draft = TaskDraft(
                    title = trimmedTitle,
                    description = formState.description,
                    note = formState.note,
                    startDateMillis = formState.startDateMillis,
                    endDateMillis = formState.endDateMillis,
                    startTimeMinutes = formState.startTimeMinutes,
                    endTimeMinutes = formState.endTimeMinutes,
                    priority = formState.priority,
                    categoryId = resolvedCategory?.id ?: formState.categoryId,
                    categoryName = resolvedCategory?.name ?: formState.categoryName,
                    status = formState.status,
                    isFavorite = formState.isFavorite,
                    reminderEnabled = formState.reminderEnabled,
                    reminderOffsetsMinutes = formState.reminderOffsetsMinutes,
                    recurrence = formState.recurrence
                )
                taskViewModel.saveTask(
                    editingTaskId = if (isEditing) taskId else null,
                    draft = draft,
                    onSaved = onBack
                )
        }
    }

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp
    val extended = DivamTheme.extendedColors

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_gorev_ekle_duzenle")
    ) {
        TopAppBar(
            title = {
                Text(
                    text = if (isEditing) "Görevi Düzenle" else "Yeni Görev Ekle",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("task_editor_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(id = R.string.cd_back),
                        tint = extended.goldMid
                    )
                }
            },
            actions = {
                IconButton(
                    onClick = submitAction,
                    modifier = Modifier.testTag("task_editor_top_save_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = "Görevi kaydet",
                        tint = extended.goldMid
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent
            )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = horizontalPadding,
                end = horizontalPadding,
                top = 8.dp,
                bottom = 32.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                TaskFormComponent(
                    state = formState,
                    categories = categories,
                    widthClass = widthClass,
                    isEditing = isEditing,
                    onStateChange = { formState = it },
                    onCreateCategory = { name -> taskViewModel.createCustomCategory(name) },
                    onSubmit = submitAction,
                    onCancel = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 1040.dp)
                )
            }
        }
    }
}
