package com.example.feature.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.SettingsSuggest
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.AppFontScale
import com.example.core.model.CardDisplayStyle
import com.example.core.model.DateFormatStyle
import com.example.core.model.TaskBoxFilter
import com.example.core.model.TaskCategory
import com.example.core.model.TaskPriority
import com.example.core.model.UserPreferences
import com.example.core.model.WeekStartDay
import com.example.core.security.AppSecurityHelper
import com.example.ui.theme.DivamTheme
import com.example.ui.theme.ThemeMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppearanceSettingsCard(
    themeMode: ThemeMode,
    userPreferences: UserPreferences,
    onThemeModeSelected: (ThemeMode) -> Unit,
    onToggleGoldAccents: (Boolean) -> Unit,
    onSelectFontScale: (AppFontScale) -> Unit,
    onSelectCardStyle: (CardDisplayStyle) -> Unit,
    onRequestResetAppearance: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.Palette, contentDescription = null, tint = extended.goldMid)
                Text(
                    text = "Tema, Altın Detaylar ve Yazı Boyutu",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { mode ->
                ThemeOptionItem(
                    mode = mode,
                    selected = mode == themeMode,
                    onSelect = { onThemeModeSelected(mode) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        SettingsSwitchLine(
            title = "Metalik Altın Detaylar",
            subtitle = "Altın vurguları, çerçeveleri ve simgeleri aç veya kapat",
            checked = userPreferences.goldAccentsEnabled,
            onCheckedChange = onToggleGoldAccents,
            testTag = "settings_gold_accents_switch"
        )

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Yazı Boyutu",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AppFontScale.entries.forEach { scale ->
                FilterChip(
                    selected = userPreferences.fontScale == scale,
                    onClick = { onSelectFontScale(scale) },
                    label = { Text(scale.turkishLabel) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        selectedLabelColor = extended.goldStart
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Görev Kartı Görünümü",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CardDisplayStyle.entries.forEach { style ->
                FilterChip(
                    selected = userPreferences.cardDisplayStyle == style,
                    onClick = { onSelectCardStyle(style) },
                    label = { Text(style.turkishLabel) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        selectedLabelColor = extended.goldStart
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PaletteSwatchPill("Siyah", extended.swatchBlack, Modifier.weight(1f))
            PaletteSwatchPill("Koyu Mor", extended.swatchPurple, Modifier.weight(1f))
            PaletteSwatchPill("Altın", extended.swatchGold, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))
        TextButton(
            onClick = onRequestResetAppearance,
            modifier = Modifier.testTag("settings_reset_appearance_button")
        ) {
            Icon(Icons.Rounded.Restore, contentDescription = null, tint = extended.goldMid, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Görünüm Ayarlarını Sıfırla", color = extended.goldMid)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DateAndTaskBehaviorCard(
    userPreferences: UserPreferences,
    categories: List<TaskCategory>,
    onToggle24Hour: (Boolean) -> Unit,
    onSelectDateFormat: (DateFormatStyle) -> Unit,
    onSelectWeekStart: (WeekStartDay) -> Unit,
    onSelectDefaultPriority: (TaskPriority) -> Unit,
    onSelectDefaultCategory: (String) -> Unit,
    onSelectDefaultTaskBox: (TaskBoxFilter) -> Unit,
    onToggleAutoArchive: (Boolean) -> Unit,
    onToggleShowOverdue: (Boolean) -> Unit,
    onToggleConfirmDelete: (Boolean) -> Unit
) {
    val extended = DivamTheme.extendedColors
    DivamCard(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Tarih, Saat ve Takvim Tercihleri",
            style = MaterialTheme.typography.titleMedium,
            color = extended.goldMid
        )
        Spacer(modifier = Modifier.height(10.dp))
        SettingsSwitchLine(
            title = "24 Saat Biçimi",
            subtitle = if (userPreferences.use24HourFormat) "24 saat (14:30) aktif" else "12 saat (02:30 ÖS) aktif",
            checked = userPreferences.use24HourFormat,
            onCheckedChange = onToggle24Hour,
            testTag = "settings_24h_switch"
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("Tarih Biçimi", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DateFormatStyle.entries.forEach { style ->
                FilterChip(
                    selected = userPreferences.dateFormatStyle == style,
                    onClick = { onSelectDateFormat(style) },
                    label = { Text(style.turkishLabel) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("Haftanın Başlangıç Günü", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WeekStartDay.entries.forEach { day ->
                FilterChip(
                    selected = userPreferences.weekStartDay == day,
                    onClick = { onSelectWeekStart(day) },
                    label = { Text(day.turkishLabel) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Görev Varsayılanları ve Davranış",
            style = MaterialTheme.typography.titleMedium,
            color = extended.goldMid
        )
        Spacer(modifier = Modifier.height(8.dp))

        Text("Varsayılan Öncelik", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TaskPriority.entries.forEach { p ->
                FilterChip(
                    selected = userPreferences.defaultPriority == p,
                    onClick = { onSelectDefaultPriority(p) },
                    label = { Text(p.turkishLabel) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("Varsayılan Kategori", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = userPreferences.defaultCategoryId == cat.id,
                    onClick = { onSelectDefaultCategory(cat.id) },
                    label = { Text(cat.name) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("Varsayılan Görev Görünümü", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(TaskBoxFilter.ACTIVE, TaskBoxFilter.FAVORITES, TaskBoxFilter.ARCHIVED).forEach { box ->
                FilterChip(
                    selected = userPreferences.defaultTaskBoxFilter == box,
                    onClick = { onSelectDefaultTaskBox(box) },
                    label = { Text(box.turkishLabel) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        SettingsSwitchLine(
            title = "Tamamlanan Görevleri Otomatik Arşivle",
            subtitle = "Tamamlandı işaretlenen görevleri otomatik Arşiv kutusuna taşır",
            checked = userPreferences.autoArchiveCompleted,
            onCheckedChange = onToggleAutoArchive,
            testTag = "settings_auto_archive_switch"
        )
        SettingsSwitchLine(
            title = "Geciken Görevleri Ana Sayfada Göster",
            subtitle = "Vadesi geçmiş görevler için Ana Sayfa'da uyarı kartı gösterir",
            checked = userPreferences.showOverdueOnHome,
            onCheckedChange = onToggleShowOverdue,
            testTag = "settings_show_overdue_switch"
        )
        SettingsSwitchLine(
            title = "Görev Silerken Onay İste",
            subtitle = "Çöp kutusuna taşıma veya kalıcı silme öncesi onay penceresi açar",
            checked = userPreferences.confirmBeforeDelete,
            onCheckedChange = onToggleConfirmDelete,
            testTag = "settings_confirm_delete_switch"
        )
    }
}

@Composable
fun BackupAndSecurityCard(
    userPreferences: UserPreferences,
    localBackupFiles: List<File>,
    onExportJson: () -> Unit,
    onImportJson: () -> Unit,
    onCreateLocalSnapshot: () -> Unit,
    onInspectLocalSnapshot: (File) -> Unit,
    onOpenPinSetup: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onLockNow: () -> Unit
) {
    val context = LocalContext.current
    val extended = DivamTheme.extendedColors
    val canBiometric = AppSecurityHelper.canUseBiometricAuthentication(context)
    val biometricLabel = AppSecurityHelper.biometricAvailabilityLabel(context)
    val dateFmt = SimpleDateFormat("d MMM yyyy HH:mm", Locale.forLanguageTag("tr-TR"))

    DivamCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Rounded.Backup, contentDescription = null, tint = extended.goldMid)
            Text(
                text = "Yedekleme ve Geri Yükleme (JSON)",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Görevleriniz ve kategorileriniz standart JSON biçiminde dışa aktarılır; geri yükleme öncesinde doğrulama ve yinelenen kayıt kontrolü yapılır.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportJson,
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).testTag("settings_export_json_button")
            ) {
                Icon(Icons.Rounded.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Dışa Aktar", maxLines = 1)
            }
            OutlinedButton(
                onClick = onImportJson,
                border = BorderStroke(1.dp, extended.goldMid),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).testTag("settings_import_json_button")
            ) {
                Icon(Icons.Rounded.FileDownload, contentDescription = null, tint = extended.goldMid, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Geri Yükle", color = extended.goldMid, maxLines = 1)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = onCreateLocalSnapshot,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("settings_local_snapshot_button")
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Cihaz İçi Yedek Oluştur")
        }

        if (localBackupFiles.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Kayıtlı Yerel Yedekler (${localBackupFiles.size})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                localBackupFiles.take(4).forEach { file ->
                    Surface(
                        onClick = { onInspectLocalSnapshot(file) },
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, extended.cardBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = file.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = dateFmt.format(Date(file.lastModified())),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text("Geri Yükle", style = MaterialTheme.typography.labelMedium, color = extended.goldMid)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Rounded.Lock, contentDescription = null, tint = extended.goldMid)
            Text(
                text = "Uygulama Kilidi ve Biyometrik Güvenlik",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (userPreferences.appLockEnabled && userPreferences.hasPinConfigured) {
                "PIN kilidi etkin. Uygulama açılışında doğrulama istenir."
            } else {
                "Uygulama kilidi kapalı. 4–6 haneli PIN ve destekleniyorsa biyometrik doğrulama ekleyebilirsiniz."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onOpenPinSetup,
                border = BorderStroke(1.dp, extended.goldMid),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).testTag("settings_pin_setup_button")
            ) {
                Text(
                    text = if (userPreferences.hasPinConfigured) "PIN Düzenle / Kapat" else "PIN Oluştur",
                    color = extended.goldMid,
                    maxLines = 1
                )
            }
            if (userPreferences.appLockEnabled && userPreferences.hasPinConfigured) {
                Button(
                    onClick = onLockNow,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = extended.goldMid,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("settings_lock_now_button")
                ) {
                    Text("Şimdi Kilitle")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f).padding(end = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.Fingerprint, contentDescription = null, tint = extended.goldMid)
                Column {
                    Text(
                        text = "Biyometrik Kilit (Parmak İzi / Yüz)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = biometricLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Switch(
                checked = userPreferences.biometricEnabled,
                onCheckedChange = onToggleBiometric,
                enabled = userPreferences.appLockEnabled && userPreferences.hasPinConfigured && canBiometric,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                    checkedTrackColor = extended.goldMid
                )
            )
        }
    }
}

@Composable
fun SettingsSwitchLine(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    val extended = DivamTheme.extendedColors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = extended.goldMid
            )
        )
    }
}

@Composable
private fun ThemeOptionItem(
    mode: ThemeMode,
    selected: Boolean,
    onSelect: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    val borderColor = if (selected) extended.goldMid else extended.cardBorderSubtle
    val containerColor = if (selected) {
        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerLow
    }

    Surface(
        onClick = onSelect,
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("theme_option_${mode.storageKey}"),
        shape = RoundedCornerShape(14.dp),
        color = containerColor,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = iconForThemeMode(mode),
                contentDescription = null,
                tint = if (selected) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = mode.turkishLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = mode.turkishDescription,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            RadioButton(
                selected = selected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = extended.goldMid,
                    unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
private fun PaletteSwatchPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, DivamTheme.extendedColors.cardBorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(color)
                    .border(1.dp, DivamTheme.extendedColors.cardBorderGold, CircleShape)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun iconForThemeMode(mode: ThemeMode): ImageVector = when (mode) {
    ThemeMode.DARK -> Icons.Rounded.DarkMode
    ThemeMode.LIGHT -> Icons.Rounded.LightMode
    ThemeMode.SYSTEM -> Icons.Rounded.SettingsSuggest
}
