package com.example.feature.tasks

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.TaskDraft
import com.example.core.data.local.TaskRepository
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.data.preferences.UserPreferencesRepository
import com.example.core.model.TaskBoxFilter
import com.example.core.model.TaskCategory
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskSortOption
import com.example.core.model.TaskStatus
import com.example.core.notifications.AndroidTaskReminderScheduler
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

@Immutable
data class TaskBoxCounts(
    val active: Int = 0,
    val favorites: Int = 0,
    val archived: Int = 0,
    val trash: Int = 0
)

@Immutable
data class TaskFilterState(
    val searchQuery: String = "",
    val boxFilter: TaskBoxFilter = TaskBoxFilter.ACTIVE,
    val statusFilter: TaskStatus? = null,
    val priorityFilter: TaskPriority? = null,
    val categoryFilterId: String? = null,
    val sortOption: TaskSortOption = TaskSortOption.DATE_ASC
) {
    val hasSecondaryFilters: Boolean
        get() = statusFilter != null || priorityFilter != null || categoryFilterId != null
}

class TaskViewModel(
    private val repository: TaskRepository,
    private val userPreferencesRepository: UserPreferencesRepository? = null,
    private val notificationPreferencesRepository: NotificationPreferencesRepository? = null,
    private val appContext: android.content.Context? = null
) : ViewModel() {

    private val trLocale = Locale.forLanguageTag("tr-TR")

    private val _filterState = MutableStateFlow(TaskFilterState())
    val filterState: StateFlow<TaskFilterState> = _filterState.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    val allTasks: StateFlow<List<TaskItem>> = repository.tasksFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val categories: StateFlow<List<TaskCategory>> = repository.categoriesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val boxCounts: StateFlow<TaskBoxCounts> = allTasks
        .map { tasks ->
            TaskBoxCounts(
                active = tasks.count { !it.isArchived && !it.isDeleted },
                favorites = tasks.count { it.isFavorite && !it.isArchived && !it.isDeleted },
                archived = tasks.count { it.isArchived && !it.isDeleted },
                trash = tasks.count { it.isDeleted }
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = TaskBoxCounts()
        )

    val filteredTasks: StateFlow<List<TaskItem>> = combine(allTasks, _filterState) { tasks, filter ->
        applyFiltersAndSort(tasks, filter)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    init {
        viewModelScope.launch {
            repository.ensureDefaultCategories()
            userPreferencesRepository?.getSnapshot()?.let { prefs ->
                _filterState.value = _filterState.value.copy(boxFilter = prefs.defaultTaskBoxFilter)
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _filterState.value = _filterState.value.copy(searchQuery = query)
    }

    fun updateBoxFilter(box: TaskBoxFilter) {
        _filterState.value = _filterState.value.copy(boxFilter = box)
    }

    fun updateStatusFilter(status: TaskStatus?) {
        val current = _filterState.value.statusFilter
        _filterState.value = _filterState.value.copy(
            statusFilter = if (current == status) null else status
        )
    }

    fun updatePriorityFilter(priority: TaskPriority?) {
        val current = _filterState.value.priorityFilter
        _filterState.value = _filterState.value.copy(
            priorityFilter = if (current == priority) null else priority
        )
    }

    fun updateCategoryFilter(categoryId: String?) {
        val current = _filterState.value.categoryFilterId
        _filterState.value = _filterState.value.copy(
            categoryFilterId = if (current == categoryId) null else categoryId
        )
    }

    fun updateSortOption(option: TaskSortOption) {
        _filterState.value = _filterState.value.copy(sortOption = option)
    }

    fun clearSecondaryFilters() {
        _filterState.value = _filterState.value.copy(
            statusFilter = null,
            priorityFilter = null,
            categoryFilterId = null
        )
    }

    suspend fun getTaskById(taskId: Long): TaskItem? = repository.getTaskById(taskId)

    suspend fun getDefaultReminderOffsets(): List<Int> =
        notificationPreferencesRepository?.getSettingsSnapshot()?.defaultReminderOffsets ?: listOf(15)

    fun saveTask(editingTaskId: Long?, draft: TaskDraft, onSaved: () -> Unit) {
        viewModelScope.launch {
            val autoArchive = userPreferencesRepository?.getSnapshot()?.autoArchiveCompleted ?: false
            if (editingTaskId == null || editingTaskId <= 0L) {
                repository.createTask(draft, autoArchiveIfCompleted = autoArchive)
                if (draft.status == TaskStatus.COMPLETED) {
                    playCompletionSoundIfPossible()
                }
                _snackbarMessages.tryEmit("Yeni görev kaydedildi")
            } else {
                val previous = repository.getTaskById(editingTaskId)
                repository.updateTask(editingTaskId, draft, autoArchiveIfCompleted = autoArchive)
                if (draft.status == TaskStatus.COMPLETED && previous?.status != TaskStatus.COMPLETED) {
                    playCompletionSoundIfPossible()
                }
                _snackbarMessages.tryEmit("Görev güncellendi")
            }
            onSaved()
        }
    }

    fun duplicateTask(taskId: Long) {
        viewModelScope.launch {
            val newId = repository.duplicateTask(taskId)
            if (newId != null) {
                _snackbarMessages.tryEmit("Görev kopyalandı")
            }
        }
    }

    fun toggleCompleted(taskId: Long) {
        viewModelScope.launch {
            val autoArchive = userPreferencesRepository?.getSnapshot()?.autoArchiveCompleted ?: false
            val becameCompleted = repository.toggleCompleted(taskId, autoArchiveIfCompleted = autoArchive)
            if (becameCompleted) {
                playCompletionSoundIfPossible()
            }
        }
    }

    fun setStatus(taskId: Long, status: TaskStatus) {
        viewModelScope.launch {
            val autoArchive = userPreferencesRepository?.getSnapshot()?.autoArchiveCompleted ?: false
            val previous = repository.getTaskById(taskId)
            repository.setStatus(taskId, status, autoArchiveIfCompleted = autoArchive)
            if (status == TaskStatus.COMPLETED && previous?.status != TaskStatus.COMPLETED) {
                playCompletionSoundIfPossible()
            }
            _snackbarMessages.tryEmit("Durum güncellendi: ${status.turkishLabel}")
        }
    }

    private suspend fun playCompletionSoundIfPossible() {
        val ctx = appContext ?: return
        val notifSettings = notificationPreferencesRepository?.getSettingsSnapshot() ?: return
        com.example.core.notifications.TaskSoundManager.playTaskCompletedFeedback(ctx, notifSettings)
    }

    fun postponeTask(taskId: Long, days: Int) {
        viewModelScope.launch {
            repository.postponeTask(taskId, days)
            _snackbarMessages.tryEmit("Görev $days gün ertelendi")
        }
    }

    fun rescheduleTask(
        taskId: Long,
        startDateMillis: Long?,
        endDateMillis: Long?,
        startTimeMinutes: Int?,
        endTimeMinutes: Int?
    ) {
        viewModelScope.launch {
            repository.rescheduleTask(
                taskId = taskId,
                startDateMillis = startDateMillis,
                endDateMillis = endDateMillis,
                startTimeMinutes = startTimeMinutes,
                endTimeMinutes = endTimeMinutes
            )
            _snackbarMessages.tryEmit("Görev tarih ve saati güncellendi")
        }
    }

    fun toggleFavorite(taskId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(taskId)
        }
    }

    fun setArchived(taskId: Long, archived: Boolean) {
        viewModelScope.launch {
            repository.setArchived(taskId, archived)
            _snackbarMessages.tryEmit(if (archived) "Görev arşivlendi" else "Görev arşivden çıkarıldı")
        }
    }

    fun moveToTrash(taskId: Long) {
        viewModelScope.launch {
            repository.moveToTrash(taskId)
            _snackbarMessages.tryEmit("Görev çöp kutusuna taşındı")
        }
    }

    fun restoreFromTrash(taskId: Long) {
        viewModelScope.launch {
            repository.restoreFromTrash(taskId)
            _snackbarMessages.tryEmit("Görev geri yüklendi")
        }
    }

    fun deletePermanently(taskId: Long) {
        viewModelScope.launch {
            repository.deletePermanently(taskId)
            _snackbarMessages.tryEmit("Görev kalıcı olarak silindi")
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
            _snackbarMessages.tryEmit("Çöp kutusu temizlendi")
        }
    }

    suspend fun createCustomCategory(name: String): Result<TaskCategory> {
        val result = repository.createCustomCategory(name)
        if (result.isSuccess) {
            _snackbarMessages.tryEmit("Kategori eklendi: ${result.getOrThrow().name}")
        }
        return result
    }

    fun deleteCustomCategory(categoryId: String) {
        viewModelScope.launch {
            repository.deleteCustomCategory(categoryId)
            if (_filterState.value.categoryFilterId == categoryId) {
                _filterState.value = _filterState.value.copy(categoryFilterId = null)
            }
            _snackbarMessages.tryEmit("Özel kategori silindi")
        }
    }

    private fun applyFiltersAndSort(tasks: List<TaskItem>, filter: TaskFilterState): List<TaskItem> =
        filterAndSortTasks(tasks, filter, trLocale)

    companion object {
        internal fun filterAndSortTasks(
            tasks: List<TaskItem>,
            filter: TaskFilterState,
            locale: Locale = Locale.forLanguageTag("tr-TR")
        ): List<TaskItem> {
            val query = filter.searchQuery.trim().lowercase(locale)
            val filtered = tasks.filter { task ->
                val matchesBox = when (filter.boxFilter) {
                    TaskBoxFilter.ACTIVE -> !task.isArchived && !task.isDeleted
                    TaskBoxFilter.FAVORITES -> task.isFavorite && !task.isArchived && !task.isDeleted
                    TaskBoxFilter.ARCHIVED -> task.isArchived && !task.isDeleted
                    TaskBoxFilter.TRASH -> task.isDeleted
                }
                if (!matchesBox) return@filter false

                if (filter.statusFilter != null && task.status != filter.statusFilter) {
                    return@filter false
                }
                if (filter.priorityFilter != null && task.priority != filter.priorityFilter) {
                    return@filter false
                }
                if (filter.categoryFilterId != null && task.categoryId != filter.categoryFilterId) {
                    return@filter false
                }
                if (query.isNotEmpty()) {
                    val matchesQuery =
                        task.title.lowercase(locale).contains(query) ||
                            task.description.lowercase(locale).contains(query) ||
                            task.note.lowercase(locale).contains(query) ||
                            task.categoryName.lowercase(locale).contains(query)
                    if (!matchesQuery) return@filter false
                }
                true
            }

            return when (filter.sortOption) {
                TaskSortOption.DATE_ASC -> filtered.sortedWith(
                    compareBy<TaskItem>(
                        { it.startDateMillis ?: Long.MAX_VALUE },
                        { it.startTimeMinutes ?: Int.MAX_VALUE },
                        { -it.priority.sortWeight },
                        { -it.createdAtMillis }
                    )
                )
                TaskSortOption.DATE_DESC -> filtered.sortedWith(
                    compareByDescending<TaskItem> { it.startDateMillis ?: Long.MIN_VALUE }
                        .thenByDescending { it.startTimeMinutes ?: Int.MIN_VALUE }
                        .thenByDescending { it.createdAtMillis }
                )
                TaskSortOption.PRIORITY_DESC -> filtered.sortedWith(
                    compareByDescending<TaskItem> { it.priority.sortWeight }
                        .thenBy { it.startDateMillis ?: Long.MAX_VALUE }
                        .thenByDescending { it.createdAtMillis }
                )
                TaskSortOption.PRIORITY_ASC -> filtered.sortedWith(
                    compareBy<TaskItem> { it.priority.sortWeight }
                        .thenBy { it.startDateMillis ?: Long.MAX_VALUE }
                        .thenByDescending { it.createdAtMillis }
                )
                TaskSortOption.CREATED_DESC -> filtered.sortedByDescending { it.createdAtMillis }
            }
        }
    }

    class Factory(
        private val context: Context
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
                val appCtx = context.applicationContext
                val db = DivamDatabase.getInstance(appCtx)
                val notifPrefs = NotificationPreferencesRepository(appCtx)
                val userPrefs = UserPreferencesRepository(appCtx)
                val scheduler = AndroidTaskReminderScheduler.create(appCtx)
                val repository = TaskRepository(
                    taskDao = db.taskDao(),
                    notificationDao = db.notificationDao(),
                    reminderScheduler = scheduler
                )
                return TaskViewModel(
                    repository = repository,
                    userPreferencesRepository = userPrefs,
                    notificationPreferencesRepository = notifPrefs,
                    appContext = appCtx
                ) as T
            }
            throw IllegalArgumentException("Bilinmeyen ViewModel sınıfı: ${modelClass.name}")
        }
    }
}
