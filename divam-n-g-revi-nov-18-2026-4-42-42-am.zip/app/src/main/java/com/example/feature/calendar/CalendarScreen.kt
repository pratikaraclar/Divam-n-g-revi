package com.example.feature.calendar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.EventNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.designsystem.components.DivamSectionTitle
import com.example.core.model.ModuleReadiness
import com.example.core.model.TaskCategory
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskStatus
import com.example.core.model.WindowWidthClass
import com.example.ui.theme.DivamTheme
import java.util.Calendar

@Composable
fun CalendarScreen(
    widthClass: WindowWidthClass,
    tasks: List<TaskItem>,
    categories: List<TaskCategory>,
    onToggleTaskComplete: (Long) -> Unit,
    onOpenTaskEditor: (Long) -> Unit,
    onCreateTaskForDate: (Long) -> Unit,
    onRescheduleTask: (taskId: Long, startDate: Long?, endDate: Long?, startTime: Int?, endTime: Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayDayMillis = remember { TaskDateTimeUtils.todayLocalDayMillis() }
    val todayCal = remember(todayDayMillis) {
        Calendar.getInstance().apply { timeInMillis = todayDayMillis }
    }

    var viewMode by remember { mutableStateOf(CalendarViewMode.MONTHLY) }
    var displayedYear by remember { mutableIntStateOf(todayCal.get(Calendar.YEAR)) }
    var displayedMonth by remember { mutableIntStateOf(todayCal.get(Calendar.MONTH)) }
    var selectedDayMillis by remember { mutableLongStateOf(todayDayMillis) }

    var categoryFilterId by remember { mutableStateOf<String?>(null) }
    var statusFilter by remember { mutableStateOf<TaskStatus?>(null) }
    var rescheduleTarget by remember { mutableStateOf<TaskItem?>(null) }

    val userPrefs = DivamTheme.userPreferences
    val filteredTasks = remember(tasks, categoryFilterId, statusFilter) {
        CalendarLogic.filterTasksForCalendar(
            tasks = tasks,
            categoryFilterId = categoryFilterId,
            statusFilter = statusFilter
        )
    }

    val selectedDayTasks = remember(filteredTasks, selectedDayMillis) {
        CalendarLogic.tasksForDay(filteredTasks, selectedDayMillis)
    }
    val selectedDayDensity = remember(filteredTasks, selectedDayMillis) {
        CalendarLogic.buildDayDensity(selectedDayMillis, filteredTasks)
    }
    val dailyBreakdown = remember(selectedDayTasks, userPrefs.use24HourFormat) {
        CalendarLogic.buildDailySchedule(selectedDayTasks, userPrefs.use24HourFormat)
    }

    val weekDays = remember(selectedDayMillis, userPrefs.weekStartDay) {
        CalendarLogic.weekDaysFor(selectedDayMillis, userPrefs.weekStartDay)
    }
    val weekDensities = remember(weekDays, filteredTasks) {
        weekDays.map { day -> CalendarLogic.buildDayDensity(day, filteredTasks) }
    }

    val monthCells = remember(
        displayedYear,
        displayedMonth,
        todayDayMillis,
        selectedDayMillis,
        filteredTasks,
        userPrefs.weekStartDay
    ) {
        CalendarLogic.buildMonthGrid(
            year = displayedYear,
            month = displayedMonth,
            todayDayMillis = todayDayMillis,
            selectedDayMillis = selectedDayMillis,
            filteredTasks = filteredTasks,
            weekStartDay = userPrefs.weekStartDay
        )
    }

    val monthTitle = remember(displayedYear, displayedMonth) {
        CalendarLogic.formatMonthTitle(displayedYear, displayedMonth)
    }
    val weekRangeTitle = remember(weekDays) {
        CalendarLogic.formatWeekRangeTitle(weekDays)
    }
    val selectedDateFormatted = remember(selectedDayMillis) {
        TaskDateTimeUtils.formatDateLongTurkish(selectedDayMillis)
    }

    val selectDayAndSyncMonth: (Long) -> Unit = { newDayMillis ->
        selectedDayMillis = newDayMillis
        val c = Calendar.getInstance().apply { timeInMillis = newDayMillis }
        displayedYear = c.get(Calendar.YEAR)
        displayedMonth = c.get(Calendar.MONTH)
    }

    val shiftMonth: (Int) -> Unit = { delta ->
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, displayedYear)
            set(Calendar.MONTH, displayedMonth)
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, delta)
        }
        displayedYear = cal.get(Calendar.YEAR)
        displayedMonth = cal.get(Calendar.MONTH)
    }

    val shiftWeek: (Int) -> Unit = { deltaWeeks ->
        val nextDay = TaskDateTimeUtils.addDaysToLocalDayMillis(selectedDayMillis, deltaWeeks * 7)
        selectDayAndSyncMonth(nextDay)
    }

    val shiftDay: (Int) -> Unit = { deltaDays ->
        val nextDay = TaskDateTimeUtils.addDaysToLocalDayMillis(selectedDayMillis, deltaDays)
        selectDayAndSyncMonth(nextDay)
    }

    val jumpToToday: () -> Unit = {
        selectDayAndSyncMonth(TaskDateTimeUtils.todayLocalDayMillis())
    }

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp
    val extended = DivamTheme.extendedColors

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_takvim"),
        contentPadding = PaddingValues(
            start = horizontalPadding,
            end = horizontalPadding,
            top = 16.dp,
            bottom = 28.dp
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 1120.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                DivamSectionTitle(
                    title = "Takvim ve Zaman Yönetimi",
                    subtitle = "Günlük, haftalık ve aylık planlama • Yerel saat dilimi",
                    badge = ModuleReadiness.ACTIVE
                )

                CalendarViewModeSwitcher(
                    selectedMode = viewMode,
                    onModeSelected = { viewMode = it }
                )

                CalendarFilterBar(
                    categories = categories,
                    selectedCategoryId = categoryFilterId,
                    selectedStatus = statusFilter,
                    onCategorySelected = { categoryFilterId = it },
                    onStatusSelected = { statusFilter = it },
                    onClearFilters = {
                        categoryFilterId = null
                        statusFilter = null
                    },
                    onTodayClick = jumpToToday
                )

                when (viewMode) {
                    CalendarViewMode.MONTHLY -> {
                        if (widthClass.isTabletOrWide) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(18.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(
                                    modifier = Modifier.weight(1.1f),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    MonthlyCalendarGridCard(
                                        monthTitle = monthTitle,
                                        cells = monthCells,
                                        onPrevMonth = { shiftMonth(-1) },
                                        onNextMonth = { shiftMonth(1) },
                                        onSelectDay = { cell -> selectDayAndSyncMonth(cell.dayMillis) }
                                    )
                                    DailyDensityCard(density = selectedDayDensity)
                                }
                                SelectedDayTaskPanel(
                                    selectedDateFormatted = selectedDateFormatted,
                                    selectedDayMillis = selectedDayMillis,
                                    tasksForDay = selectedDayTasks,
                                    onToggleComplete = onToggleTaskComplete,
                                    onEditTask = onOpenTaskEditor,
                                    onRescheduleTask = { rescheduleTarget = it },
                                    onCreateTaskForDate = onCreateTaskForDate,
                                    modifier = Modifier.weight(0.9f)
                                )
                            }
                        } else {
                            MonthlyCalendarGridCard(
                                monthTitle = monthTitle,
                                cells = monthCells,
                                onPrevMonth = { shiftMonth(-1) },
                                onNextMonth = { shiftMonth(1) },
                                onSelectDay = { cell -> selectDayAndSyncMonth(cell.dayMillis) }
                            )
                            DailyDensityCard(density = selectedDayDensity)
                            SelectedDayTaskPanel(
                                selectedDateFormatted = selectedDateFormatted,
                                selectedDayMillis = selectedDayMillis,
                                tasksForDay = selectedDayTasks,
                                onToggleComplete = onToggleTaskComplete,
                                onEditTask = onOpenTaskEditor,
                                onRescheduleTask = { rescheduleTarget = it },
                                onCreateTaskForDate = onCreateTaskForDate
                            )
                        }
                    }

                    CalendarViewMode.WEEKLY -> {
                        WeeklyHeaderCard(
                            weekRangeTitle = weekRangeTitle,
                            weekDensities = weekDensities,
                            selectedDayMillis = selectedDayMillis,
                            todayDayMillis = todayDayMillis,
                            onPrevWeek = { shiftWeek(-1) },
                            onNextWeek = { shiftWeek(1) },
                            onSelectDay = selectDayAndSyncMonth
                        )

                        if (widthClass.isTabletOrWide) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(18.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(
                                    modifier = Modifier.weight(0.9f),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    WeeklyDensityCard(
                                        weekDensities = weekDensities,
                                        selectedDayMillis = selectedDayMillis,
                                        onSelectDay = selectDayAndSyncMonth
                                    )
                                    DailyDensityCard(density = selectedDayDensity)
                                }
                                SelectedDayTaskPanel(
                                    selectedDateFormatted = selectedDateFormatted,
                                    selectedDayMillis = selectedDayMillis,
                                    tasksForDay = selectedDayTasks,
                                    onToggleComplete = onToggleTaskComplete,
                                    onEditTask = onOpenTaskEditor,
                                    onRescheduleTask = { rescheduleTarget = it },
                                    onCreateTaskForDate = onCreateTaskForDate,
                                    modifier = Modifier.weight(1.1f)
                                )
                            }
                        } else {
                            WeeklyDensityCard(
                                weekDensities = weekDensities,
                                selectedDayMillis = selectedDayMillis,
                                onSelectDay = selectDayAndSyncMonth
                            )
                            SelectedDayTaskPanel(
                                selectedDateFormatted = selectedDateFormatted,
                                selectedDayMillis = selectedDayMillis,
                                tasksForDay = selectedDayTasks,
                                onToggleComplete = onToggleTaskComplete,
                                onEditTask = onOpenTaskEditor,
                                onRescheduleTask = { rescheduleTarget = it },
                                onCreateTaskForDate = onCreateTaskForDate
                            )
                        }
                    }

                    CalendarViewMode.DAILY -> {
                        DailyNavigatorHeaderCard(
                            selectedDateFormatted = selectedDateFormatted,
                            onPrevDay = { shiftDay(-1) },
                            onNextDay = { shiftDay(1) },
                            onCreateTaskForDate = { onCreateTaskForDate(selectedDayMillis) }
                        )

                        DailyDensityCard(density = selectedDayDensity)

                        if (dailyBreakdown.timedClusters.isEmpty() && dailyBreakdown.untimedTasks.isEmpty()) {
                            DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.EventNote,
                                        contentDescription = null,
                                        tint = extended.goldMid
                                    )
                                    Text(
                                        text = "Bu gün için planlanmış görev bulunmuyor.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            if (dailyBreakdown.timedClusters.isNotEmpty()) {
                                Text(
                                    text = "Saatlik Zaman Çizelgesi",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                dailyBreakdown.timedClusters.forEach { cluster ->
                                    TimeSlotClusterCard(
                                        cluster = cluster,
                                        isTabletOrWide = widthClass.isTabletOrWide,
                                        onToggleComplete = onToggleTaskComplete,
                                        onEditTask = onOpenTaskEditor,
                                        onRescheduleTask = { rescheduleTarget = it }
                                    )
                                }
                            }

                            if (dailyBreakdown.untimedTasks.isNotEmpty()) {
                                Text(
                                    text = "Saat Belirtilmemiş Görevler",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                dailyBreakdown.untimedTasks.forEach { task ->
                                    CalendarTaskCard(
                                        task = task,
                                        onToggleComplete = { onToggleTaskComplete(task.id) },
                                        onEdit = { onOpenTaskEditor(task.id) },
                                        onReschedule = { rescheduleTarget = task }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    rescheduleTarget?.let { target ->
        RescheduleTaskDialog(
            task = target,
            onDismiss = { rescheduleTarget = null },
            onSave = { startDate, endDate, startTime, endTime ->
                onRescheduleTask(target.id, startDate, endDate, startTime, endTime)
                rescheduleTarget = null
            }
        )
    }
}

@Composable
private fun MonthlyCalendarGridCard(
    monthTitle: String,
    cells: List<CalendarDayCell?>,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDay: (CalendarDayCell) -> Unit,
    modifier: Modifier = Modifier
) {
    val userPrefs = DivamTheme.userPreferences
    val weekdays = remember(userPrefs.weekStartDay) {
        CalendarLogic.weekdayHeaders(userPrefs.weekStartDay)
    }
    val extended = DivamTheme.extendedColors

    DivamCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = monthTitle,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onPrevMonth,
                    modifier = Modifier.testTag("calendar_prev_month")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ChevronLeft,
                        contentDescription = "Önceki ay",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(
                    onClick = onNextMonth,
                    modifier = Modifier.testTag("calendar_next_month")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = "Sonraki ay",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            weekdays.forEach { dayName ->
                Text(
                    text = dayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val rows = cells.chunked(7)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            rows.forEach { week ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    week.forEach { cell ->
                        if (cell == null) {
                            Spacer(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                            )
                        } else {
                            val bgColor = when {
                                cell.isSelected -> MaterialTheme.colorScheme.secondaryContainer
                                cell.taskCount > 0 -> MaterialTheme.colorScheme.surfaceContainerLow
                                else -> Color.Transparent
                            }
                            val borderStroke = when {
                                cell.isSelected -> BorderStroke(1.5.dp, extended.goldMid)
                                cell.isToday -> BorderStroke(1.dp, extended.cardBorderGold)
                                else -> null
                            }
                            val textColor = when {
                                cell.isSelected -> extended.goldStart
                                cell.isToday -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onSurface
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(bgColor)
                                    .then(
                                        if (borderStroke != null) {
                                            Modifier.border(borderStroke, CircleShape)
                                        } else {
                                            Modifier
                                        }
                                    )
                                    .clickable { onSelectDay(cell) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = cell.dayOfMonth.toString(),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (cell.isToday || cell.isSelected) {
                                            FontWeight.Bold
                                        } else {
                                            FontWeight.Normal
                                        },
                                        color = textColor
                                    )
                                    if (cell.taskCount > 0) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                            if (cell.hasHighPriority) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(extended.goldMid)
                                                )
                                            }
                                            if (cell.hasPending) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.primary)
                                                )
                                            }
                                            if (cell.hasPostponed) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(extended.statusPlanned)
                                                )
                                            }
                                            if (cell.hasCompleted) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(extended.statusActive)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeeklyHeaderCard(
    weekRangeTitle: String,
    weekDensities: List<DayDensitySummary>,
    selectedDayMillis: Long,
    todayDayMillis: Long,
    onPrevWeek: () -> Unit,
    onNextWeek: () -> Unit,
    onSelectDay: (Long) -> Unit
) {
    val extended = DivamTheme.extendedColors

    DivamCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = weekRangeTitle,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Row {
                IconButton(
                    onClick = onPrevWeek,
                    modifier = Modifier.testTag("calendar_prev_week")
                ) {
                    Icon(Icons.Rounded.ChevronLeft, contentDescription = "Önceki hafta")
                }
                IconButton(
                    onClick = onNextWeek,
                    modifier = Modifier.testTag("calendar_next_week")
                ) {
                    Icon(Icons.Rounded.ChevronRight, contentDescription = "Sonraki hafta")
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            weekDensities.forEach { day ->
                val selected = day.dayMillis == selectedDayMillis
                val isToday = day.dayMillis == todayDayMillis
                Surface(
                    onClick = { onSelectDay(day.dayMillis) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerLow
                    },
                    border = when {
                        selected -> BorderStroke(1.5.dp, extended.goldMid)
                        isToday -> BorderStroke(1.dp, extended.cardBorderGold)
                        else -> BorderStroke(1.dp, extended.cardBorderSubtle)
                    }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = day.shortDayName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = day.dayNumber.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) extended.goldStart else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        day.highPriorityCount > 0 -> extended.goldMid
                                        day.totalCount > 0 -> MaterialTheme.colorScheme.primary
                                        else -> Color.Transparent
                                    }
                                )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyNavigatorHeaderCard(
    selectedDateFormatted: String,
    onPrevDay: () -> Unit,
    onNextDay: () -> Unit,
    onCreateTaskForDate: () -> Unit
) {
    val extended = DivamTheme.extendedColors

    DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onPrevDay,
                modifier = Modifier.testTag("calendar_prev_day")
            ) {
                Icon(Icons.Rounded.ChevronLeft, contentDescription = "Önceki gün")
            }
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = selectedDateFormatted,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
            IconButton(
                onClick = onNextDay,
                modifier = Modifier.testTag("calendar_next_day")
            ) {
                Icon(Icons.Rounded.ChevronRight, contentDescription = "Sonraki gün")
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = onCreateTaskForDate,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("calendar_daily_add_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = extended.goldMid,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Icon(imageVector = Icons.Rounded.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Bu Güne Yeni Görev Ekle", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SelectedDayTaskPanel(
    selectedDateFormatted: String,
    selectedDayMillis: Long,
    tasksForDay: List<TaskItem>,
    onToggleComplete: (Long) -> Unit,
    onEditTask: (Long) -> Unit,
    onRescheduleTask: (TaskItem) -> Unit,
    onCreateTaskForDate: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DivamCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarToday,
                        contentDescription = null,
                        tint = extended.goldMid,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "Seçili Tarih",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = selectedDateFormatted,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Button(
                    onClick = { onCreateTaskForDate(selectedDayMillis) },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = extended.goldMid,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("calendar_add_task_for_date_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ekle", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        if (tasksForDay.isEmpty()) {
            DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.EventNote,
                        contentDescription = null,
                        tint = extended.goldMid
                    )
                    Text(
                        text = "Bu tarihe planlanmış görev bulunmuyor.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            tasksForDay.forEach { task ->
                CalendarTaskCard(
                    task = task,
                    onToggleComplete = { onToggleComplete(task.id) },
                    onEdit = { onEditTask(task.id) },
                    onReschedule = { onRescheduleTask(task) }
                )
            }
        }
    }
}
