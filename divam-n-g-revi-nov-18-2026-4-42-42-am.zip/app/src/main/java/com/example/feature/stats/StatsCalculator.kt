package com.example.feature.stats

import androidx.compose.runtime.Immutable
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskStatus
import com.example.core.model.WeekStartDay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class StatsDateRangePreset(val turkishLabel: String) {
    TODAY("Bugün"),
    LAST_7_DAYS("Son 7 Gün"),
    LAST_30_DAYS("Son 30 Gün"),
    THIS_MONTH("Bu Ay"),
    CUSTOM("Özel Aralık")
}

@Immutable
data class CategoryStatItem(
    val categoryId: String,
    val categoryName: String,
    val totalCount: Int,
    val completedCount: Int
)

@Immutable
data class PriorityStatItem(
    val priority: TaskPriority,
    val totalCount: Int,
    val completedCount: Int
)

@Immutable
data class ChartPoint(
    val label: String,
    val dayMillis: Long,
    val completedCount: Int,
    val totalCount: Int
)

@Immutable
data class PeriodComparison(
    val currentCount: Int,
    val previousCount: Int,
    val deltaCount: Int,
    val deltaPercent: Int?
)

@Immutable
data class GoalProgress(
    val completed: Int,
    val target: Int
) {
    val ratio: Float
        get() = if (target <= 0) 0f else (completed.toFloat() / target.toFloat()).coerceIn(0f, 1f)
    val percent: Int
        get() = if (target <= 0) 0 else ((completed * 100) / target).coerceAtLeast(0)
}

@Immutable
data class ProductiveDayItem(
    val dayMillis: Long,
    val dateLabel: String,
    val completedCount: Int
)

@Immutable
data class StatsReportSnapshot(
    val totalActiveRecords: Int,
    val rangeFilteredTotalCount: Int,
    val rangeCompletedCount: Int,
    val rangeIncompleteCount: Int,
    val rangeCancelledCount: Int,
    val rangeCompletionPercent: Int,
    val dailyCompletedCount: Int,
    val dailyPendingCount: Int,
    val dailyOverdueCount: Int,
    val dailyCompletionPercent: Int,
    val weeklyCompletedCount: Int,
    val weeklyTotalCount: Int,
    val weeklyCompletionPercent: Int,
    val monthlyCompletedCount: Int,
    val monthlyTotalCount: Int,
    val monthlyCompletionPercent: Int,
    val topCategories: List<CategoryStatItem>,
    val priorityDistribution: List<PriorityStatItem>,
    val dailyProgressSeries: List<ChartPoint>,
    val weeklyPerformanceBars: List<ChartPoint>,
    val monthlyPerformanceBars: List<ChartPoint>,
    val weekComparison: PeriodComparison,
    val monthComparison: PeriodComparison,
    val dailyGoal: GoalProgress,
    val weeklyGoal: GoalProgress,
    val mostProductiveDays: List<ProductiveDayItem>,
    val historyFeed: List<TaskItem>,
    val rangeStartMillis: Long,
    val rangeEndMillis: Long
)

object StatsCalculator {
    private val trLocale: Locale = Locale.forLanguageTag("tr-TR")

    fun calculate(
        allTasks: List<TaskItem>,
        todayDayMillis: Long,
        rangePreset: StatsDateRangePreset,
        customStartDayMillis: Long?,
        customEndDayMillis: Long?,
        categoryFilterId: String?,
        weekStartDay: WeekStartDay,
        dailyGoalTarget: Int,
        weeklyGoalTarget: Int
    ): StatsReportSnapshot {
        // Silinmiş kayıtları hariç tut, ID ile tekilleştir (aynı görevi birden fazla sayma)
        val nonDeleted = allTasks
            .distinctBy { it.id }
            .filter { !it.isDeleted }
            .let { list ->
                if (categoryFilterId != null) {
                    list.filter { it.categoryId == categoryFilterId }
                } else {
                    list
                }
            }

        val (rangeStart, rangeEnd) = resolveDateRange(
            todayDayMillis = todayDayMillis,
            preset = rangePreset,
            customStart = customStartDayMillis,
            customEnd = customEndDayMillis
        )

        // Görevleri yerel güne eşle
        val rangeTasks = nonDeleted.filter { task ->
            val refDay = effectiveTaskReferenceDayMillis(task)
            refDay in rangeStart..rangeEnd
        }

        // Tamamlanan görevler (İptal edilen görevler ASLA tamamlanan sayılmaz)
        val rangeCompletedCount = rangeTasks.count { it.status == TaskStatus.COMPLETED }
        val rangeCancelledCount = rangeTasks.count { it.status == TaskStatus.CANCELLED }
        val rangeIncompleteCount = rangeTasks.count {
            it.status != TaskStatus.COMPLETED && it.status != TaskStatus.CANCELLED
        }
        val rangeActionable = rangeCompletedCount + rangeIncompleteCount
        val rangeCompletionPercent = if (rangeActionable == 0) 0 else (rangeCompletedCount * 100) / rangeActionable

        // 1-3, 6: Günlük istatistikler
        val todayTasks = nonDeleted.filter { isTaskScheduledOrCompletedOnDay(it, todayDayMillis) }
        val dailyCompletedCount = nonDeleted.count { task ->
            task.status == TaskStatus.COMPLETED &&
                completionLocalDayMillis(task) == todayDayMillis
        }
        val dailyPendingCount = todayTasks.count {
            it.status == TaskStatus.PENDING ||
                it.status == TaskStatus.IN_PROGRESS ||
                it.status == TaskStatus.POSTPONED
        }
        val dailyOverdueCount = nonDeleted.count { task ->
            task.status != TaskStatus.COMPLETED &&
                task.status != TaskStatus.CANCELLED &&
                task.startDateMillis != null &&
                task.startDateMillis < todayDayMillis
        }
        val dailyActionable = dailyCompletedCount + dailyPendingCount
        val dailyCompletionPercent = if (dailyActionable == 0) 0 else (dailyCompletedCount * 100) / dailyActionable

        // 4, 7, 15: Haftalık istatistikler & önceki hafta karşılaştırması
        val thisWeekStart = weekStartMillis(todayDayMillis, weekStartDay)
        val thisWeekEnd = TaskDateTimeUtils.addDaysToLocalDayMillis(thisWeekStart, 6)
        val prevWeekStart = TaskDateTimeUtils.addDaysToLocalDayMillis(thisWeekStart, -7)
        val prevWeekEnd = TaskDateTimeUtils.addDaysToLocalDayMillis(thisWeekStart, -1)

        val thisWeekTasks = nonDeleted.filter {
            effectiveTaskReferenceDayMillis(it) in thisWeekStart..thisWeekEnd
        }
        val weeklyCompletedCount = nonDeleted.count { task ->
            task.status == TaskStatus.COMPLETED &&
                completionLocalDayMillis(task) in thisWeekStart..thisWeekEnd
        }
        val weeklyActionable = thisWeekTasks.count { it.status != TaskStatus.CANCELLED }
        val weeklyCompletionPercent = if (weeklyActionable == 0) 0 else (weeklyCompletedCount * 100) / weeklyActionable

        val prevWeekCompletedCount = nonDeleted.count { task ->
            task.status == TaskStatus.COMPLETED &&
                completionLocalDayMillis(task) in prevWeekStart..prevWeekEnd
        }
        val weekComparison = buildComparison(weeklyCompletedCount, prevWeekCompletedCount)

        // 5, 8, 16: Aylık istatistikler & önceki ay karşılaştırması
        val (thisMonthStart, thisMonthEnd) = monthBoundsMillis(todayDayMillis, monthOffset = 0)
        val (prevMonthStart, prevMonthEnd) = monthBoundsMillis(todayDayMillis, monthOffset = -1)

        val thisMonthTasks = nonDeleted.filter {
            effectiveTaskReferenceDayMillis(it) in thisMonthStart..thisMonthEnd
        }
        val monthlyCompletedCount = nonDeleted.count { task ->
            task.status == TaskStatus.COMPLETED &&
                completionLocalDayMillis(task) in thisMonthStart..thisMonthEnd
        }
        val monthlyActionable = thisMonthTasks.count { it.status != TaskStatus.CANCELLED }
        val monthlyCompletionPercent = if (monthlyActionable == 0) 0 else (monthlyCompletedCount * 100) / monthlyActionable

        val prevMonthCompletedCount = nonDeleted.count { task ->
            task.status == TaskStatus.COMPLETED &&
                completionLocalDayMillis(task) in prevMonthStart..prevMonthEnd
        }
        val monthComparison = buildComparison(monthlyCompletedCount, prevMonthCompletedCount)

        // 9: En çok kullanılan kategoriler (seçili tarih aralığındaki verilerden)
        val topCategories = rangeTasks
            .groupBy { it.categoryId to it.categoryName }
            .map { (key, list) ->
                CategoryStatItem(
                    categoryId = key.first,
                    categoryName = key.second,
                    totalCount = list.size,
                    completedCount = list.count { it.status == TaskStatus.COMPLETED }
                )
            }
            .sortedByDescending { it.totalCount }

        // 10: Öncelik seviyelerine göre dağılım
        val priorityDistribution = TaskPriority.entries.map { priority ->
            val subset = rangeTasks.filter { it.priority == priority }
            PriorityStatItem(
                priority = priority,
                totalCount = subset.size,
                completedCount = subset.count { it.status == TaskStatus.COMPLETED }
            )
        }

        // 12: Günlük ilerleme grafiği (Son 7 günün günlük tamamlanan/toplam seyri)
        val shortDateFmt = SimpleDateFormat("d MMM", trLocale)
        val dailyProgressSeries = (-6..0).map { offset ->
            val d = TaskDateTimeUtils.addDaysToLocalDayMillis(todayDayMillis, offset)
            val scheduled = nonDeleted.count {
                it.status != TaskStatus.CANCELLED && TaskDateTimeUtils.isTaskOnDay(it, d)
            }
            val done = nonDeleted.count {
                it.status == TaskStatus.COMPLETED && completionLocalDayMillis(it) == d
            }
            ChartPoint(
                label = shortDateFmt.format(Date(d)),
                dayMillis = d,
                completedCount = done,
                totalCount = maxOf(scheduled, done)
            )
        }

        // 13: Haftalık performans grafiği (Bu haftanın 7 günü)
        val dayNameFmt = SimpleDateFormat("EEE", trLocale)
        val weeklyPerformanceBars = (0..6).map { idx ->
            val d = TaskDateTimeUtils.addDaysToLocalDayMillis(thisWeekStart, idx)
            val scheduled = nonDeleted.count {
                it.status != TaskStatus.CANCELLED && TaskDateTimeUtils.isTaskOnDay(it, d)
            }
            val done = nonDeleted.count {
                it.status == TaskStatus.COMPLETED && completionLocalDayMillis(it) == d
            }
            val label = dayNameFmt.format(Date(d))
                .replace(".", "")
                .replaceFirstChar { if (it.isLowerCase()) it.titlecase(trLocale) else it.toString() }
            ChartPoint(
                label = label,
                dayMillis = d,
                completedCount = done,
                totalCount = maxOf(scheduled, done)
            )
        }

        // 14: Aylık performans grafiği (Bu ayın haftalık dilimleri)
        val monthlyPerformanceBars = buildMonthlyWeekBuckets(
            tasks = nonDeleted,
            monthStartMillis = thisMonthStart,
            monthEndMillis = thisMonthEnd
        )

        // 19: En verimli günler
        val longFmt = SimpleDateFormat("d MMM yyyy, EEE", trLocale)
        val mostProductiveDays = nonDeleted
            .filter { it.status == TaskStatus.COMPLETED }
            .groupBy { completionLocalDayMillis(it) }
            .map { (dayMs, list) ->
                ProductiveDayItem(
                    dayMillis = dayMs,
                    dateLabel = longFmt.format(Date(dayMs)),
                    completedCount = list.size
                )
            }
            .sortedWith(compareByDescending<ProductiveDayItem> { it.completedCount }.thenByDescending { it.dayMillis })
            .take(5)

        // 20: Görev geçmişi
        val historyFeed = rangeTasks
            .sortedByDescending { it.completedAtMillis ?: it.updatedAtMillis }
            .take(40)

        return StatsReportSnapshot(
            totalActiveRecords = nonDeleted.size,
            rangeFilteredTotalCount = rangeTasks.size,
            rangeCompletedCount = rangeCompletedCount,
            rangeIncompleteCount = rangeIncompleteCount,
            rangeCancelledCount = rangeCancelledCount,
            rangeCompletionPercent = rangeCompletionPercent,
            dailyCompletedCount = dailyCompletedCount,
            dailyPendingCount = dailyPendingCount,
            dailyOverdueCount = dailyOverdueCount,
            dailyCompletionPercent = dailyCompletionPercent,
            weeklyCompletedCount = weeklyCompletedCount,
            weeklyTotalCount = weeklyActionable,
            weeklyCompletionPercent = weeklyCompletionPercent,
            monthlyCompletedCount = monthlyCompletedCount,
            monthlyTotalCount = monthlyActionable,
            monthlyCompletionPercent = monthlyCompletionPercent,
            topCategories = topCategories,
            priorityDistribution = priorityDistribution,
            dailyProgressSeries = dailyProgressSeries,
            weeklyPerformanceBars = weeklyPerformanceBars,
            monthlyPerformanceBars = monthlyPerformanceBars,
            weekComparison = weekComparison,
            monthComparison = monthComparison,
            dailyGoal = GoalProgress(completed = dailyCompletedCount, target = dailyGoalTarget),
            weeklyGoal = GoalProgress(completed = weeklyCompletedCount, target = weeklyGoalTarget),
            mostProductiveDays = mostProductiveDays,
            historyFeed = historyFeed,
            rangeStartMillis = rangeStart,
            rangeEndMillis = rangeEnd
        )
    }

    fun epochToLocalDayMillis(epochMillis: Long): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        return TaskDateTimeUtils.localDayMillis(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun completionLocalDayMillis(task: TaskItem): Long {
        val completedEpoch = task.completedAtMillis
        return when {
            completedEpoch != null -> epochToLocalDayMillis(completedEpoch)
            task.endDateMillis != null -> task.endDateMillis
            task.startDateMillis != null -> task.startDateMillis
            else -> epochToLocalDayMillis(task.updatedAtMillis)
        }
    }

    private fun effectiveTaskReferenceDayMillis(task: TaskItem): Long {
        return if (task.status == TaskStatus.COMPLETED && task.completedAtMillis != null) {
            epochToLocalDayMillis(task.completedAtMillis)
        } else {
            task.startDateMillis ?: task.endDateMillis ?: epochToLocalDayMillis(task.createdAtMillis)
        }
    }

    private fun isTaskScheduledOrCompletedOnDay(task: TaskItem, dayMillis: Long): Boolean {
        if (TaskDateTimeUtils.isTaskOnDay(task, dayMillis)) return true
        return task.status == TaskStatus.COMPLETED && completionLocalDayMillis(task) == dayMillis
    }

    private fun resolveDateRange(
        todayDayMillis: Long,
        preset: StatsDateRangePreset,
        customStart: Long?,
        customEnd: Long?
    ): Pair<Long, Long> {
        return when (preset) {
            StatsDateRangePreset.TODAY -> todayDayMillis to todayDayMillis
            StatsDateRangePreset.LAST_7_DAYS ->
                TaskDateTimeUtils.addDaysToLocalDayMillis(todayDayMillis, -6) to todayDayMillis
            StatsDateRangePreset.LAST_30_DAYS ->
                TaskDateTimeUtils.addDaysToLocalDayMillis(todayDayMillis, -29) to todayDayMillis
            StatsDateRangePreset.THIS_MONTH -> monthBoundsMillis(todayDayMillis, monthOffset = 0)
            StatsDateRangePreset.CUSTOM -> {
                val start = customStart ?: TaskDateTimeUtils.addDaysToLocalDayMillis(todayDayMillis, -6)
                val end = customEnd ?: todayDayMillis
                if (start <= end) start to end else end to start
            }
        }
    }

    private fun weekStartMillis(dayMillis: Long, weekStartDay: WeekStartDay): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = dayMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val target = weekStartDay.calendarConstant
        val diff = (dow - target + 7) % 7
        cal.add(Calendar.DAY_OF_MONTH, -diff)
        return cal.timeInMillis
    }

    private fun monthBoundsMillis(refDayMillis: Long, monthOffset: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply {
            timeInMillis = refDayMillis
            add(Calendar.MONTH, monthOffset)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val end = TaskDateTimeUtils.localDayMillis(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            maxDay
        )
        return start to end
    }

    private fun buildMonthlyWeekBuckets(
        tasks: List<TaskItem>,
        monthStartMillis: Long,
        monthEndMillis: Long
    ): List<ChartPoint> {
        val buckets = mutableListOf<ChartPoint>()
        var cursor = monthStartMillis
        var weekIdx = 1
        while (cursor <= monthEndMillis && weekIdx <= 5) {
            val bucketEnd = minOf(
                TaskDateTimeUtils.addDaysToLocalDayMillis(cursor, 6),
                monthEndMillis
            )
            val total = tasks.count {
                it.status != TaskStatus.CANCELLED &&
                    effectiveTaskReferenceDayMillis(it) in cursor..bucketEnd
            }
            val done = tasks.count {
                it.status == TaskStatus.COMPLETED &&
                    completionLocalDayMillis(it) in cursor..bucketEnd
            }
            buckets.add(
                ChartPoint(
                    label = "$weekIdx. Hft",
                    dayMillis = cursor,
                    completedCount = done,
                    totalCount = maxOf(total, done)
                )
            )
            cursor = TaskDateTimeUtils.addDaysToLocalDayMillis(bucketEnd, 1)
            weekIdx++
        }
        return buckets
    }

    private fun buildComparison(current: Int, previous: Int): PeriodComparison {
        val delta = current - previous
        val pct = if (previous == 0) {
            if (current == 0) 0 else null
        } else {
            ((delta * 100.0) / previous.toDouble()).toInt()
        }
        return PeriodComparison(
            currentCount = current,
            previousCount = previous,
            deltaCount = delta,
            deltaPercent = pct
        )
    }
}
