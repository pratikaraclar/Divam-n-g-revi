package com.example.feature.security

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.designsystem.components.DivamLogoMark
import com.example.core.designsystem.components.DivamLuxuryBackground
import com.example.core.security.AppSecurityHelper
import com.example.ui.theme.DivamTheme

@Composable
fun AppLockScreen(
    biometricEnabled: Boolean,
    onVerifyPin: (String) -> Boolean,
    onBiometricUnlocked: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Kilit ekranındayken geri tuşunun kilidi atlamasını engelle
    BackHandler(enabled = true) {}

    val context = LocalContext.current
    val extended = DivamTheme.extendedColors
    val canBiometric = remember(context, biometricEnabled) {
        biometricEnabled && AppSecurityHelper.canUseBiometricAuthentication(context)
    }

    var enteredPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val triggerBiometric: () -> Unit = {
        AppSecurityHelper.authenticateWithBiometric(
            context = context,
            onSuccess = onBiometricUnlocked,
            onError = { msg -> errorMessage = msg }
        )
    }

    LaunchedEffect(canBiometric) {
        if (canBiometric) {
            triggerBiometric()
        }
    }

    val submitPin: (String) -> Unit = { pinToCheck ->
        if (pinToCheck.length < 4) {
            errorMessage = "PIN en az 4 haneli olmalıdır."
        } else if (onVerifyPin(pinToCheck)) {
            errorMessage = null
            enteredPin = ""
        } else {
            errorMessage = "Girilen PIN hatalı. Lütfen tekrar deneyin."
            enteredPin = ""
        }
    }

    DivamLuxuryBackground(modifier = modifier.fillMaxSize().testTag("screen_app_lock")) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            DivamCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp),
                highlightGoldBorder = true
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    com.example.core.designsystem.components.DivamCrestWordmarkLogo(crestSize = 68.dp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = extended.goldMid,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Uygulama Kilidi",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Devam etmek için 4–6 haneli PIN kodunuzu girin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Maskeli PIN noktaları
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (index in 0 until 6) {
                            val filled = index < enteredPin.length
                            Box(
                                modifier = Modifier
                                    .size(if (filled) 16.dp else 14.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (filled) extended.goldMid
                                        else MaterialTheme.colorScheme.surfaceContainerLow
                                    )
                                    .border(
                                        width = 1.5.dp,
                                        color = if (filled) extended.goldStart else extended.cardBorderSubtle,
                                        shape = CircleShape
                                    )
                            )
                        }
                    }

                    if (!errorMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    // Sayısal Tuş Takımı (1–9, Sil, 0, Onayla)
                    val rows = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9")
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        rows.forEach { rowDigits ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                rowDigits.forEach { digit ->
                                    PinPadButton(
                                        label = digit,
                                        onClick = {
                                            if (enteredPin.length < 6) {
                                                errorMessage = null
                                                enteredPin += digit
                                            }
                                        },
                                        modifier = Modifier.testTag("pin_key_$digit")
                                    )
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                onClick = {
                                    if (enteredPin.isNotEmpty()) {
                                        enteredPin = enteredPin.dropLast(1)
                                    }
                                    errorMessage = null
                                },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                border = BorderStroke(1.dp, extended.cardBorderSubtle),
                                modifier = Modifier
                                    .size(64.dp)
                                    .testTag("pin_key_backspace")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Backspace,
                                        contentDescription = "Sil",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            PinPadButton(
                                label = "0",
                                onClick = {
                                    if (enteredPin.length < 6) {
                                        errorMessage = null
                                        enteredPin += "0"
                                    }
                                },
                                modifier = Modifier.testTag("pin_key_0")
                            )

                            Surface(
                                onClick = { submitPin(enteredPin) },
                                shape = CircleShape,
                                color = extended.goldMid,
                                modifier = Modifier
                                    .size(64.dp)
                                    .testTag("pin_key_submit")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Aç",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { submitPin(enteredPin) },
                        enabled = enteredPin.length >= 4,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = extended.goldMid,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("pin_unlock_button")
                    ) {
                        Text("Kilidi Aç", fontWeight = FontWeight.Bold)
                    }

                    if (canBiometric) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = triggerBiometric,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, extended.goldMid),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("biometric_unlock_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Fingerprint,
                                contentDescription = null,
                                tint = extended.goldMid,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Biyometrik Doğrulama ile Aç", color = extended.goldMid)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PinPadButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, extended.cardBorderSubtle),
        modifier = modifier.size(64.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
