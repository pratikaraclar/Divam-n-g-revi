package com.example.feature.tasks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.NotificationSettings
import com.example.core.model.TaskCategory
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import com.example.core.model.WindowWidthClass
import com.example.ui.theme.DivamTheme
import kotlinx.coroutines.launch

@Immutable
data class TaskFormState(
    val title: String = "",
    val description: String = "",
    val note: String = "",
    val startDateMillis: Long? = TaskDateTimeUtils.todayLocalDayMillis(),
    val endDateMillis: Long? = null,
    val startTimeMinutes: Int? = null,
    val endTimeMinutes: Int? = null,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val categoryId: String = "cat_is",
    val categoryName: String = "İş",
    val status: TaskStatus = TaskStatus.PENDING,
    val isFavorite: Boolean = false,
    val reminderEnabled: Boolean = true,
    val reminderOffsetsMinutes: List<Int> = listOf(15),
    val recurrence: TaskRecurrence = TaskRecurrence.NONE,
    val titleError: String? = null,
    val scheduleError: String? = null
)

private enum class DateFieldTarget { START, END }
private enum class TimeFieldTarget { START, END }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TaskFormComponent(
    state: TaskFormState,
    categories: List<TaskCategory>,
    widthClass: WindowWidthClass,
    isEditing: Boolean,
    onStateChange: (TaskFormState) -> Unit,
    onCreateCategory: suspend (String) -> Result<TaskCategory>,
    onSubmit: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeDatePicker by remember { mutableStateOf<DateFieldTarget?>(null) }
    var activeTimePicker by remember { mutableStateOf<TimeFieldTarget?>(null) }
    var showNewCategoryDialog by remember { mutableStateOf(false) }
    var showCustomOffsetDialog by remember { mutableStateOf(false) }

    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences
    val coroutineScope = rememberCoroutineScope()

    val primarySection: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            DivamCard(modifier = Modifier.fillMaxWidth(), highlightGoldBorder = true) {
                Text(
                    text = "Temel Bilgiler",
                    style = MaterialTheme.typography.titleMedium,
                    color = extended.goldMid
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = state.title,
                    onValueChange = { next ->
                        if (next.length <= 120) {
                            onStateChange(state.copy(title = next, titleError = null))
                        }
                    },
                    label = { Text("Görev Başlığı *") },
                    placeholder = { Text("Örn. Haftalık strateji sunumunu hazırla") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Title,
                            contentDescription = null,
                            tint = extended.goldMid
                        )
                    },
                    isError = state.titleError != null,
                    supportingText = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(state.titleError ?: "Kısa ve net bir görev adı girin")
                            Text("${state.title.length}/120")
                        }
                    },
                    singleLine = true,
                    colors = divamTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_form_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = state.description,
                    onValueChange = { next ->
                        if (next.length <= 600) {
                            onStateChange(state.copy(description = next))
                        }
                    },
                    label = { Text("Açıklama") },
                    placeholder = { Text("Görevin kapsamını, hedeflerini veya adımlarını yazın") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Description,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    minLines = 3,
                    maxLines = 5,
                    colors = divamTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_form_description_input")
                )
            }

            DivamCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Özel Not ve Öne Çıkarma",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = state.note,
                    onValueChange = { next ->
                        if (next.length <= 500) {
                            onStateChange(state.copy(note = next))
                        }
                    },
                    label = { Text("Özel Not") },
                    placeholder = { Text("Ek hatırlatma, kişi bilgisi veya referans notu ekleyin") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.StickyNote2,
                            contentDescription = null,
                            tint = extended.goldMid
                        )
                    },
                    minLines = 2,
                    maxLines = 4,
                    colors = divamTextFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_form_note_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    onClick = { onStateChange(state.copy(isFavorite = !state.isFavorite)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("task_form_favorite_toggle"),
                    shape = RoundedCornerShape(14.dp),
                    color = if (state.isFavorite) {
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerLow
                    },
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (state.isFavorite) extended.goldMid else extended.cardBorderSubtle
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = if (state.isFavorite) Icons.Rounded.Star else Icons.Outlined.StarOutline,
                            contentDescription = null,
                            tint = if (state.isFavorite) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Favori Görev",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Favoriler sekmesinde öncelikli olarak listelensin",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = state.isFavorite,
                            onCheckedChange = { checked ->
                                onStateChange(state.copy(isFavorite = checked))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                checkedTrackColor = extended.goldMid
                            )
                        )
                    }
                }
            }
        }
    }

    val scheduleAndClassificationSection: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            DivamCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Tarih ve Saat Planı",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PickerValueTile(
                        label = "Başlangıç Tarihi",
                        valueText = state.startDateMillis?.let {
                            TaskDateTimeUtils.formatDateTurkish(it, userPrefs.dateFormatStyle)
                        } ?: "Seçilmedi",
                        icon = Icons.Rounded.CalendarToday,
                        hasValue = state.startDateMillis != null,
                        onPick = { activeDatePicker = DateFieldTarget.START },
                        onClear = {
                            onStateChange(state.copy(startDateMillis = null, scheduleError = null))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("task_form_start_date")
                    )
                    PickerValueTile(
                        label = "Bitiş Tarihi",
                        valueText = state.endDateMillis?.let {
                            TaskDateTimeUtils.formatDateTurkish(it, userPrefs.dateFormatStyle)
                        } ?: "Seçilmedi",
                        icon = Icons.Rounded.CalendarToday,
                        hasValue = state.endDateMillis != null,
                        onPick = { activeDatePicker = DateFieldTarget.END },
                        onClear = {
                            onStateChange(state.copy(endDateMillis = null, scheduleError = null))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("task_form_end_date")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PickerValueTile(
                        label = "Başlangıç Saati",
                        valueText = state.startTimeMinutes?.let {
                            TaskDateTimeUtils.formatTimeMinutes(it, userPrefs.use24HourFormat)
                        } ?: "Seçilmedi",
                        icon = Icons.Rounded.Schedule,
                        hasValue = state.startTimeMinutes != null,
                        onPick = { activeTimePicker = TimeFieldTarget.START },
                        onClear = {
                            onStateChange(state.copy(startTimeMinutes = null, scheduleError = null))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("task_form_start_time")
                    )
                    PickerValueTile(
                        label = "Bitiş Saati",
                        valueText = state.endTimeMinutes?.let {
                            TaskDateTimeUtils.formatTimeMinutes(it, userPrefs.use24HourFormat)
                        } ?: "Seçilmedi",
                        icon = Icons.Rounded.Schedule,
                        hasValue = state.endTimeMinutes != null,
                        onPick = { activeTimePicker = TimeFieldTarget.END },
                        onClear = {
                            onStateChange(state.copy(endTimeMinutes = null, scheduleError = null))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("task_form_end_time")
                    )
                }

                if (state.scheduleError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.scheduleError,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            DivamCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Flag,
                        contentDescription = null,
                        tint = extended.goldMid,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Öncelik Düzeyi",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TaskPriority.entries.forEach { priority ->
                        val selected = state.priority == priority
                        SelectableLuxuryChip(
                            label = priority.turkishLabel,
                            selected = selected,
                            onClick = { onStateChange(state.copy(priority = priority)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("task_form_priority_${priority.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Görev Durumu",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TaskStatus.entries.forEach { status ->
                        SelectableLuxuryChip(
                            label = status.turkishLabel,
                            selected = state.status == status,
                            onClick = { onStateChange(state.copy(status = status)) },
                            modifier = Modifier.testTag("task_form_status_${status.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kategori",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(
                        onClick = { showNewCategoryDialog = true },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("task_form_add_category_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = extended.goldMid,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Özel Kategori",
                            style = MaterialTheme.typography.labelLarge,
                            color = extended.goldMid
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        SelectableLuxuryChip(
                            label = cat.name,
                            selected = state.categoryId == cat.id,
                            onClick = {
                                onStateChange(
                                    state.copy(
                                        categoryId = cat.id,
                                        categoryName = cat.name
                                    )
                                )
                            },
                            modifier = Modifier.testTag("task_form_category_${cat.id}")
                        )
                    }
                }
            }

            DivamCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.NotificationsActive,
                            contentDescription = null,
                            tint = extended.goldMid,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Hatırlatma ve Tekrar",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Switch(
                        checked = state.reminderEnabled,
                        onCheckedChange = { enabled ->
                            onStateChange(state.copy(reminderEnabled = enabled))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = extended.goldMid
                        ),
                        modifier = Modifier.testTag("task_form_reminder_switch")
                    )
                }

                if (state.reminderEnabled) {
                    Spacer(modifier = Modifier.height(8.dp))
                    if (state.startDateMillis == null || state.startTimeMinutes == null) {
                        Text(
                            text = "Yerel bildirim planlanabilmesi için yukarıdan başlangıç tarihi ve saati seçin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = extended.statusPlanned
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Hatırlatma Zamanları",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(
                            onClick = { showCustomOffsetDialog = true },
                            modifier = Modifier.testTag("task_form_add_custom_offset")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = null,
                                tint = extended.goldMid,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Özel Süre", color = extended.goldMid)
                        }
                    }

                    val allDisplayedOffsets = remember(state.reminderOffsetsMinutes) {
                        (NotificationSettings.PRESET_OFFSETS_MINUTES + state.reminderOffsetsMinutes)
                            .distinct()
                            .sorted()
                    }
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allDisplayedOffsets.forEach { offset ->
                            val selected = offset in state.reminderOffsetsMinutes
                            SelectableLuxuryChip(
                                label = TaskDateTimeUtils.formatReminderOffsetTurkish(offset),
                                selected = selected,
                                onClick = {
                                    val next = if (selected) {
                                        state.reminderOffsetsMinutes - offset
                                    } else {
                                        (state.reminderOffsetsMinutes + offset).distinct().sorted()
                                    }
                                    onStateChange(state.copy(reminderOffsetsMinutes = next))
                                },
                                modifier = Modifier.testTag("task_form_offset_$offset")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Repeat,
                        contentDescription = null,
                        tint = extended.goldMid,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Tekrarlama Sıklığı",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TaskRecurrence.entries.forEach { recurrence ->
                        SelectableLuxuryChip(
                            label = recurrence.turkishLabel,
                            selected = state.recurrence == recurrence,
                            onClick = { onStateChange(state.copy(recurrence = recurrence)) },
                            modifier = Modifier.testTag("task_form_recurrence_${recurrence.name.lowercase()}")
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        if (widthClass.isTabletOrWide) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(modifier = Modifier.weight(1f)) { primarySection() }
                Box(modifier = Modifier.weight(1f)) { scheduleAndClassificationSection() }
            }
        } else {
            primarySection()
            scheduleAndClassificationSection()
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("task_form_cancel_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, extended.cardBorderSubtle)
            ) {
                Text(
                    text = "Vazgeç",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Button(
                onClick = onSubmit,
                modifier = Modifier
                    .weight(1.4f)
                    .height(52.dp)
                    .testTag("task_form_submit_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text(
                    text = if (isEditing) "Değişiklikleri Kaydet" else "Görevi Oluştur",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }

    // --- Tarih Seçici ---
    activeDatePicker?.let { target ->
        val initialLocal = when (target) {
            DateFieldTarget.START -> state.startDateMillis ?: TaskDateTimeUtils.todayLocalDayMillis()
            DateFieldTarget.END -> state.endDateMillis ?: state.startDateMillis ?: TaskDateTimeUtils.todayLocalDayMillis()
        }
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = TaskDateTimeUtils.localDayMillisToUtcPickerMillis(initialLocal)
        )
        DatePickerDialog(
            onDismissRequest = { activeDatePicker = null },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedUtc = datePickerState.selectedDateMillis
                        if (selectedUtc != null) {
                            val localMillis = TaskDateTimeUtils.utcPickerMillisToLocalDayMillis(selectedUtc)
                            val updated = when (target) {
                                DateFieldTarget.START -> {
                                    val end = state.endDateMillis
                                    if (end != null && end < localMillis) {
                                        state.copy(
                                            startDateMillis = localMillis,
                                            endDateMillis = localMillis,
                                            scheduleError = null
                                        )
                                    } else {
                                        state.copy(startDateMillis = localMillis, scheduleError = null)
                                    }
                                }
                                DateFieldTarget.END -> {
                                    val start = state.startDateMillis
                                    if (start != null && localMillis < start) {
                                        state.copy(
                                            scheduleError = "Bitiş tarihi başlangıç tarihinden önce olamaz."
                                        )
                                    } else {
                                        state.copy(endDateMillis = localMillis, scheduleError = null)
                                    }
                                }
                            }
                            onStateChange(updated)
                        }
                        activeDatePicker = null
                    }
                ) {
                    Text("Seç", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeDatePicker = null }) {
                    Text("İptal")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // --- Saat Seçici ---
    activeTimePicker?.let { target ->
        val currentMinutes = when (target) {
            TimeFieldTarget.START -> state.startTimeMinutes ?: (9 * 60)
            TimeFieldTarget.END -> state.endTimeMinutes ?: ((state.startTimeMinutes ?: 9 * 60) + 60).coerceAtMost(23 * 60 + 59)
        }
        val timePickerState = rememberTimePickerState(
            initialHour = currentMinutes / 60,
            initialMinute = currentMinutes % 60,
            is24Hour = userPrefs.use24HourFormat
        )
        AlertDialog(
            onDismissRequest = { activeTimePicker = null },
            title = {
                Text(
                    text = if (target == TimeFieldTarget.START) "Başlangıç Saati" else "Bitiş Saati",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    TimePicker(state = timePickerState)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val mins = timePickerState.hour * 60 + timePickerState.minute
                        val updated = when (target) {
                            TimeFieldTarget.START -> state.copy(
                                startTimeMinutes = mins,
                                scheduleError = null
                            )
                            TimeFieldTarget.END -> {
                                val sameDay = state.startDateMillis == null ||
                                    state.endDateMillis == null ||
                                    state.startDateMillis == state.endDateMillis
                                if (sameDay && state.startTimeMinutes != null && mins < state.startTimeMinutes) {
                                    state.copy(
                                        scheduleError = "Aynı günde bitiş saati başlangıç saatinden önce olamaz."
                                    )
                                } else {
                                    state.copy(endTimeMinutes = mins, scheduleError = null)
                                }
                            }
                        }
                        onStateChange(updated)
                        activeTimePicker = null
                    }
                ) {
                    Text("Tamam", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeTimePicker = null }) {
                    Text("İptal")
                }
            }
        )
    }

    // --- Özel Kategori Oluşturma Penceresi ---
    if (showNewCategoryDialog) {
        var newCatName by remember { mutableStateOf("") }
        var catError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showNewCategoryDialog = false },
            title = {
                Text(
                    text = "Yeni Kategori Oluştur",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Oluşturduğunuz kategori tüm görevlerde kalıcı olarak kullanılabilir.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = newCatName,
                        onValueChange = {
                            if (it.length <= 32) {
                                newCatName = it
                                catError = null
                            }
                        },
                        label = { Text("Kategori Adı") },
                        placeholder = { Text("Örn. Finans, Proje, Seyahat") },
                        singleLine = true,
                        isError = catError != null,
                        supportingText = catError?.let { err -> { Text(err) } },
                        colors = divamTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_category_name_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        coroutineScope.launch {
                            val res = onCreateCategory(newCatName)
                            res.onSuccess { created ->
                                onStateChange(
                                    state.copy(
                                        categoryId = created.id,
                                        categoryName = created.name
                                    )
                                )
                                showNewCategoryDialog = false
                            }.onFailure { err ->
                                catError = err.message ?: "Kategori oluşturulamadı."
                            }
                        }
                    },
                    modifier = Modifier.testTag("confirm_new_category_button")
                ) {
                    Text("Oluştur", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewCategoryDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // --- Özel Hatırlatma Süresi Penceresi ---
    if (showCustomOffsetDialog) {
        var minutesText by remember { mutableStateOf("") }
        var offsetError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showCustomOffsetDialog = false },
            title = { Text("Özel Hatırlatma Süresi") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Görev başlangıç saatinden kaç dakika önce hatırlatılmasını istersiniz? (1 – 10080 dakika)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = minutesText,
                        onValueChange = { raw ->
                            minutesText = raw.filter { it.isDigit() }.take(5)
                            offsetError = null
                        },
                        label = { Text("Dakika") },
                        placeholder = { Text("Örn. 45 veya 120") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isError = offsetError != null,
                        supportingText = offsetError?.let { err -> { Text(err) } },
                        colors = divamTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val parsed = minutesText.toIntOrNull()
                        if (parsed == null || parsed !in 1..10_080) {
                            offsetError = "Lütfen 1 ile 10080 dakika arasında bir değer girin."
                        } else {
                            onStateChange(
                                state.copy(
                                    reminderEnabled = true,
                                    reminderOffsetsMinutes = (state.reminderOffsetsMinutes + parsed)
                                        .distinct()
                                        .sorted()
                                )
                            )
                            showCustomOffsetDialog = false
                        }
                    }
                ) {
                    Text("Ekle", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomOffsetDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }
}

@Composable
private fun PickerValueTile(
    label: String,
    valueText: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    hasValue: Boolean,
    onPick: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    Surface(
        onClick = onPick,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(
            width = 1.dp,
            color = if (hasValue) extended.cardBorderGold else extended.cardBorderSubtle
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (hasValue) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = valueText,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (hasValue) FontWeight.SemiBold else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (hasValue) {
                IconButton(
                    onClick = onClear,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Clear,
                        contentDescription = "$label temizle",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectableLuxuryChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val container = if (selected) {
        MaterialTheme.colorScheme.secondaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceContainerLow
    }
    val borderColor = if (selected) extended.goldMid else extended.cardBorderSubtle
    val textColor = if (selected) extended.goldStart else MaterialTheme.colorScheme.onSurface

    Surface(
        onClick = onClick,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(12.dp),
        color = container,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun divamTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = DivamTheme.extendedColors.goldMid,
    unfocusedBorderColor = DivamTheme.extendedColors.cardBorderSubtle,
    focusedLabelColor = DivamTheme.extendedColors.goldMid,
    cursorColor = DivamTheme.extendedColors.goldMid,
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent
)
