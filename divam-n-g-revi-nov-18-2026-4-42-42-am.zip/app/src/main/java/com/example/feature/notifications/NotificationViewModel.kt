package com.example.feature.notifications

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.local.DivamDatabase
import com.example.core.data.local.NotificationDao
import com.example.core.data.preferences.NotificationPreferencesRepository
import com.example.core.model.ChannelSystemInspection
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationDeliveryStatus
import com.example.core.model.NotificationHistoryItem
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationSoundCatalog
import com.example.core.model.NotificationSoundOption
import com.example.core.model.QuietHoursPolicy
import com.example.core.model.ScheduledReminderItem
import com.example.core.notifications.AndroidTaskReminderScheduler
import com.example.core.notifications.NotificationChannelHelper
import com.example.core.notifications.TaskSoundManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotificationViewModel(
    private val appContext: Context,
    private val prefsRepository: NotificationPreferencesRepository,
    private val notificationDao: NotificationDao,
    private val scheduler: AndroidTaskReminderScheduler
) : ViewModel() {

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _availableSounds = MutableStateFlow<List<NotificationSoundOption>>(
        NotificationSoundCatalog.BUILT_IN_SOUNDS
    )
    val availableSounds: StateFlow<List<NotificationSoundOption>> = _availableSounds.asStateFlow()

    private val _channelInspections = MutableStateFlow<List<ChannelSystemInspection>>(emptyList())
    val channelInspections: StateFlow<List<ChannelSystemInspection>> = _channelInspections.asStateFlow()

    val playingSoundId: StateFlow<String?> = TaskSoundManager.playingSoundId

    val settings: StateFlow<NotificationSettings> = prefsRepository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = NotificationSettings()
        )

    val history: StateFlow<List<NotificationHistoryItem>> = notificationDao.observeNotificationHistory()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val scheduledReminders: StateFlow<List<ScheduledReminderItem>> = notificationDao.observeScheduledReminders()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    init {
        refreshSystemState()
    }

    fun refreshSystemState() {
        viewModelScope.launch(Dispatchers.IO) {
            _availableSounds.value = TaskSoundManager.loadAvailableSounds(appContext)
            val snap = prefsRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            _channelInspections.value = NotificationChannelHelper.inspectSystemChannels(appContext, snap)
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        updateAndResync { it.copy(notificationsEnabled = enabled) }
    }

    fun toggleDefaultOffset(offsetMinutes: Int) {
        updateAndResync { current ->
            val exists = offsetMinutes in current.defaultReminderOffsets
            val nextOffsets = if (exists) {
                current.defaultReminderOffsets - offsetMinutes
            } else {
                (current.defaultReminderOffsets + offsetMinutes).distinct().sorted()
            }
            current.copy(defaultReminderOffsets = nextOffsets)
        }
    }

    fun addCustomDefaultOffset(offsetMinutes: Int) {
        if (offsetMinutes < 0) return
        updateAndResync { current ->
            current.copy(
                defaultReminderOffsets = (current.defaultReminderOffsets + offsetMinutes).distinct().sorted()
            )
        }
    }

    fun setMorningSummary(enabled: Boolean? = null, minuteOfDay: Int? = null) {
        updateAndResync { current ->
            current.copy(
                morningSummaryEnabled = enabled ?: current.morningSummaryEnabled,
                morningSummaryMinutes = minuteOfDay ?: current.morningSummaryMinutes
            )
        }
    }

    fun setEveningIncomplete(enabled: Boolean? = null, minuteOfDay: Int? = null) {
        updateAndResync { current ->
            current.copy(
                eveningIncompleteEnabled = enabled ?: current.eveningIncompleteEnabled,
                eveningIncompleteMinutes = minuteOfDay ?: current.eveningIncompleteMinutes
            )
        }
    }

    fun setQuietHours(
        enabled: Boolean? = null,
        startMinutes: Int? = null,
        endMinutes: Int? = null,
        policy: QuietHoursPolicy? = null
    ) {
        updateAndSyncChannels { current ->
            current.copy(
                quietHoursEnabled = enabled ?: current.quietHoursEnabled,
                quietHoursStartMinutes = startMinutes ?: current.quietHoursStartMinutes,
                quietHoursEndMinutes = endMinutes ?: current.quietHoursEndMinutes,
                quietHoursPolicy = policy ?: current.quietHoursPolicy
            )
        }
    }

    fun setGlobalSoundEnabled(enabled: Boolean) {
        updateAndBumpChannelVersion { it.copy(soundEnabled = enabled) }
    }

    fun setGlobalVibrationEnabled(enabled: Boolean) {
        updateAndBumpChannelVersion { it.copy(vibrationEnabled = enabled) }
    }

    fun setSilentNotificationMode(enabled: Boolean) {
        updateAndBumpChannelVersion { it.copy(silentNotificationMode = enabled) }
    }

    fun setCompletionSoundEnabled(enabled: Boolean) {
        updateAndSyncChannels { it.copy(completionSoundEnabled = enabled) }
    }

    fun selectChannelSound(kind: NotificationChannelKind, soundId: String) {
        viewModelScope.launch {
            prefsRepository.updateChannelConfig(kind) { cfg ->
                cfg.copy(soundId = soundId)
            }
            val snap = prefsRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            _channelInspections.value = NotificationChannelHelper.inspectSystemChannels(appContext, snap)
            _messages.tryEmit("${kind.turkishTitle} sesi güncellendi")
        }
    }

    fun setChannelSoundEnabled(kind: NotificationChannelKind, enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.updateChannelConfig(kind) { it.copy(soundEnabled = enabled) }
            val snap = prefsRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            _channelInspections.value = NotificationChannelHelper.inspectSystemChannels(appContext, snap)
        }
    }

    fun setChannelVibrationEnabled(kind: NotificationChannelKind, enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.updateChannelConfig(kind) { it.copy(vibrationEnabled = enabled) }
            val snap = prefsRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            _channelInspections.value = NotificationChannelHelper.inspectSystemChannels(appContext, snap)
        }
    }

    fun setChannelSilentMode(kind: NotificationChannelKind, silent: Boolean) {
        viewModelScope.launch {
            prefsRepository.updateChannelConfig(kind) { it.copy(silentMode = silent) }
            val snap = prefsRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            _channelInspections.value = NotificationChannelHelper.inspectSystemChannels(appContext, snap)
        }
    }

    fun resetSoundsToDefault() {
        viewModelScope.launch {
            prefsRepository.resetSoundsToDefault()
            val snap = prefsRepository.getSettingsSnapshot()
            NotificationChannelHelper.ensureChannelsSynced(appContext, snap)
            _channelInspections.value = NotificationChannelHelper.inspectSystemChannels(appContext, snap)
            _messages.tryEmit("Ses ve titreşim ayarları varsayılana döndürüldü")
        }
    }

    fun playSoundPreview(soundId: String) {
        val result = TaskSoundManager.playPreviewWithDiagnostics(appContext, soundId)
        when {
            !result.started -> {
                _messages.tryEmit(result.errorMessage ?: "Ses önizlemesi cihazda oynatılamadı.")
            }
            result.mediaVolumeZero -> {
                _messages.tryEmit("Ses çalınıyor ancak cihazın medya sesi kapalı görünüyor.")
            }
            result.usedFallback -> {
                _messages.tryEmit("Varsayılan sistem sesi bulunamadı; yerleşik ses medya kanalından çalındı.")
            }
            else -> {
                val label = if (soundId == TaskSoundManager.ID_COMPLETION_SOUND) {
                    "Görev Tamamlama Sesi"
                } else {
                    NotificationSoundCatalog.labelForSoundId(soundId, _availableSounds.value)
                }
                _messages.tryEmit("$label medya sesi üzerinden çalınıyor.")
            }
        }
    }

    fun playSelectedChannelSoundPreview(kind: NotificationChannelKind) {
        val currentSoundId = settings.value.channelConfigFor(kind).soundId
        if (playingSoundId.value == currentSoundId) {
            stopSoundPreview()
        } else {
            playSoundPreview(currentSoundId)
        }
    }

    fun playCompletionSoundPreview() {
        if (playingSoundId.value == TaskSoundManager.ID_COMPLETION_SOUND) {
            stopSoundPreview()
        } else {
            playSoundPreview(TaskSoundManager.ID_COMPLETION_SOUND)
        }
    }

    fun stopSoundPreview() {
        TaskSoundManager.stopPreview()
    }

    fun sendTestNotification(
        channelKind: NotificationChannelKind = NotificationChannelKind.TEST_ALERTS,
        respectQuietHours: Boolean = false
    ) {
        viewModelScope.launch {
            val status = scheduler.sendTestNotificationNow(
                channelKind = channelKind,
                respectQuietHours = respectQuietHours
            )
            val feedback = when (status) {
                NotificationDeliveryStatus.SENT -> "Test bildirimi gönderildi"
                NotificationDeliveryStatus.SENT_SILENT -> "Test bildirimi sessiz modda gönderildi"
                NotificationDeliveryStatus.SUPPRESSED_QUIET_HOURS -> "Sessiz saat aktif olduğu için test bildirimi susturuldu"
                NotificationDeliveryStatus.SKIPPED_NO_PERMISSION -> "Bildirim izni verilmediği için gönderilemedi"
                NotificationDeliveryStatus.CANCELLED -> "İptal edildi"
            }
            _messages.tryEmit(feedback)
        }
    }

    fun syncSchedulesAfterPermissionChange() {
        viewModelScope.launch(Dispatchers.IO) {
            scheduler.syncAll()
            refreshSystemState()
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            notificationDao.clearNotificationHistory()
            _messages.tryEmit("Bildirim geçmişi temizlendi")
        }
    }

    private fun updateAndResync(transform: (NotificationSettings) -> NotificationSettings) {
        viewModelScope.launch {
            prefsRepository.updateSettings(transform)
            scheduler.syncAll()
            refreshSystemState()
        }
    }

    private fun updateAndSyncChannels(transform: (NotificationSettings) -> NotificationSettings) {
        viewModelScope.launch {
            prefsRepository.updateSettings(transform)
            refreshSystemState()
        }
    }

    private fun updateAndBumpChannelVersion(transform: (NotificationSettings) -> NotificationSettings) {
        viewModelScope.launch {
            prefsRepository.updateSettings { current ->
                transform(current).copy(channelConfigVersion = current.channelConfigVersion + 1)
            }
            refreshSystemState()
        }
    }

    override fun onCleared() {
        TaskSoundManager.stopPreview()
        super.onCleared()
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(NotificationViewModel::class.java)) {
                val appCtx = context.applicationContext
                val db = DivamDatabase.getInstance(appCtx)
                val prefs = NotificationPreferencesRepository(appCtx)
                val scheduler = AndroidTaskReminderScheduler.create(appCtx)
                return NotificationViewModel(
                    appContext = appCtx,
                    prefsRepository = prefs,
                    notificationDao = db.notificationDao(),
                    scheduler = scheduler
                ) as T
            }
            throw IllegalArgumentException("Bilinmeyen ViewModel sınıfı: ${modelClass.name}")
        }
    }
}
