package com.example.feature.tasks

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.designsystem.components.DivamCard
import com.example.core.designsystem.components.DivamSectionTitle
import com.example.core.model.ModuleReadiness
import com.example.core.model.TaskBoxFilter
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskSortOption
import com.example.core.model.TaskStatus
import com.example.core.model.WindowWidthClass
import com.example.ui.theme.DivamTheme
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TasksScreen(
    widthClass: WindowWidthClass,
    taskViewModel: TaskViewModel,
    onCreateNewTask: () -> Unit,
    onEditTask: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val filterState by taskViewModel.filterState.collectAsStateWithLifecycle()
    val filteredTasks by taskViewModel.filteredTasks.collectAsStateWithLifecycle()
    val boxCounts by taskViewModel.boxCounts.collectAsStateWithLifecycle()
    val categories by taskViewModel.categories.collectAsStateWithLifecycle()

    var showFiltersPanel by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var detailTask by remember { mutableStateOf<TaskItem?>(null) }
    var postponeTargetTask by remember { mutableStateOf<TaskItem?>(null) }
    var deleteConfirmTask by remember { mutableStateOf<Pair<TaskItem, Boolean>?>(null) } // Boolean = permanent
    var showEmptyTrashDialog by remember { mutableStateOf(false) }
    var showNewCategoryDialog by remember { mutableStateOf(false) }

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp
    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences
    val coroutineScope = rememberCoroutineScope()

    val requestMoveToTrash: (TaskItem) -> Unit = { task ->
        if (userPrefs.confirmBeforeDelete) {
            deleteConfirmTask = task to false
        } else {
            taskViewModel.moveToTrash(task.id)
        }
    }
    val requestPermanentDelete: (TaskItem) -> Unit = { task ->
        if (userPrefs.confirmBeforeDelete) {
            deleteConfirmTask = task to true
        } else {
            taskViewModel.deletePermanently(task.id)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_gorevler")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = horizontalPadding,
                end = horizontalPadding,
                top = 16.dp,
                bottom = 96.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 1120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DivamSectionTitle(
                        title = "Görevler",
                        subtitle = "Kalıcı yerel görev yönetimi • Çevrimdışı hazır",
                        badge = ModuleReadiness.ACTIVE
                    )

                    // Kutu Seçici: Aktif, Favoriler, Arşiv, Çöp Kutusu
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(TaskBoxFilter.entries) { box ->
                            val count = when (box) {
                                TaskBoxFilter.ACTIVE -> boxCounts.active
                                TaskBoxFilter.FAVORITES -> boxCounts.favorites
                                TaskBoxFilter.ARCHIVED -> boxCounts.archived
                                TaskBoxFilter.TRASH -> boxCounts.trash
                            }
                            val selected = filterState.boxFilter == box
                            FilterChip(
                                selected = selected,
                                onClick = { taskViewModel.updateBoxFilter(box) },
                                label = {
                                    Text(
                                        text = "${box.turkishLabel} ($count)",
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor = extended.goldStart
                                ),
                                modifier = Modifier.testTag("tasks_box_${box.name.lowercase()}")
                            )
                        }
                    }

                    // Arama Çubuğu
                    OutlinedTextField(
                        value = filterState.searchQuery,
                        onValueChange = taskViewModel::updateSearchQuery,
                        placeholder = { Text("Başlık, açıklama, not veya kategori ara...") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = null,
                                tint = extended.goldMid
                            )
                        },
                        trailingIcon = {
                            if (filterState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { taskViewModel.updateSearchQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Clear,
                                        contentDescription = "Aramayı temizle"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = divamTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tasks_search_input")
                    )

                    // Sıralama ve Filtreleme Araç Çubuğu
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(
                                onClick = { showSortMenu = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("tasks_sort_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, extended.cardBorderSubtle)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Sort,
                                    contentDescription = null,
                                    tint = extended.goldMid,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = filterState.sortOption.turkishLabel,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false }
                            ) {
                                TaskSortOption.entries.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.turkishLabel) },
                                        onClick = {
                                            taskViewModel.updateSortOption(option)
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = { showFiltersPanel = !showFiltersPanel },
                            modifier = Modifier.testTag("tasks_filter_toggle_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                1.dp,
                                if (filterState.hasSecondaryFilters || showFiltersPanel) {
                                    extended.goldMid
                                } else {
                                    extended.cardBorderSubtle
                                }
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FilterList,
                                contentDescription = null,
                                tint = if (filterState.hasSecondaryFilters) {
                                    extended.goldMid
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Filtre", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    // Genişleyen Filtre Paneli
                    AnimatedVisibility(visible = showFiltersPanel) {
                        DivamCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Filtreler",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = extended.goldMid
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    TextButton(onClick = { showNewCategoryDialog = true }) {
                                        Text("+ Kategori", color = extended.goldMid)
                                    }
                                    if (filterState.hasSecondaryFilters) {
                                        TextButton(onClick = taskViewModel::clearSecondaryFilters) {
                                            Text("Sıfırla")
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Öncelik",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                TaskPriority.entries.forEach { priority ->
                                    FilterChip(
                                        selected = filterState.priorityFilter == priority,
                                        onClick = { taskViewModel.updatePriorityFilter(priority) },
                                        label = { Text(priority.turkishLabel) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Durum",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                TaskStatus.entries.forEach { status ->
                                    FilterChip(
                                        selected = filterState.statusFilter == status,
                                        onClick = { taskViewModel.updateStatusFilter(status) },
                                        label = { Text(status.turkishLabel) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Kategori",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                categories.forEach { category ->
                                    FilterChip(
                                        selected = filterState.categoryFilterId == category.id,
                                        onClick = { taskViewModel.updateCategoryFilter(category.id) },
                                        label = { Text(category.name) }
                                    )
                                }
                            }
                        }
                    }

                    // Çöp Kutusu Üst Çubuğu
                    if (filterState.boxFilter == TaskBoxFilter.TRASH && filteredTasks.isNotEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            border = BorderStroke(1.dp, extended.cardBorderSubtle)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Silinen görevler geri yüklenebilir veya kalıcı silinebilir.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { showEmptyTrashDialog = true }) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteSweep,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Boşalt", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }

                    // Görev Listesi veya Boş Durum
                    if (filteredTasks.isEmpty()) {
                        TasksEmptyCard(
                            boxFilter = filterState.boxFilter,
                            hasQueryOrFilter = filterState.searchQuery.isNotBlank() ||
                                filterState.hasSecondaryFilters,
                            onCreateNewTask = onCreateNewTask,
                            onResetFilters = {
                                taskViewModel.updateSearchQuery("")
                                taskViewModel.clearSecondaryFilters()
                            }
                        )
                    } else if (widthClass.isTabletOrWide) {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            filteredTasks.chunked(2).forEach { pair ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    pair.forEach { task ->
                                        TaskListItemCard(
                                            task = task,
                                            onOpenDetail = { detailTask = task },
                                            onEdit = { onEditTask(task.id) },
                                            onToggleComplete = { taskViewModel.toggleCompleted(task.id) },
                                            onToggleFavorite = { taskViewModel.toggleFavorite(task.id) },
                                            onDuplicate = { taskViewModel.duplicateTask(task.id) },
                                            onPostponeRequest = { postponeTargetTask = task },
                                            onToggleArchive = {
                                                taskViewModel.setArchived(task.id, !task.isArchived)
                                            },
                                            onMoveToTrash = { requestMoveToTrash(task) },
                                            onRestoreFromTrash = {
                                                taskViewModel.restoreFromTrash(task.id)
                                            },
                                            onDeletePermanently = {
                                                requestPermanentDelete(task)
                                            },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (pair.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            filteredTasks.forEach { task ->
                                TaskListItemCard(
                                    task = task,
                                    onOpenDetail = { detailTask = task },
                                    onEdit = { onEditTask(task.id) },
                                    onToggleComplete = { taskViewModel.toggleCompleted(task.id) },
                                    onToggleFavorite = { taskViewModel.toggleFavorite(task.id) },
                                    onDuplicate = { taskViewModel.duplicateTask(task.id) },
                                    onPostponeRequest = { postponeTargetTask = task },
                                    onToggleArchive = {
                                        taskViewModel.setArchived(task.id, !task.isArchived)
                                    },
                                    onMoveToTrash = { requestMoveToTrash(task) },
                                    onRestoreFromTrash = {
                                        taskViewModel.restoreFromTrash(task.id)
                                    },
                                    onDeletePermanently = {
                                        requestPermanentDelete(task)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = onCreateNewTask,
            containerColor = extended.goldMid,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = horizontalPadding, bottom = 18.dp)
                .testTag("tasks_fab_add")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = Icons.Rounded.Add, contentDescription = null)
                Text(
                    text = "Yeni Görev",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // --- Görev Detay Penceresi ---
    detailTask?.let { target ->
        val latest = filteredTasks.firstOrNull { it.id == target.id } ?: target
        TaskDetailDialog(
            task = latest,
            onDismiss = { detailTask = null },
            onEdit = {
                detailTask = null
                onEditTask(latest.id)
            },
            onStatusChange = { status ->
                taskViewModel.setStatus(latest.id, status)
                detailTask = null
            },
            onDuplicate = {
                taskViewModel.duplicateTask(latest.id)
                detailTask = null
            },
            onPostpone = {
                detailTask = null
                postponeTargetTask = latest
            },
            onArchiveToggle = {
                taskViewModel.setArchived(latest.id, !latest.isArchived)
                detailTask = null
            },
            onMoveToTrash = {
                detailTask = null
                requestMoveToTrash(latest)
            }
        )
    }

    deleteConfirmTask?.let { (targetTask, isPermanent) ->
        AlertDialog(
            onDismissRequest = { deleteConfirmTask = null },
            title = {
                Text(if (isPermanent) "Kalıcı Olarak Sil" else "Görevi Sil")
            },
            text = {
                Text(
                    if (isPermanent) {
                        "\"${targetTask.title}\" kalıcı olarak silinecek ve geri yüklenemeyecek. Devam edilsin mi?"
                    } else {
                        "\"${targetTask.title}\" çöp kutusuna taşınsın mı?"
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (isPermanent) {
                            taskViewModel.deletePermanently(targetTask.id)
                        } else {
                            taskViewModel.moveToTrash(targetTask.id)
                        }
                        deleteConfirmTask = null
                    }
                ) {
                    Text(
                        if (isPermanent) "Kalıcı Sil" else "Çöp Kutusuna Taşı",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmTask = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // --- Erteleme Seçenekleri ---
    postponeTargetTask?.let { target ->
        AlertDialog(
            onDismissRequest = { postponeTargetTask = null },
            title = { Text("Görevi Ertele") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "\"${target.title}\" görevini ne kadar ertelemek istersiniz?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    listOf(
                        1 to "Yarına Ertele (+1 Gün)",
                        3 to "3 Gün Sonraya Ertele",
                        7 to "Gelecek Haftaya Ertele (+7 Gün)"
                    ).forEach { (days, label) ->
                        OutlinedButton(
                            onClick = {
                                taskViewModel.postponeTask(target.id, days)
                                postponeTargetTask = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(label)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { postponeTargetTask = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // --- Çöp Kutusunu Boşaltma Onayı ---
    if (showEmptyTrashDialog) {
        AlertDialog(
            onDismissRequest = { showEmptyTrashDialog = false },
            title = { Text("Çöp Kutusunu Boşalt") },
            text = { Text("Çöp kutusundaki tüm görevler kalıcı olarak silinecek. Bu işlem geri alınamaz.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        taskViewModel.emptyTrash()
                        showEmptyTrashDialog = false
                    }
                ) {
                    Text("Kalıcı Sil", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEmptyTrashDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // --- Yeni Kategori Penceresi ---
    if (showNewCategoryDialog) {
        var newCategoryName by remember { mutableStateOf("") }
        var categoryError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showNewCategoryDialog = false },
            title = { Text("Özel Kategori Oluştur") },
            text = {
                OutlinedTextField(
                    value = newCategoryName,
                    onValueChange = {
                        if (it.length <= 32) {
                            newCategoryName = it
                            categoryError = null
                        }
                    },
                    label = { Text("Kategori Adı") },
                    singleLine = true,
                    isError = categoryError != null,
                    supportingText = categoryError?.let { err -> { Text(err) } },
                    colors = divamTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        coroutineScope.launch {
                            val result = taskViewModel.createCustomCategory(newCategoryName)
                            result.onSuccess {
                                showNewCategoryDialog = false
                            }.onFailure { err ->
                                categoryError = err.message ?: "Kategori eklenemedi."
                            }
                        }
                    }
                ) {
                    Text("Oluştur", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewCategoryDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }
}

@Composable
private fun TasksEmptyCard(
    boxFilter: TaskBoxFilter,
    hasQueryOrFilter: Boolean,
    onCreateNewTask: () -> Unit,
    onResetFilters: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    val (title, subtitle) = when {
        hasQueryOrFilter -> {
            "Eşleşen Görev Bulunamadı" to "Arama terimini veya aktif filtreleri temizleyerek tüm kayıtları görebilirsiniz."
        }
        boxFilter == TaskBoxFilter.ACTIVE -> {
            "Henüz Kayıtlı Görev Yok" to "İlk görevinizi oluşturarak başlangıç ve bitiş planınızı cihazınızda güvenle saklayın."
        }
        boxFilter == TaskBoxFilter.FAVORITES -> {
            "Favori Görev Bulunmuyor" to "Önem verdiğiniz görevleri yıldız simgesiyle favorilerinize ekleyebilirsiniz."
        }
        boxFilter == TaskBoxFilter.ARCHIVED -> {
            "Arşivlenmiş Görev Yok" to "Tamamlanan veya saklamak istediğiniz görevleri arşivleyebilirsiniz."
        }
        else -> {
            "Çöp Kutusu Boş" to "Silinen görevler kalıcı olarak silinmeden önce burada saklanır."
        }
    }

    DivamCard(
        modifier = Modifier.fillMaxWidth(),
        highlightGoldBorder = true
    ) {
        Icon(
            imageVector = Icons.Rounded.Checklist,
            contentDescription = null,
            tint = extended.goldMid,
            modifier = Modifier.size(34.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (hasQueryOrFilter) {
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(onClick = onResetFilters) {
                Text("Filtreleri Temizle")
            }
        } else if (boxFilter == TaskBoxFilter.ACTIVE) {
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onCreateNewTask,
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Yeni Görev Oluştur")
            }
        }
    }
}
