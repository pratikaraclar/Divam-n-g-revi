package com.example.feature.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.ui.theme.DivamTheme

@Composable
fun CompletionDonutChartCard(
    completedCount: Int,
    incompleteCount: Int,
    cancelledCount: Int,
    completionPercent: Int,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val total = completedCount + incompleteCount + cancelledCount

    DivamCard(modifier = modifier.fillMaxWidth(), highlightGoldBorder = true) {
        Text(
            text = "Tamamlanan ve Tamamlanmayan Görev Karşılaştırması",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Box(
                modifier = Modifier.size(132.dp),
                contentAlignment = Alignment.Center
            ) {
                val trackColor = MaterialTheme.colorScheme.surfaceContainerLow
                val completedColor = extended.goldMid
                val incompleteColor = MaterialTheme.colorScheme.primary
                val cancelledColor = MaterialTheme.colorScheme.error.copy(alpha = 0.75f)

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 18.dp.toPx()
                    val diameter = size.minDimension - strokeWidth
                    val topLeft = Offset(
                        (size.width - diameter) / 2f,
                        (size.height - diameter) / 2f
                    )
                    val arcSize = Size(diameter, diameter)

                    drawArc(
                        color = trackColor,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )

                    if (total > 0) {
                        var startAngle = -90f
                        val segments = listOf(
                            completedCount to completedColor,
                            incompleteCount to incompleteColor,
                            cancelledCount to cancelledColor
                        )
                        segments.forEach { (count, segColor) ->
                            if (count > 0) {
                                val sweep = (count.toFloat() / total.toFloat()) * 360f
                                drawArc(
                                    color = segColor,
                                    startAngle = startAngle,
                                    sweepAngle = sweep,
                                    useCenter = false,
                                    topLeft = topLeft,
                                    size = arcSize,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                )
                                startAngle += sweep
                            }
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "%$completionPercent",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = extended.goldMid
                    )
                    Text(
                        text = "Başarı",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DonutLegendRow(
                    label = "Tamamlanan",
                    count = completedCount,
                    color = extended.goldMid
                )
                DonutLegendRow(
                    label = "Tamamlanmayan",
                    count = incompleteCount,
                    color = MaterialTheme.colorScheme.primary
                )
                DonutLegendRow(
                    label = "İptal Edilen",
                    count = cancelledCount,
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun DonutLegendRow(label: String, count: Int, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun DailyProgressLineChartCard(
    series: List<ChartPoint>,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val maxVal = (series.maxOfOrNull { maxOf(it.totalCount, it.completedCount) } ?: 1).coerceAtLeast(1)

    DivamCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Günlük İlerleme Grafiği (Son 7 Gün)",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Çizgi Grafik",
                style = MaterialTheme.typography.labelSmall,
                color = extended.goldMid
            )
        }
        Spacer(modifier = Modifier.height(14.dp))

        val lineColor = extended.goldMid
        val totalLineColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
        val gridColor = extended.cardBorderSubtle

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            val w = size.width
            val h = size.height
            val horizontalPad = 14.dp.toPx()
            val verticalPad = 12.dp.toPx()
            val plotW = (w - horizontalPad * 2).coerceAtLeast(1f)
            val plotH = (h - verticalPad * 2).coerceAtLeast(1f)

            // Yatay kılavuz çizgileri
            for (i in 0..3) {
                val y = verticalPad + (plotH * i / 3f)
                drawLine(
                    color = gridColor.copy(alpha = 0.35f),
                    start = Offset(horizontalPad, y),
                    end = Offset(w - horizontalPad, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            if (series.isEmpty()) return@Canvas
            val stepX = if (series.size <= 1) 0f else plotW / (series.size - 1).toFloat()

            val completedPath = Path()
            val fillPath = Path()
            val totalPath = Path()

            series.forEachIndexed { idx, pt ->
                val x = horizontalPad + idx * stepX
                val yTotal = verticalPad + plotH * (1f - (pt.totalCount.toFloat() / maxVal.toFloat()))
                val yDone = verticalPad + plotH * (1f - (pt.completedCount.toFloat() / maxVal.toFloat()))

                if (idx == 0) {
                    totalPath.moveTo(x, yTotal)
                    completedPath.moveTo(x, yDone)
                    fillPath.moveTo(x, verticalPad + plotH)
                    fillPath.lineTo(x, yDone)
                } else {
                    totalPath.lineTo(x, yTotal)
                    completedPath.lineTo(x, yDone)
                    fillPath.lineTo(x, yDone)
                }
                if (idx == series.lastIndex) {
                    fillPath.lineTo(x, verticalPad + plotH)
                    fillPath.close()
                }
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(lineColor.copy(alpha = 0.28f), lineColor.copy(alpha = 0f))
                )
            )
            drawPath(
                path = totalPath,
                color = totalLineColor,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path = completedPath,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            series.forEachIndexed { idx, pt ->
                val x = horizontalPad + idx * stepX
                val yDone = verticalPad + plotH * (1f - (pt.completedCount.toFloat() / maxVal.toFloat()))
                drawCircle(
                    color = lineColor,
                    radius = 4.5.dp.toPx(),
                    center = Offset(x, yDone)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            series.forEach { pt ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "${pt.completedCount}/${pt.totalCount}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (pt.completedCount > 0) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = pt.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun PerformanceColumnChartCard(
    title: String,
    subtitle: String,
    bars: List<ChartPoint>,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val maxVal = (bars.maxOfOrNull { maxOf(it.totalCount, it.completedCount) } ?: 1).coerceAtLeast(1)
    val trackColor = MaterialTheme.colorScheme.surfaceContainerLow
    val doneColor = extended.goldMid
    val plannedColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.48f)

    DivamCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = extended.goldMid
            )
        }
        Spacer(modifier = Modifier.height(14.dp))

        if (bars.isEmpty()) {
            Text(
                text = "Bu dönem için sütun verisi bulunmuyor.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(136.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                bars.forEach { bar ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .height(136.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Text(
                            text = bar.completedCount.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (bar.completedCount > 0) extended.goldMid else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Canvas(
                            modifier = Modifier
                                .width(22.dp)
                                .height(86.dp)
                        ) {
                            val totalH = if (bar.totalCount == 0) {
                                4.dp.toPx()
                            } else {
                                (size.height * (bar.totalCount.toFloat() / maxVal.toFloat())).coerceAtLeast(8.dp.toPx())
                            }
                            drawRoundRect(
                                color = trackColor,
                                cornerRadius = CornerRadius(8f, 8f),
                                size = size
                            )
                            drawRoundRect(
                                color = plannedColor,
                                topLeft = Offset(0f, size.height - totalH),
                                size = Size(size.width, totalH),
                                cornerRadius = CornerRadius(8f, 8f)
                            )
                            if (bar.completedCount > 0) {
                                val doneH = (size.height * (bar.completedCount.toFloat() / maxVal.toFloat()))
                                    .coerceAtLeast(8.dp.toPx())
                                drawRoundRect(
                                    color = doneColor,
                                    topLeft = Offset(0f, size.height - doneH),
                                    size = Size(size.width, doneH),
                                    cornerRadius = CornerRadius(8f, 8f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = bar.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
