package com.example.feature.notifications

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.NotificationChannelKind
import com.example.core.model.NotificationSettings
import com.example.core.model.NotificationSoundCatalog
import com.example.core.model.QuietHoursPolicy
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.WindowWidthClass
import com.example.core.notifications.NotificationChannelHelper
import com.example.feature.tasks.divamTextFieldColors
import com.example.ui.theme.DivamTheme

private enum class NotificationTimeTarget {
    MORNING,
    EVENING,
    QUIET_START,
    QUIET_END
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NotificationsScreen(
    widthClass: WindowWidthClass,
    notificationViewModel: NotificationViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences

    val settings by notificationViewModel.settings.collectAsStateWithLifecycle()
    val history by notificationViewModel.history.collectAsStateWithLifecycle()
    val scheduledReminders by notificationViewModel.scheduledReminders.collectAsStateWithLifecycle()
    val availableSounds by notificationViewModel.availableSounds.collectAsStateWithLifecycle()
    val playingSoundId by notificationViewModel.playingSoundId.collectAsStateWithLifecycle()
    val inspections by notificationViewModel.channelInspections.collectAsStateWithLifecycle()

    var hasPostPermission by remember {
        mutableStateOf(NotificationChannelHelper.hasPostNotificationPermission(context))
    }
    var canExactAlarm by remember {
        mutableStateOf(NotificationChannelHelper.canScheduleExactAlarms(context))
    }
    var selectedChannelKind by remember { mutableStateOf(NotificationChannelKind.TASK_REMINDERS) }
    var testChannelKind by remember { mutableStateOf(NotificationChannelKind.TEST_ALERTS) }
    var testRespectQuietHours by remember { mutableStateOf(false) }
    var timeTarget by remember { mutableStateOf<NotificationTimeTarget?>(null) }
    var showCustomOffsetDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        hasPostPermission = NotificationChannelHelper.hasPostNotificationPermission(context)
        notificationViewModel.syncSchedulesAfterPermissionChange()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasPostPermission = NotificationChannelHelper.hasPostNotificationPermission(context)
                canExactAlarm = NotificationChannelHelper.canScheduleExactAlarms(context)
                notificationViewModel.refreshSystemState()
            } else if (event == Lifecycle.Event.ON_STOP) {
                notificationViewModel.stopSoundPreview()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            notificationViewModel.stopSoundPreview()
        }
    }

    val requestPermissionAction: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            NotificationChannelHelper.openAppNotificationSettings(context)
        }
    }

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_bildirimler")
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Bildirim ve Ses Merkezi",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("notifications_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(id = R.string.cd_back),
                        tint = extended.goldMid
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = horizontalPadding,
                end = horizontalPadding,
                top = 8.dp,
                bottom = 32.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 980.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PermissionAndSystemCard(
                        hasPostPermission = hasPostPermission,
                        canExactAlarm = canExactAlarm,
                        scheduledCount = scheduledReminders.size,
                        onRequestPostPermission = requestPermissionAction,
                        onOpenExactAlarmSettings = {
                            NotificationChannelHelper.openExactAlarmSettings(context)
                        },
                        onOpenBatterySettings = {
                            NotificationChannelHelper.openBatteryOptimizationSettings(context)
                        },
                        onOpenAppNotificationSettings = {
                            NotificationChannelHelper.openAppNotificationSettings(context)
                        }
                    )

                    // Genel Bildirim & Test Kartı
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        SettingSwitchRow(
                            title = "Yerel Bildirimler Etkin",
                            subtitle = "Kapatıldığında yeni görev hatırlatmaları ve günlük özetler planlanmaz.",
                            checked = settings.notificationsEnabled,
                            onCheckedChange = notificationViewModel::setNotificationsEnabled,
                            testTag = "switch_notifications_enabled"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Test Bildirimi Kanalı",
                            style = MaterialTheme.typography.labelLarge,
                            color = extended.goldMid
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            NotificationChannelKind.entries.forEach { kind ->
                                FilterChip(
                                    selected = testChannelKind == kind,
                                    onClick = { testChannelKind = kind },
                                    label = { Text(kind.turkishTitle) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        selectedLabelColor = extended.goldStart
                                    )
                                )
                            }
                        }
                        SettingSwitchRow(
                            title = "Testte Sessiz Saat Kuralını Uygula",
                            subtitle = null,
                            checked = testRespectQuietHours,
                            onCheckedChange = { testRespectQuietHours = it }
                        )
                        val testChannelSoundId = settings.channelConfigFor(testChannelKind).soundId
                        val testChannelSoundLabel = NotificationSoundCatalog.labelForSoundId(testChannelSoundId, availableSounds)
                        val isTestSoundPlaying = playingSoundId == testChannelSoundId
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Seçili ses: $testChannelSoundLabel • Ses testi medya kanalıyla çalar, telefon sessizdeyken bile duyulur.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                if (isTestSoundPlaying) {
                                    notificationViewModel.stopSoundPreview()
                                } else {
                                    notificationViewModel.playSelectedChannelSoundPreview(testChannelKind)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("notifications_test_sound_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.2.dp, extended.goldMid)
                        ) {
                            Icon(
                                imageVector = if (isTestSoundPlaying) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                                contentDescription = null,
                                tint = extended.goldMid
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isTestSoundPlaying) {
                                    "Ses Önizlemesini Durdur"
                                } else {
                                    "Seçili Sesi Test Et ($testChannelSoundLabel)"
                                },
                                color = extended.goldMid,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (!hasPostPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    requestPermissionAction()
                                } else {
                                    notificationViewModel.sendTestNotification(
                                        channelKind = testChannelKind,
                                        respectQuietHours = testRespectQuietHours
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("notifications_send_test_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = extended.goldMid,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Rounded.Send, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bildirim Testi Gönder", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Varsayılan Hatırlatma Süreleri
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = extended.goldMid)
                                Text(
                                    text = "Varsayılan Hatırlatma Süreleri",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            TextButton(onClick = { showCustomOffsetDialog = true }) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Özel Süre", color = extended.goldMid)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Yeni eklenen görevler için otomatik seçilecek hatırlatma süreleri:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val offsets = remember(settings.defaultReminderOffsets) {
                            (NotificationSettings.PRESET_OFFSETS_MINUTES + settings.defaultReminderOffsets)
                                .distinct()
                                .sorted()
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            offsets.forEach { offset ->
                                val selected = offset in settings.defaultReminderOffsets
                                FilterChip(
                                    selected = selected,
                                    onClick = { notificationViewModel.toggleDefaultOffset(offset) },
                                    label = { Text(TaskDateTimeUtils.formatReminderOffsetTurkish(offset)) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        selectedLabelColor = extended.goldStart
                                    )
                                )
                            }
                        }
                    }

                    // Sabah Özeti & Akşam Hatırlatması
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.Schedule, contentDescription = null, tint = extended.goldMid)
                            Text(
                                text = "Günlük Özet Bildirimleri",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        SettingSwitchRow(
                            title = "Sabah Günlük Görev Özeti",
                            subtitle = "Günün planlı görevlerini sabah saatinde özetler",
                            checked = settings.morningSummaryEnabled,
                            onCheckedChange = { notificationViewModel.setMorningSummary(enabled = it) }
                        )
                        OutlinedButton(
                            onClick = { timeTarget = NotificationTimeTarget.MORNING },
                            enabled = settings.morningSummaryEnabled,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "Sabah Özeti Saati: ${
                                    TaskDateTimeUtils.formatTimeMinutes(
                                        settings.morningSummaryMinutes,
                                        userPrefs.use24HourFormat
                                    )
                                }"
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        SettingSwitchRow(
                            title = "Akşam Tamamlanmamış Görev Uyarısı",
                            subtitle = "Tamamlanmamış aktif görevler varsa akşam hatırlatır",
                            checked = settings.eveningIncompleteEnabled,
                            onCheckedChange = { notificationViewModel.setEveningIncomplete(enabled = it) }
                        )
                        OutlinedButton(
                            onClick = { timeTarget = NotificationTimeTarget.EVENING },
                            enabled = settings.eveningIncompleteEnabled,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "Akşam Hatırlatma Saati: ${
                                    TaskDateTimeUtils.formatTimeMinutes(
                                        settings.eveningIncompleteMinutes,
                                        userPrefs.use24HourFormat
                                    )
                                }"
                            )
                        }
                    }

                    // Sessiz Saatler
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.Bedtime, contentDescription = null, tint = extended.goldMid)
                            Text(
                                text = "Sessiz Saatler",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        SettingSwitchRow(
                            title = "Sessiz Saatleri Etkinleştir",
                            subtitle = "Belirlenen saat aralığında bildirim sesi ve titreşimi susturulur.",
                            checked = settings.quietHoursEnabled,
                            onCheckedChange = { notificationViewModel.setQuietHours(enabled = it) },
                            testTag = "switch_quiet_hours"
                        )
                        if (settings.quietHoursEnabled) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { timeTarget = NotificationTimeTarget.QUIET_START },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        "Başlangıç: ${
                                            TaskDateTimeUtils.formatTimeMinutes(
                                                settings.quietHoursStartMinutes,
                                                userPrefs.use24HourFormat
                                            )
                                        }",
                                        maxLines = 1
                                    )
                                }
                                OutlinedButton(
                                    onClick = { timeTarget = NotificationTimeTarget.QUIET_END },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        "Bitiş: ${
                                            TaskDateTimeUtils.formatTimeMinutes(
                                                settings.quietHoursEndMinutes,
                                                userPrefs.use24HourFormat
                                            )
                                        }",
                                        maxLines = 1
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                QuietHoursPolicy.entries.forEach { policy ->
                                    val selected = settings.quietHoursPolicy == policy
                                    Surface(
                                        onClick = { notificationViewModel.setQuietHours(policy = policy) },
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (selected) {
                                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                                        } else {
                                            MaterialTheme.colorScheme.surfaceContainerLow
                                        },
                                        border = BorderStroke(
                                            1.dp,
                                            if (selected) extended.goldMid else extended.cardBorderSubtle
                                        )
                                    ) {
                                        Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                                            Text(
                                                text = policy.turkishLabel,
                                                style = MaterialTheme.typography.titleSmall,
                                                color = if (selected) extended.goldStart else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = policy.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Ses ve Titreşim Stüdyosu
                    SoundAndChannelStudioCard(
                        settings = settings,
                        selectedChannelKind = selectedChannelKind,
                        availableSounds = availableSounds,
                        playingSoundId = playingSoundId,
                        inspections = inspections,
                        onSelectChannelKind = { selectedChannelKind = it },
                        onGlobalSoundChange = notificationViewModel::setGlobalSoundEnabled,
                        onGlobalVibrationChange = notificationViewModel::setGlobalVibrationEnabled,
                        onGlobalSilentChange = notificationViewModel::setSilentNotificationMode,
                        onCompletionSoundChange = notificationViewModel::setCompletionSoundEnabled,
                        onSelectChannelSound = notificationViewModel::selectChannelSound,
                        onChannelSoundToggle = notificationViewModel::setChannelSoundEnabled,
                        onChannelVibrationToggle = notificationViewModel::setChannelVibrationEnabled,
                        onChannelSilentToggle = notificationViewModel::setChannelSilentMode,
                        onPlayPreview = notificationViewModel::playSoundPreview,
                        onPlayCompletionPreview = notificationViewModel::playCompletionSoundPreview,
                        onStopPreview = notificationViewModel::stopSoundPreview,
                        onOpenChannelSettings = { channelId ->
                            NotificationChannelHelper.openChannelNotificationSettings(context, channelId)
                        },
                        onResetSounds = notificationViewModel::resetSoundsToDefault
                    )

                    // Bildirim Geçmişi
                    NotificationHistoryCard(
                        history = history,
                        use24Hour = userPrefs.use24HourFormat,
                        onClearHistory = notificationViewModel::clearHistory
                    )
                }
            }
        }
    }

    timeTarget?.let { target ->
        val (dialogTitle, initialMins) = when (target) {
            NotificationTimeTarget.MORNING -> "Sabah Özeti Saati" to settings.morningSummaryMinutes
            NotificationTimeTarget.EVENING -> "Akşam Hatırlatma Saati" to settings.eveningIncompleteMinutes
            NotificationTimeTarget.QUIET_START -> "Sessiz Saat Başlangıcı" to settings.quietHoursStartMinutes
            NotificationTimeTarget.QUIET_END -> "Sessiz Saat Bitişi" to settings.quietHoursEndMinutes
        }
        NotificationTimePickerDialog(
            title = dialogTitle,
            initialMinutes = initialMins,
            is24Hour = userPrefs.use24HourFormat,
            onDismiss = { timeTarget = null },
            onConfirm = { chosenMinutes ->
                when (target) {
                    NotificationTimeTarget.MORNING ->
                        notificationViewModel.setMorningSummary(minuteOfDay = chosenMinutes)
                    NotificationTimeTarget.EVENING ->
                        notificationViewModel.setEveningIncomplete(minuteOfDay = chosenMinutes)
                    NotificationTimeTarget.QUIET_START ->
                        notificationViewModel.setQuietHours(startMinutes = chosenMinutes)
                    NotificationTimeTarget.QUIET_END ->
                        notificationViewModel.setQuietHours(endMinutes = chosenMinutes)
                }
                timeTarget = null
            }
        )
    }

    if (showCustomOffsetDialog) {
        var minutesInput by remember { mutableStateOf("") }
        var inputErr by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showCustomOffsetDialog = false },
            title = { Text("Özel Varsayılan Süre") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Görevlerden kaç dakika önce hatırlatılmasını istersiniz?",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = minutesInput,
                        onValueChange = { raw ->
                            minutesInput = raw.filter { it.isDigit() }.take(5)
                            inputErr = null
                        },
                        label = { Text("Dakika (1 – 10080)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isError = inputErr != null,
                        supportingText = inputErr?.let { err -> { Text(err) } },
                        colors = divamTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val parsed = minutesInput.toIntOrNull()
                        if (parsed == null || parsed !in 1..10_080) {
                            inputErr = "Geçerli bir dakika değeri girin (1–10080)."
                        } else {
                            notificationViewModel.addCustomDefaultOffset(parsed)
                            showCustomOffsetDialog = false
                        }
                    }
                ) {
                    Text("Ekle", color = extended.goldMid)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomOffsetDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }
}
