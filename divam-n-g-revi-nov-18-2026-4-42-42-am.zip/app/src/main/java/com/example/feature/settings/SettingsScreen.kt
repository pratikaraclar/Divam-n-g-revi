package com.example.feature.settings

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.R
import com.example.core.backup.BackupValidationPreview
import com.example.core.backup.TaskBackupManager
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.TaskCategory
import com.example.core.model.WindowWidthClass
import com.example.core.viewmodel.AppViewModel
import com.example.ui.theme.DivamTheme
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.launch

private enum class ResetActionKind(val title: String, val message: String) {
    APPEARANCE(
        title = "Görünüm Ayarlarını Sıfırla",
        message = "Tema, altın detaylar, yazı boyutu ve kart görünümü varsayılan ayarlara döndürülsün mü?"
    ),
    NOTIFICATIONS(
        title = "Bildirim Ayarlarını Sıfırla",
        message = "Tüm bildirim, ses, titreşim, özet ve sessiz saat tercihleri varsayılana döndürülsün mü?"
    ),
    ALL_PREFERENCES(
        title = "Bütün Tercihleri Sıfırla",
        message = "Görünüm, tarih/saat, görev varsayılanları, bildirimler ve uygulama kilidi ayarları varsayılana döndürülsün mü? Mevcut görev kayıtlarınız silinmez."
    ),
    WIPE_PERSONAL_DATA(
        title = "Tüm Kişisel Verileri Sil",
        message = "Kayıtlı tüm görevler, özel kategoriler, bildirim geçmişi, yerel yedekler ve profil fotoğrafı kalıcı olarak silinecek. Emin misiniz?"
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    widthClass: WindowWidthClass,
    themeMode: ThemeMode,
    categories: List<TaskCategory>,
    appViewModel: AppViewModel,
    onOpenNotifications: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val userPreferences by appViewModel.userPreferences.collectAsStateWithLifecycle()
    val localBackupFiles by appViewModel.localBackupFiles.collectAsStateWithLifecycle()

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp
    val extended = DivamTheme.extendedColors
    val scope = rememberCoroutineScope()

    var activeDocument by remember { mutableStateOf<SupportDocumentKind?>(null) }
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pendingRestorePreview by remember { mutableStateOf<BackupValidationPreview?>(null) }
    var pendingResetAction by remember { mutableStateOf<ResetActionKind?>(null) }
    var statusNotice by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = appViewModel.exportBackupToUri(uri)
                statusNotice = res.fold(
                    onSuccess = { count -> "$count görev JSON dosyasına dışa aktarıldı." },
                    onFailure = { err -> "Dışa aktarma başarısız: ${err.message ?: "Hata"}" }
                )
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = appViewModel.inspectBackupFromUri(uri)
                res.fold(
                    onSuccess = { preview -> pendingRestorePreview = preview },
                    onFailure = { err ->
                        statusNotice = "Yedek doğrulanamadı: ${err.message ?: "Geçersiz JSON dosyası"}"
                    }
                )
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_ayarlar")
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(id = R.string.nav_settings),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(id = R.string.cd_back),
                        tint = extended.goldMid
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = horizontalPadding,
                end = horizontalPadding,
                top = 8.dp,
                bottom = 32.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 820.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (!statusNotice.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                            border = BorderStroke(1.dp, extended.goldMid),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = statusNotice!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { statusNotice = null }) {
                                    Text("Tamam", color = extended.goldMid)
                                }
                            }
                        }
                    }

                    // 1. Görünüm & Tema & Altın Detaylar & Yazı Boyutu & Kart Stili
                    AppearanceSettingsCard(
                        themeMode = themeMode,
                        userPreferences = userPreferences,
                        onThemeModeSelected = appViewModel::updateThemeMode,
                        onToggleGoldAccents = appViewModel::setGoldAccentsEnabled,
                        onSelectFontScale = appViewModel::updateFontScale,
                        onSelectCardStyle = appViewModel::updateCardDisplayStyle,
                        onRequestResetAppearance = { pendingResetAction = ResetActionKind.APPEARANCE }
                    )

                    // 2. Tarih/Saat/Takvim & Görev Varsayılanları
                    DateAndTaskBehaviorCard(
                        userPreferences = userPreferences,
                        categories = categories,
                        onToggle24Hour = appViewModel::setUse24HourFormat,
                        onSelectDateFormat = appViewModel::updateDateFormatStyle,
                        onSelectWeekStart = appViewModel::updateWeekStartDay,
                        onSelectDefaultPriority = appViewModel::updateDefaultPriority,
                        onSelectDefaultCategory = appViewModel::updateDefaultCategoryId,
                        onSelectDefaultTaskBox = appViewModel::updateDefaultTaskBoxFilter,
                        onToggleAutoArchive = appViewModel::setAutoArchiveCompleted,
                        onToggleShowOverdue = appViewModel::setShowOverdueOnHome,
                        onToggleConfirmDelete = appViewModel::setConfirmBeforeDelete
                    )

                    // 3. Bildirim ve Ses Ayarları Erişimi & Sıfırlama
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = extended.goldMid)
                            Text(
                                text = "Bildirimler ve Ses Ayarları",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Hatırlatma süreleri, bildirim sesleri, titreşim, sessiz saatler ve bildirim geçmişini yönetin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onOpenNotifications,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = extended.goldMid,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.weight(1f).testTag("settings_open_notifications")
                            ) {
                                Text("Bildirim Merkezi")
                            }
                            OutlinedButton(
                                onClick = { pendingResetAction = ResetActionKind.NOTIFICATIONS },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).testTag("settings_reset_notifications_button")
                            ) {
                                Text("Bildirimleri Sıfırla", maxLines = 1)
                            }
                        }
                    }

                    // 4. Yedekleme, Geri Yükleme & Güvenlik
                    BackupAndSecurityCard(
                        userPreferences = userPreferences,
                        localBackupFiles = localBackupFiles,
                        onExportJson = { exportLauncher.launch(TaskBackupManager.defaultBackupFileName()) },
                        onImportJson = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                        onCreateLocalSnapshot = appViewModel::createLocalBackupSnapshot,
                        onInspectLocalSnapshot = { file ->
                            scope.launch {
                                val res = appViewModel.inspectLocalBackupFile(file)
                                res.fold(
                                    onSuccess = { preview -> pendingRestorePreview = preview },
                                    onFailure = { err ->
                                        statusNotice = "Yerel yedek okunamadı: ${err.message ?: "Hata"}"
                                    }
                                )
                            }
                        },
                        onOpenPinSetup = { showPinDialog = true },
                        onToggleBiometric = appViewModel::setBiometricEnabled,
                        onLockNow = appViewModel::lockNowIfEnabled
                    )

                    // 5. Yasal, Destek, Yardım ve Sıfırlama
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Yasal Bilgiler, Yardım ve Destek",
                            style = MaterialTheme.typography.titleMedium,
                            color = extended.goldMid
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        SettingsNavActionRow(
                            icon = Icons.Rounded.PrivacyTip,
                            title = "Gizlilik Politikası",
                            onClick = { activeDocument = SupportDocumentKind.PRIVACY_POLICY }
                        )
                        SettingsNavActionRow(
                            icon = Icons.Rounded.Gavel,
                            title = "Kullanım Koşulları",
                            onClick = { activeDocument = SupportDocumentKind.TERMS_OF_USE }
                        )
                        SettingsNavActionRow(
                            icon = Icons.Rounded.HelpOutline,
                            title = "Sık Sorulan Sorular",
                            onClick = { activeDocument = SupportDocumentKind.FAQ }
                        )
                        SettingsNavActionRow(
                            icon = Icons.Rounded.MenuBook,
                            title = "Kullanım Rehberi",
                            onClick = { activeDocument = SupportDocumentKind.USAGE_GUIDE }
                        )
                        SettingsNavActionRow(
                            icon = Icons.Rounded.SupportAgent,
                            title = "Bildirim Sorunları Yardım Ekranı",
                            onClick = { activeDocument = SupportDocumentKind.NOTIFICATION_HELP }
                        )
                        SettingsNavActionRow(
                            icon = Icons.Rounded.BugReport,
                            title = "Geri Bildirim ve Sorun Bildirme",
                            onClick = { showFeedbackDialog = true }
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { pendingResetAction = ResetActionKind.ALL_PREFERENCES },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("settings_reset_all_prefs_button")
                        ) {
                            Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bütün Tercihleri Varsayılana Döndür")
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { pendingResetAction = ResetActionKind.WIPE_PERSONAL_DATA },
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("settings_wipe_personal_data_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteForever,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Kişisel Verileri Sil", color = MaterialTheme.colorScheme.error)
                        }
                    }

                    // 6. Uygulama Sürümü Kartı
                    DivamCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = stringResource(id = R.string.app_name),
                            style = MaterialTheme.typography.titleMedium,
                            color = extended.goldMid
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sürüm ${BuildConfig.VERSION_NAME} (Yapı ${BuildConfig.VERSION_CODE}) • Çevrimdışı yerel görev, takvim, bildirim ve raporlama sistemi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    activeDocument?.let { docKind ->
        SupportDocumentDialog(
            kind = docKind,
            onDismiss = { activeDocument = null }
        )
    }

    if (showFeedbackDialog) {
        FeedbackDialog(
            onDismiss = { showFeedbackDialog = false },
            onResultMessage = { msg -> statusNotice = msg }
        )
    }

    if (showPinDialog) {
        PinSetupDialog(
            hasExistingPin = userPreferences.hasPinConfigured,
            onDismiss = { showPinDialog = false },
            onSavePin = appViewModel::setupOrUpdatePin,
            onDisablePin = appViewModel::disableAppLock
        )
    }

    pendingRestorePreview?.let { preview ->
        BackupRestorePreviewDialog(
            preview = preview,
            onDismiss = { pendingRestorePreview = null },
            onConfirmRestore = {
                appViewModel.confirmRestoreBackup(preview.document) { summary ->
                    statusNotice = "Geri yükleme tamamlandı: ${summary.importedTasksCount} yeni görev eklendi, ${summary.skippedDuplicatesCount} mükerrer atlandı."
                }
                pendingRestorePreview = null
            }
        )
    }

    pendingResetAction?.let { resetAction ->
        AlertDialog(
            onDismissRequest = { pendingResetAction = null },
            title = { Text(resetAction.title, color = extended.goldMid) },
            text = { Text(resetAction.message) },
            confirmButton = {
                Button(
                    onClick = {
                        when (resetAction) {
                            ResetActionKind.APPEARANCE -> appViewModel.resetAppearanceSettingsOnly()
                            ResetActionKind.NOTIFICATIONS -> appViewModel.resetNotificationSettingsOnly()
                            ResetActionKind.ALL_PREFERENCES -> appViewModel.resetAllPreferences()
                            ResetActionKind.WIPE_PERSONAL_DATA -> appViewModel.deleteAllPersonalData()
                        }
                        pendingResetAction = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (resetAction == ResetActionKind.WIPE_PERSONAL_DATA) {
                            MaterialTheme.colorScheme.error
                        } else {
                            extended.goldMid
                        }
                    )
                ) {
                    Text("Onayla", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingResetAction = null }) { Text("İptal") }
            }
        )
    }
}

@Composable
private fun SettingsNavActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, extended.cardBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = extended.goldMid, modifier = Modifier.size(20.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
