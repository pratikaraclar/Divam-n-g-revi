package com.example.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.designsystem.components.DivamCard
import com.example.core.designsystem.components.DivamLogoMark
import com.example.core.designsystem.components.DivamSectionTitle
import com.example.core.designsystem.components.ModuleStatusBadge
import com.example.core.model.ModuleOverviewItem
import com.example.core.model.ModuleReadiness
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskStatus
import com.example.core.model.UserPreferences
import com.example.core.model.WindowWidthClass
import com.example.core.navigation.AppRoutes
import com.example.feature.stats.StatsCalculator
import com.example.feature.tasks.TaskBoxCounts
import com.example.ui.theme.DivamTheme
import com.example.ui.theme.ThemeMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    widthClass: WindowWidthClass,
    themeMode: ThemeMode,
    userPreferences: UserPreferences,
    tasks: List<TaskItem>,
    boxCounts: TaskBoxCounts,
    scheduledRemindersCount: Int,
    onCreateNewTask: () -> Unit,
    onNavigateToRoute: (String) -> Unit,
    onEditTask: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayDayMillis = remember { TaskDateTimeUtils.todayLocalDayMillis() }
    val todayFormatted = remember {
        val localeTr = Locale.forLanguageTag("tr-TR")
        SimpleDateFormat("d MMMM yyyy, EEEE", localeTr).format(Date())
    }

    val activeTasks = remember(tasks) {
        tasks.filter { !it.isArchived && !it.isDeleted }
    }
    val completedCount = remember(activeTasks) {
        activeTasks.count { it.status == TaskStatus.COMPLETED }
    }
    val pendingCount = remember(activeTasks) {
        activeTasks.count {
            it.status == TaskStatus.PENDING ||
                it.status == TaskStatus.IN_PROGRESS ||
                it.status == TaskStatus.POSTPONED
        }
    }
    val todayCompletedCount = remember(tasks, todayDayMillis) {
        tasks.count {
            !it.isDeleted &&
                it.status == TaskStatus.COMPLETED &&
                StatsCalculator.completionLocalDayMillis(it) == todayDayMillis
        }
    }
    val overdueTasks = remember(tasks, todayDayMillis) {
        tasks.filter { task ->
            !task.isDeleted &&
                !task.isArchived &&
                task.status != TaskStatus.COMPLETED &&
                task.status != TaskStatus.CANCELLED &&
                task.startDateMillis != null &&
                task.startDateMillis < todayDayMillis
        }.sortedBy { it.startDateMillis }
    }

    val quickModules = remember(boxCounts, completedCount, scheduledRemindersCount) {
        listOf(
            ModuleOverviewItem(
                id = "tasks",
                title = "Görevler",
                subtitle = if (boxCounts.active == 0) {
                    "Henüz kayıtlı görev yok. İlk görevinizi oluşturabilirsiniz."
                } else {
                    "${boxCounts.active} aktif görev • $completedCount tamamlandı"
                },
                readiness = ModuleReadiness.ACTIVE,
                targetRoute = AppRoutes.TASKS
            ),
            ModuleOverviewItem(
                id = "calendar",
                title = "Takvim ve Zaman",
                subtitle = "Günlük, haftalık ve aylık yerel takvim planlaması.",
                readiness = ModuleReadiness.ACTIVE,
                targetRoute = AppRoutes.CALENDAR
            ),
            ModuleOverviewItem(
                id = "notifications",
                title = "Bildirim ve Ses Merkezi",
                subtitle = "$scheduledRemindersCount aktif hatırlatma planlandı • Ses ve sessiz saat ayarları.",
                readiness = ModuleReadiness.ACTIVE,
                targetRoute = AppRoutes.NOTIFICATIONS
            ),
            ModuleOverviewItem(
                id = "stats",
                title = "İstatistikler",
                subtitle = "Günlük, haftalık ve aylık grafikler ve hedef takibi.",
                readiness = ModuleReadiness.ACTIVE,
                targetRoute = AppRoutes.STATS
            ),
            ModuleOverviewItem(
                id = "profile",
                title = "Profil ve Ayarlar",
                subtitle = "Profil, görünüm, JSON yedekleme, PIN ve biyometrik kilit.",
                readiness = ModuleReadiness.ACTIVE,
                targetRoute = AppRoutes.PROFILE
            )
        )
    }

    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_ana_sayfa"),
        contentPadding = PaddingValues(
            start = horizontalPadding,
            end = horizontalPadding,
            top = 16.dp,
            bottom = 28.dp
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 1040.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                DivamSectionTitle(
                    title = stringResource(id = R.string.app_name),
                    subtitle = todayFormatted,
                    badge = ModuleReadiness.ACTIVE
                )

                if (widthClass.isTabletOrWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        WelcomeFoundationCard(
                            userName = userPreferences.userName,
                            themeMode = themeMode,
                            todayCompleted = todayCompletedCount,
                            dailyGoal = userPreferences.dailyTaskGoal,
                            onCreateNewTask = onCreateNewTask,
                            onOpenNotifications = { onNavigateToRoute(AppRoutes.NOTIFICATIONS) },
                            modifier = Modifier.weight(1.1f)
                        )
                        LiveTaskSummaryCard(
                            activeCount = boxCounts.active,
                            pendingCount = pendingCount,
                            completedCount = completedCount,
                            favoriteCount = boxCounts.favorites,
                            onOpenTasks = { onNavigateToRoute(AppRoutes.TASKS) },
                            modifier = Modifier.weight(0.9f)
                        )
                    }
                } else {
                    WelcomeFoundationCard(
                        userName = userPreferences.userName,
                        themeMode = themeMode,
                        todayCompleted = todayCompletedCount,
                        dailyGoal = userPreferences.dailyTaskGoal,
                        onCreateNewTask = onCreateNewTask,
                        onOpenNotifications = { onNavigateToRoute(AppRoutes.NOTIFICATIONS) }
                    )
                    LiveTaskSummaryCard(
                        activeCount = boxCounts.active,
                        pendingCount = pendingCount,
                        completedCount = completedCount,
                        favoriteCount = boxCounts.favorites,
                        onOpenTasks = { onNavigateToRoute(AppRoutes.TASKS) }
                    )
                }

                if (userPreferences.showOverdueOnHome && overdueTasks.isNotEmpty()) {
                    OverdueTasksHomeCard(
                        overdueTasks = overdueTasks,
                        dateFormatStyle = userPreferences.dateFormatStyle,
                        onEditTask = onEditTask,
                        onOpenAllTasks = { onNavigateToRoute(AppRoutes.TASKS) }
                    )
                }

                Text(
                    text = "Modül Geçişleri",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (widthClass.isTabletOrWide) {
                    quickModules.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            pair.forEach { item ->
                                QuickModuleCard(
                                    item = item,
                                    icon = iconForModule(item.id),
                                    onClick = { item.targetRoute?.let(onNavigateToRoute) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        quickModules.forEach { item ->
                            QuickModuleCard(
                                item = item,
                                icon = iconForModule(item.id),
                                onClick = { item.targetRoute?.let(onNavigateToRoute) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WelcomeFoundationCard(
    userName: String,
    themeMode: ThemeMode,
    todayCompleted: Int,
    dailyGoal: Int,
    onCreateNewTask: () -> Unit,
    onOpenNotifications: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val safeGoal = dailyGoal.coerceAtLeast(1)
    val goalRatio = (todayCompleted.toFloat() / safeGoal.toFloat()).coerceIn(0f, 1f)

    DivamCard(
        modifier = modifier.fillMaxWidth(),
        highlightGoldBorder = true
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            DivamLogoMark(size = 58.dp)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Hoş Geldiniz, $userName",
                    style = MaterialTheme.typography.titleLarge,
                    color = extended.goldMid,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Tüm veriler cihazınızda yerel olarak saklanır ve internet olmadan çalışır.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Günlük Hedef: $todayCompleted / $safeGoal",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Tema: ${themeMode.turkishLabel}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { goalRatio },
            color = extended.goldMid,
            trackColor = MaterialTheme.colorScheme.surfaceContainerLow,
            strokeCap = StrokeCap.Round,
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                onClick = onOpenNotifications,
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(1.dp, extended.cardBorderSubtle),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("home_notifications_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.NotificationsActive,
                        contentDescription = null,
                        tint = extended.goldMid,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Bildirimler",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Button(
                onClick = onCreateNewTask,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .weight(1.1f)
                    .height(44.dp)
                    .testTag("home_add_task_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Yeni Görev",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun OverdueTasksHomeCard(
    overdueTasks: List<TaskItem>,
    dateFormatStyle: com.example.core.model.DateFormatStyle,
    onEditTask: (Long) -> Unit,
    onOpenAllTasks: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    DivamCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_overdue_card"),
        highlightGoldBorder = true
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = null,
                    tint = extended.statusPlanned
                )
                Text(
                    text = "Geciken Görevler (${overdueTasks.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = extended.statusPlanned
                )
            }
            TextButton(onClick = onOpenAllTasks) {
                Text("Tümü", color = extended.goldMid)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            overdueTasks.take(3).forEach { task ->
                Surface(
                    onClick = { onEditTask(task.id) },
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, extended.cardBorderSubtle)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val dateStr = task.startDateMillis?.let {
                                TaskDateTimeUtils.formatDateTurkish(it, dateFormatStyle)
                            } ?: ""
                            Text(
                                text = "${task.categoryName} • $dateStr",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.ArrowForward,
                            contentDescription = "Görevi aç",
                            tint = extended.goldMid,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveTaskSummaryCard(
    activeCount: Int,
    pendingCount: Int,
    completedCount: Int,
    favoriteCount: Int,
    onOpenTasks: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors

    DivamCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_live_summary_card"),
        onClick = onOpenTasks
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Canlı Görev Özeti",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            ModuleStatusBadge(readiness = ModuleReadiness.ACTIVE)
        }
        Spacer(modifier = Modifier.height(10.dp))
        StatusSummaryLine(label = "Aktif Görevler", value = activeCount.toString())
        Spacer(modifier = Modifier.height(6.dp))
        StatusSummaryLine(label = "Bekleyen / Devam Eden", value = pendingCount.toString())
        Spacer(modifier = Modifier.height(6.dp))
        StatusSummaryLine(label = "Tamamlanan", value = completedCount.toString())
        Spacer(modifier = Modifier.height(6.dp))
        StatusSummaryLine(label = "Favori Görevler", value = favoriteCount.toString())
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Görevlere git",
                style = MaterialTheme.typography.labelLarge,
                color = extended.goldMid
            )
            Icon(
                imageVector = Icons.Rounded.ArrowForward,
                contentDescription = null,
                tint = extended.goldMid,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun StatusSummaryLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun QuickModuleCard(
    item: ModuleOverviewItem,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    DivamCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_module_card_${item.id}"),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = DivamTheme.extendedColors.goldMid,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            ModuleStatusBadge(readiness = item.readiness)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = item.subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun iconForModule(id: String): ImageVector = when (id) {
    "tasks" -> Icons.Rounded.CheckCircle
    "calendar" -> Icons.Rounded.CalendarMonth
    "notifications" -> Icons.Rounded.NotificationsActive
    "stats" -> Icons.Rounded.BarChart
    else -> Icons.Rounded.Person
}
