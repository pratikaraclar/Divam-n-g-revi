package com.example.feature.tasks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RestoreFromTrash
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.DivamCard
import com.example.core.model.CardDisplayStyle
import com.example.core.model.DateFormatStyle
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskPriority
import com.example.core.model.TaskRecurrence
import com.example.core.model.TaskStatus
import com.example.ui.theme.DivamTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskListItemCard(
    task: TaskItem,
    onOpenDetail: () -> Unit,
    onEdit: () -> Unit,
    onToggleComplete: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDuplicate: () -> Unit,
    onPostponeRequest: () -> Unit,
    onToggleArchive: () -> Unit,
    onMoveToTrash: () -> Unit,
    onRestoreFromTrash: () -> Unit,
    onDeletePermanently: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences
    val isCompleted = task.status == TaskStatus.COMPLETED
    val isCancelled = task.status == TaskStatus.CANCELLED
    val isCompact = userPrefs.cardDisplayStyle == CardDisplayStyle.COMPACT
    val isDetailed = userPrefs.cardDisplayStyle == CardDisplayStyle.DETAILED

    val scheduleSummary = remember(
        task.startDateMillis,
        task.endDateMillis,
        task.startTimeMinutes,
        task.endTimeMinutes,
        userPrefs.dateFormatStyle,
        userPrefs.use24HourFormat
    ) {
        buildScheduleSummary(task, userPrefs.dateFormatStyle, userPrefs.use24HourFormat)
    }

    DivamCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_card_${task.id}"),
        highlightGoldBorder = task.isFavorite && !task.isDeleted,
        onClick = onOpenDetail
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!task.isDeleted) {
                IconButton(
                    onClick = onToggleComplete,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("task_complete_toggle_${task.id}")
                ) {
                    Icon(
                        imageVector = if (isCompleted) {
                            Icons.Rounded.CheckCircle
                        } else {
                            Icons.Outlined.RadioButtonUnchecked
                        },
                        contentDescription = if (isCompleted) {
                            "Tamamlandı işaretini kaldır"
                        } else {
                            "Tamamlandı olarak işaretle"
                        },
                        tint = if (isCompleted) extended.statusActive else extended.goldMid
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        textDecoration = if (isCompleted || isCancelled) {
                            TextDecoration.LineThrough
                        } else {
                            TextDecoration.None
                        }
                    ),
                    color = if (isCompleted || isCancelled) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (task.description.isNotBlank() && !isCompact) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = if (isDetailed) 4 else 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (!task.isDeleted) {
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("task_favorite_toggle_${task.id}")
                ) {
                    Icon(
                        imageVector = if (task.isFavorite) {
                            Icons.Rounded.Star
                        } else {
                            Icons.Outlined.StarOutline
                        },
                        contentDescription = if (task.isFavorite) {
                            "Favorilerden çıkar"
                        } else {
                            "Favorilere ekle"
                        },
                        tint = if (task.isFavorite) {
                            extended.goldMid
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("task_menu_button_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MoreVert,
                        contentDescription = "Görev işlemleri",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    if (task.isDeleted) {
                        DropdownMenuItem(
                            text = { Text("Geri Yükle") },
                            leadingIcon = {
                                Icon(Icons.Rounded.RestoreFromTrash, contentDescription = null)
                            },
                            onClick = {
                                menuExpanded = false
                                onRestoreFromTrash()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Kalıcı Olarak Sil") },
                            leadingIcon = {
                                Icon(
                                    Icons.Rounded.DeleteForever,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                onDeletePermanently()
                            }
                        )
                    } else {
                        DropdownMenuItem(
                            text = { Text("Düzenle") },
                            leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(if (isCompleted) "Bekliyor Yap" else "Tamamlandı İşaretle")
                            },
                            leadingIcon = {
                                Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                            },
                            onClick = {
                                menuExpanded = false
                                onToggleComplete()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Kopyala") },
                            leadingIcon = {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                            },
                            onClick = {
                                menuExpanded = false
                                onDuplicate()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Ertele") },
                            leadingIcon = { Icon(Icons.Rounded.Update, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onPostponeRequest()
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(if (task.isArchived) "Arşivden Çıkar" else "Arşivle")
                            },
                            leadingIcon = {
                                Icon(
                                    if (task.isArchived) Icons.Rounded.Unarchive else Icons.Rounded.Archive,
                                    contentDescription = null
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                onToggleArchive()
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Çöp Kutusuna Taşı") },
                            leadingIcon = {
                                Icon(
                                    Icons.Rounded.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                onMoveToTrash()
                            }
                        )
                    }
                }
            }
        }

        if (task.note.isNotBlank() && !isCompact) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerLow)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.StickyNote2,
                    contentDescription = null,
                    tint = extended.goldMid,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = task.note,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = if (isDetailed) 3 else 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(if (isCompact) 6.dp else 10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TaskTagPill(
                text = task.status.turkishLabel,
                accentColor = statusAccentColor(task.status)
            )
            TaskTagPill(
                text = "Öncelik: ${task.priority.turkishLabel}",
                accentColor = priorityAccentColor(task.priority)
            )
            TaskTagPill(
                text = task.categoryName,
                accentColor = MaterialTheme.colorScheme.secondary
            )
            if (scheduleSummary != null) {
                TaskTagPill(
                    text = scheduleSummary,
                    accentColor = extended.goldMid
                )
            }
            if (task.recurrence != TaskRecurrence.NONE) {
                TaskTagPill(
                    text = task.recurrence.turkishLabel,
                    accentColor = MaterialTheme.colorScheme.primary
                )
            }
            if (!isCompact && task.reminderEnabled && task.reminderOffsetsMinutes.isNotEmpty() &&
                task.startDateMillis != null && task.startTimeMinutes != null
            ) {
                val reminderText = if (task.reminderOffsetsMinutes.size == 1) {
                    TaskDateTimeUtils.formatReminderOffsetTurkish(task.reminderOffsetsMinutes.first())
                } else {
                    "${task.reminderOffsetsMinutes.size} hatırlatma"
                }
                TaskTagPill(
                    text = reminderText,
                    accentColor = extended.goldStart
                )
            }
        }

        if (task.isDeleted) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(
                    onClick = onRestoreFromTrash,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.RestoreFromTrash,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Geri Yükle")
                }
                TextButton(
                    onClick = onDeletePermanently,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteForever,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Kalıcı Sil", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun TaskDetailDialog(
    task: TaskItem,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onStatusChange: (TaskStatus) -> Unit,
    onDuplicate: () -> Unit,
    onPostpone: () -> Unit,
    onArchiveToggle: () -> Unit,
    onMoveToTrash: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    val userPrefs = DivamTheme.userPreferences
    val scheduleText = buildScheduleSummary(
        task = task,
        dateStyle = userPrefs.dateFormatStyle,
        use24Hour = userPrefs.use24HourFormat
    ) ?: "Tarih veya saat belirtilmedi"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (task.isFavorite) {
                    Icon(
                        imageVector = Icons.Rounded.Star,
                        contentDescription = "Favori",
                        tint = extended.goldMid,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (task.description.isNotBlank()) {
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarToday,
                        contentDescription = null,
                        tint = extended.goldMid,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = scheduleText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "Kategori: ${task.categoryName} • Öncelik: ${task.priority.turkishLabel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (task.note.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, extended.cardBorderSubtle)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Özel Not",
                                style = MaterialTheme.typography.labelSmall,
                                color = extended.goldMid
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = task.note,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                if (!task.isDeleted) {
                    Text(
                        text = "Hızlı Durum Değiştir",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    @OptIn(ExperimentalLayoutApi::class)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TaskStatus.entries.forEach { st ->
                            val selected = task.status == st
                            Surface(
                                onClick = { onStatusChange(st) },
                                shape = RoundedCornerShape(50),
                                color = if (selected) {
                                    MaterialTheme.colorScheme.secondaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainerLow
                                },
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) extended.goldMid else extended.cardBorderSubtle
                                )
                            ) {
                                Text(
                                    text = st.turkishLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) extended.goldStart else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = onDuplicate) { Text("Kopyala") }
                        TextButton(onClick = onPostpone) { Text("Ertele") }
                        TextButton(onClick = onArchiveToggle) {
                            Text(if (task.isArchived) "Çıkar" else "Arşivle")
                        }
                        TextButton(onClick = onMoveToTrash) {
                            Text("Sil", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!task.isDeleted) {
                TextButton(onClick = onEdit) {
                    Text("Düzenle", color = extended.goldMid)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat")
            }
        }
    )
}

@Composable
private fun TaskTagPill(
    text: String,
    accentColor: Color
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = accentColor.copy(alpha = 0.13f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = accentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun statusAccentColor(status: TaskStatus): Color {
    val extended = DivamTheme.extendedColors
    return when (status) {
        TaskStatus.PENDING -> MaterialTheme.colorScheme.onSurfaceVariant
        TaskStatus.IN_PROGRESS -> extended.goldMid
        TaskStatus.COMPLETED -> extended.statusActive
        TaskStatus.POSTPONED -> extended.statusPlanned
        TaskStatus.CANCELLED -> MaterialTheme.colorScheme.error
    }
}

@Composable
private fun priorityAccentColor(priority: TaskPriority): Color {
    val extended = DivamTheme.extendedColors
    return when (priority) {
        TaskPriority.LOW -> MaterialTheme.colorScheme.onSurfaceVariant
        TaskPriority.NORMAL -> MaterialTheme.colorScheme.primary
        TaskPriority.HIGH -> extended.goldMid
    }
}

private fun buildScheduleSummary(
    task: TaskItem,
    dateStyle: DateFormatStyle = DateFormatStyle.SHORT_MONTH,
    use24Hour: Boolean = true
): String? {
    val startDate = task.startDateMillis?.let { TaskDateTimeUtils.formatDateTurkish(it, dateStyle) }
    val endDate = task.endDateMillis?.let { TaskDateTimeUtils.formatDateTurkish(it, dateStyle) }
    val startTime = task.startTimeMinutes?.let { TaskDateTimeUtils.formatTimeMinutes(it, use24Hour) }
    val endTime = task.endTimeMinutes?.let { TaskDateTimeUtils.formatTimeMinutes(it, use24Hour) }

    val datePart = when {
        startDate != null && endDate != null && startDate != endDate -> "$startDate - $endDate"
        startDate != null -> startDate
        endDate != null -> "Bitiş: $endDate"
        else -> null
    }
    val timePart = when {
        startTime != null && endTime != null -> "$startTime-$endTime"
        startTime != null -> startTime
        endTime != null -> "Son: $endTime"
        else -> null
    }
    return listOfNotNull(datePart, timePart).takeIf { it.isNotEmpty() }?.joinToString(" • ")
}
