package com.example.feature.profile

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.core.designsystem.components.DivamCard
import com.example.core.designsystem.components.DivamLogoMark
import com.example.core.designsystem.components.DivamSectionTitle
import com.example.core.model.ModuleReadiness
import com.example.core.model.TaskDateTimeUtils
import com.example.core.model.TaskItem
import com.example.core.model.TaskStatus
import com.example.core.model.UserPreferences
import com.example.core.model.WindowWidthClass
import com.example.feature.settings.EditUserNameDialog
import com.example.feature.settings.GoalEditorDialog
import com.example.feature.stats.StatsCalculator
import com.example.ui.theme.DivamTheme
import com.example.ui.theme.ThemeMode

@Composable
fun ProfileScreen(
    widthClass: WindowWidthClass,
    themeMode: ThemeMode,
    userPreferences: UserPreferences,
    tasks: List<TaskItem>,
    onOpenSettings: () -> Unit,
    onOpenNotifications: () -> Unit,
    onUpdateUserName: (String) -> Unit,
    onSaveAvatarUri: (Uri) -> Unit,
    onRemoveAvatar: () -> Unit,
    onUpdateGoals: (daily: Int, weekly: Int) -> Unit,
    onDeleteAllPersonalData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val horizontalPadding = if (widthClass.isTabletOrWide) 28.dp else 16.dp

    var showNameDialog by remember { mutableStateOf(false) }
    var showGoalsDialog by remember { mutableStateOf(false) }
    var showWipeStep1 by remember { mutableStateOf(false) }
    var showWipeStep2 by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSaveAvatarUri(uri)
        }
    }

    val todayMillis = remember { TaskDateTimeUtils.todayLocalDayMillis() }
    val todayCompleted = remember(tasks, todayMillis) {
        tasks.count {
            !it.isDeleted &&
                it.status == TaskStatus.COMPLETED &&
                StatsCalculator.completionLocalDayMillis(it) == todayMillis
        }
    }
    val weekDays = remember(todayMillis, userPreferences.weekStartDay) {
        com.example.feature.calendar.CalendarLogic.weekDaysFor(todayMillis, userPreferences.weekStartDay)
    }
    val weeklyCompleted = remember(tasks, weekDays) {
        val start = weekDays.first()
        val end = weekDays.last()
        tasks.count { task ->
            val completedDay = StatsCalculator.completionLocalDayMillis(task)
            !task.isDeleted &&
                task.status == TaskStatus.COMPLETED &&
                completedDay != null &&
                completedDay in start..end
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("screen_profil"),
        contentPadding = PaddingValues(
            start = horizontalPadding,
            end = horizontalPadding,
            top = 16.dp,
            bottom = 28.dp
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 1040.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                DivamSectionTitle(
                    title = "Profil",
                    subtitle = "Kullanıcı profili, hedefler, bildirimler ve ayarlar",
                    badge = ModuleReadiness.ACTIVE
                )

                if (widthClass.isTabletOrWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        ProfileIdentityCard(
                            userPreferences = userPreferences,
                            onPickPhoto = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onRemovePhoto = onRemoveAvatar,
                            onEditName = { showNameDialog = true },
                            modifier = Modifier.weight(1f)
                        )
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            EntryShortcutCard(
                                title = "Ayarlar",
                                subtitle = "Tema, görünüm, tarih/saat, yedekleme ve PIN kilidi",
                                icon = Icons.Rounded.Settings,
                                onClick = onOpenSettings,
                                testTag = "profile_settings_button"
                            )
                            EntryShortcutCard(
                                title = "Bildirim ve Ses Merkezi",
                                subtitle = "Hatırlatmalar, ses önizleme ve sessiz saatler",
                                icon = Icons.Rounded.NotificationsActive,
                                onClick = onOpenNotifications,
                                testTag = "profile_notifications_button"
                            )
                        }
                    }
                } else {
                    ProfileIdentityCard(
                        userPreferences = userPreferences,
                        onPickPhoto = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onRemovePhoto = onRemoveAvatar,
                        onEditName = { showNameDialog = true }
                    )
                    EntryShortcutCard(
                        title = "Ayarlar",
                        subtitle = "Tema, görünüm, tarih/saat, yedekleme ve PIN kilidi",
                        icon = Icons.Rounded.Settings,
                        onClick = onOpenSettings,
                        testTag = "profile_settings_button"
                    )
                    EntryShortcutCard(
                        title = "Bildirim ve Ses Merkezi",
                        subtitle = "Hatırlatmalar, ses önizleme ve sessiz saatler",
                        icon = Icons.Rounded.NotificationsActive,
                        onClick = onOpenNotifications,
                        testTag = "profile_notifications_button"
                    )
                }

                // Kişisel ve Günlük Görev Hedefleri
                DivamCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.TrackChanges, contentDescription = null, tint = extended.goldMid)
                            Text(
                                text = "Kişisel Görev Hedefleri",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        TextButton(
                            onClick = { showGoalsDialog = true },
                            modifier = Modifier.testTag("profile_edit_goals_button")
                        ) {
                            Text("Düzenle", color = extended.goldMid)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    GoalProgressLine(
                        label = "Günlük Görev Hedefi",
                        completed = todayCompleted,
                        target = userPreferences.dailyTaskGoal
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    GoalProgressLine(
                        label = "Kişisel Haftalık Hedef",
                        completed = weeklyCompleted,
                        target = userPreferences.weeklyTaskGoal
                    )
                }

                // Uygulama ve Hesap Durumu (Dürüst bilgilendirme)
                DivamCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Uygulama ve Depolama Bilgileri",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    InfoRow(label = "Uygulama", value = stringResource(id = R.string.app_name))
                    Spacer(modifier = Modifier.height(6.dp))
                    InfoRow(label = "Sürüm", value = "${BuildConfig.VERSION_NAME} (Yapı ${BuildConfig.VERSION_CODE})")
                    Spacer(modifier = Modifier.height(6.dp))
                    InfoRow(label = "Aktif Tema", value = themeMode.turkishLabel)
                    Spacer(modifier = Modifier.height(6.dp))
                    InfoRow(label = "Ekran Sınıfı", value = widthClass.turkishLabel)
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, extended.cardBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Çevrimdışı yerel profil kullanılır. Çıkış yapılacak bir bulut hesap sistemi mevcut değildir; verileriniz cihazınızda korunur.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Kişisel Verileri Silme
                DivamCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteForever,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = "Kişisel Verileri Temizle",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Tüm görevleri, özel kategorileri, bildirim geçmişini, yerel yedekleri ve profil fotoğrafını cihazdan kalıcı olarak siler.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { showWipeStep1 = true },
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("profile_delete_personal_data")
                    ) {
                        Text("Tüm Kişisel Verileri Sil", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (showNameDialog) {
        EditUserNameDialog(
            currentName = userPreferences.userName,
            onDismiss = { showNameDialog = false },
            onSave = onUpdateUserName
        )
    }

    if (showGoalsDialog) {
        GoalEditorDialog(
            currentDaily = userPreferences.dailyTaskGoal,
            currentWeekly = userPreferences.weeklyTaskGoal,
            onDismiss = { showGoalsDialog = false },
            onSave = onUpdateGoals
        )
    }

    if (showWipeStep1) {
        AlertDialog(
            onDismissRequest = { showWipeStep1 = false },
            title = { Text("Kişisel Verileri Sil") },
            text = {
                Text("Bu işlem tüm görevlerinizi, notlarınızı, yerel yedek kopyalarınızı ve profil fotoğrafınızı siler. Devam etmek istiyor musunuz?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showWipeStep1 = false
                        showWipeStep2 = true
                    }
                ) {
                    Text("Devam Et", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeStep1 = false }) { Text("İptal") }
            }
        )
    }

    if (showWipeStep2) {
        AlertDialog(
            onDismissRequest = { showWipeStep2 = false },
            title = { Text("Son Onay") },
            text = {
                Text("Silinen yerel veriler dışarı aktarılmış bir JSON yedeğiniz yoksa geri alınamaz. Onaylıyor musunuz?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAllPersonalData()
                        showWipeStep2 = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Kalıcı Olarak Sil")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeStep2 = false }) { Text("Vazgeç") }
            }
        )
    }
}

@Composable
private fun ProfileIdentityCard(
    userPreferences: UserPreferences,
    onPickPhoto: () -> Unit,
    onRemovePhoto: () -> Unit,
    onEditName: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    val avatarBitmap = remember(userPreferences.avatarLocalPath) {
        val path = userPreferences.avatarLocalPath
        if (!path.isNullOrBlank()) {
            runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull()
        } else {
            null
        }
    }

    DivamCard(
        modifier = modifier.fillMaxWidth(),
        highlightGoldBorder = true
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .border(2.dp, extended.goldMid, CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerLow),
                contentAlignment = Alignment.Center
            ) {
                if (avatarBitmap != null) {
                    Image(
                        bitmap = avatarBitmap,
                        contentDescription = "Profil fotoğrafı",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    DivamLogoMark(size = 56.dp)
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = userPreferences.userName,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    IconButton(
                        onClick = onEditName,
                        modifier = Modifier.testTag("profile_edit_name_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "Kullanıcı adını düzenle",
                            tint = extended.goldMid,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Text(
                    text = "Günlük hedef: ${userPreferences.dailyTaskGoal} görev • Haftalık: ${userPreferences.weeklyTaskGoal}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onPickPhoto,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, extended.goldMid),
                modifier = Modifier.weight(1f).testTag("profile_pick_photo_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.AddAPhoto,
                    contentDescription = null,
                    tint = extended.goldMid,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (avatarBitmap == null) "Fotoğraf Ekle" else "Fotoğrafı Değiştir",
                    style = MaterialTheme.typography.labelMedium,
                    color = extended.goldMid,
                    maxLines = 1
                )
            }
            if (avatarBitmap != null) {
                TextButton(onClick = onRemovePhoto) {
                    Text("Kaldır", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun EntryShortcutCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val extended = DivamTheme.extendedColors
    DivamCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag),
        highlightGoldBorder = true,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.secondaryContainer)
                    .border(1.dp, extended.cardBorderGold, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = extended.goldMid,
                    modifier = Modifier.size(24.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = title,
                tint = extended.goldMid
            )
        }
    }
}

@Composable
private fun GoalProgressLine(label: String, completed: Int, target: Int) {
    val extended = DivamTheme.extendedColors
    val safeTarget = target.coerceAtLeast(1)
    val ratio = (completed.toFloat() / safeTarget.toFloat()).coerceIn(0f, 1f)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(
                "$completed / $safeTarget",
                style = MaterialTheme.typography.labelLarge,
                color = extended.goldMid,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { ratio },
            color = extended.goldMid,
            trackColor = MaterialTheme.colorScheme.surfaceContainerLow,
            strokeCap = StrokeCap.Round,
            modifier = Modifier.fillMaxWidth().height(7.dp)
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
