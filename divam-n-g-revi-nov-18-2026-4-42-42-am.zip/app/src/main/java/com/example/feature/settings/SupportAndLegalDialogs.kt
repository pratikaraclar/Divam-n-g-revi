package com.example.feature.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.core.backup.BackupValidationPreview
import com.example.core.notifications.NotificationChannelHelper
import com.example.core.security.AppSecurityHelper
import com.example.feature.tasks.divamTextFieldColors
import com.example.ui.theme.DivamTheme

enum class SupportDocumentKind(val title: String) {
    PRIVACY_POLICY("Gizlilik Politikası"),
    TERMS_OF_USE("Kullanım Koşulları"),
    FAQ("Sık Sorulan Sorular"),
    USAGE_GUIDE("Kullanım Rehberi"),
    NOTIFICATION_HELP("Bildirim Sorunları Yardımı")
}

@Composable
fun SupportDocumentDialog(
    kind: SupportDocumentKind,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val extended = DivamTheme.extendedColors

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = kind.title,
                style = MaterialTheme.typography.titleLarge,
                color = extended.goldMid
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (kind) {
                    SupportDocumentKind.PRIVACY_POLICY -> {
                        SupportSectionItem(
                            heading = "1. Verilerin Yerel Saklanması",
                            body = "Divamın Görevi, oluşturduğunuz tüm görevleri, özel notları, kategorileri, bildirim geçmişini ve profil tercihlerinizi yalnızca cihazınızdaki yerel Room veritabanında ve DataStore alanında saklar."
                        )
                        SupportSectionItem(
                            heading = "2. Bulut İletimi ve Hesap Durumu",
                            body = "Bu sürümde uzaktan sunucuya veya bulut hesabına otomatik veri gönderimi yapılmaz. İnternet bağlantısı olmadan da tüm temel görev, takvim, istatistik ve yerel bildirim özellikleri çalışır."
                        )
                        SupportSectionItem(
                            heading = "3. Fotoğraf Seçici ve Yedek Dosyaları",
                            body = "Profil fotoğrafı için yalnızca Android sistem Fotoğraf Seçici (Photo Picker) kullanılır ve geniş depolama izni istenmez. JSON yedekleri yalnızca sizin seçtiğiniz konuma kaydedilir."
                        )
                        SupportSectionItem(
                            heading = "4. Güvenlik",
                            body = "Uygulama kilidi PIN kodunuz rastgele tuz (salt) ile SHA-256 özeti alınarak saklanır; düz metin olarak tutulmaz."
                        )
                    }
                    SupportDocumentKind.TERMS_OF_USE -> {
                        SupportSectionItem(
                            heading = "1. Kullanım Amacı",
                            body = "Divamın Görevi, kişisel görev yönetimi, yerel takvim planlaması, yerel hatırlatmalar ve üretkenlik raporlaması sunmak amacıyla hazırlanmıştır."
                        )
                        SupportSectionItem(
                            heading = "2. Kullanıcı Sorumluluğu",
                            body = "Verileriniz cihazınızda saklandığı için cihaz değişimi veya uygulama kaldırma öncesinde Ayarlar > Yedekleme bölümünden JSON yedeği almanız önerilir."
                        )
                        SupportSectionItem(
                            heading = "3. Bildirim Teslimatı",
                            body = "Android cihazların üretici pil optimizasyonu ve 'Rahatsız Etmeyin' ayarları zamanlanmış bildirimlerin teslimat zamanını etkileyebilir."
                        )
                    }
                    SupportDocumentKind.FAQ -> {
                        SupportSectionItem(
                            heading = "Verilerim internet olmadan da kaydedilir mi?",
                            body = "Evet. Görevler, kategoriler, takvim değişiklikleri, istatistikler ve ayarlar tamamen cihazınızda çevrimdışı olarak saklanır."
                        )
                        SupportSectionItem(
                            heading = "Bildirim sesini değiştirdiğimde neden kanal yenileniyor?",
                            body = "Android 8 ve üzeri sürümlerde bildirim kanallarının sesi sistem tarafından kilitlenir. Seçtiğiniz yeni sesin sonraki bildirimlerde geçerli olması için uygulama kanal sürümünü otomatik günceller."
                        )
                        SupportSectionItem(
                            heading = "Yedek geri yüklerken aynı görevler iki kez eklenir mi?",
                            body = "Hayır. Yedek dosyası içe aktarılmadan önce kontrol edilir; başlık, başlangıç tarihi, başlangıç saati ve kategori eşleşen mükerrer kayıtlar atlanır."
                        )
                        SupportSectionItem(
                            heading = "Hesapla giriş ve bulut senkronizasyonu var mı?",
                            body = "Bu sürümde çevrimdışı yerel çalışma esastır; bulut hesap eşitlemesi yer almaz. Cihazlar arası aktarım için JSON Dışa/İçe Aktarma kullanabilirsiniz."
                        )
                    }
                    SupportDocumentKind.USAGE_GUIDE -> {
                        SupportSectionItem(
                            heading = "1. Görevler ve Özel Notlar",
                            body = "Görevler sekmesinden veya Ana Sayfa'daki 'Yeni Görev' butonundan başlangıç/bitiş tarihi, saat, öncelik, kategori, özel not, tekrar ve hatırlatma ekleyebilirsiniz."
                        )
                        SupportSectionItem(
                            heading = "2. Takvim Yönetimi",
                            body = "Takvim sekmesinde Günlük, Haftalık ve Aylık görünümler arasında geçebilir, görev saatini güncelleyebilir veya seçili güne doğrudan yeni görev ekleyebilirsiniz."
                        )
                        SupportSectionItem(
                            heading = "3. Bildirimler ve Ses Stüdyosu",
                            body = "Bildirim ve Ses Merkezi'nden izinleri kontrol edebilir, görevden önce hatırlatma sürelerini seçebilir, sabah/akşam özet saatlerini ayarlayabilir ve ses önizlemesi dinleyebilirsiniz."
                        )
                        SupportSectionItem(
                            heading = "4. İstatistikler ve Yedekleme",
                            body = "İstatistikler yalnızca gerçek görev kayıtlarınızdan hesaplanır. Ayarlar'dan PIN/Biyometrik kilit açabilir ve JSON yedeği alabilirsiniz."
                        )
                    }
                    SupportDocumentKind.NOTIFICATION_HELP -> {
                        SupportSectionItem(
                            heading = "1. Bildirim ve Tam Zamanlı Alarm İzni",
                            body = "Android 13+ cihazlarda bildirim izni, Android 12+ cihazlarda ise 'Alarmlar ve Hatırlatıcılar' izni açık olmalıdır."
                        )
                        SupportSectionItem(
                            heading = "2. Pil Optimizasyonu Kısıtlaması",
                            body = "Arka planda bildirimlerin gecikmemesi için pil ayarlarından Divamın Görevi için 'Kısıtlanmamış' pil kullanımını seçmeniz önerilir."
                        )
                        SupportSectionItem(
                            heading = "3. Sessiz Saatler Kontrolü",
                            body = "Sessiz saatler etkinse bildirimler seçili politikaya göre sessiz kanala alınır veya tamamen susturulur."
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = { NotificationChannelHelper.openAppNotificationSettings(context) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Cihaz Bildirim Ayarlarını Aç")
                        }
                        OutlinedButton(
                            onClick = { NotificationChannelHelper.openExactAlarmSettings(context) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Tam Zamanlı Alarm İznini Aç")
                        }
                        OutlinedButton(
                            onClick = { NotificationChannelHelper.openBatteryOptimizationSettings(context) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Pil Optimizasyonu Ayarlarını Aç")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat", color = extended.goldMid, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun SupportSectionItem(heading: String, body: String) {
    val extended = DivamTheme.extendedColors
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, extended.cardBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = heading,
                style = MaterialTheme.typography.titleSmall,
                color = extended.goldMid,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun FeedbackDialog(
    onDismiss: () -> Unit,
    onResultMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val extended = DivamTheme.extendedColors
    var messageText by remember { mutableStateOf("") }
    var issueCategory by remember { mutableStateOf("Geri Bildirim") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Geri Bildirim ve Sorun Bildir", color = extended.goldMid) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Açıklamanız cihaz ve sürüm bilgisiyle birlikte e-posta veya paylaşım uygulaması üzerinden hazırlanır.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Geri Bildirim", "Hata Bildirimi").forEach { option ->
                        OutlinedButton(
                            onClick = { issueCategory = option },
                            border = BorderStroke(
                                1.dp,
                                if (issueCategory == option) extended.goldMid else extended.cardBorderSubtle
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = option,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (issueCategory == option) extended.goldMid else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it.take(600) },
                    label = { Text("Mesajınız") },
                    placeholder = { Text("Karşılaştığınız durumu veya önerinizi yazın...") },
                    minLines = 3,
                    maxLines = 5,
                    colors = divamTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val launched = launchFeedbackIntent(context, issueCategory, messageText.trim())
                    onResultMessage(
                        if (launched) {
                            "Geri bildirim paylaşım penceresi açıldı"
                        } else {
                            "Cihazda uygun e-posta veya paylaşım uygulaması bulunamadı"
                        }
                    )
                    onDismiss()
                },
                enabled = messageText.trim().length >= 3,
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Gönder")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

private fun launchFeedbackIntent(context: Context, category: String, body: String): Boolean {
    val fullBody = buildString {
        appendLine("Kategori: $category")
        appendLine("Uygulama: Divamın Görevi v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
        appendLine("Cihaz: ${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine()
        appendLine(body)
    }
    val mailIntent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:")
        putExtra(Intent.EXTRA_SUBJECT, "Divamın Görevi - $category")
        putExtra(Intent.EXTRA_TEXT, fullBody)
    }
    if (runCatching { context.startActivity(mailIntent) }.isSuccess) {
        return true
    }
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Divamın Görevi - $category")
        putExtra(Intent.EXTRA_TEXT, fullBody)
    }
    val chooser = Intent.createChooser(shareIntent, "Geri Bildirim Gönder")
    return runCatching { context.startActivity(chooser) }.isSuccess
}

@Composable
fun PinSetupDialog(
    hasExistingPin: Boolean,
    onDismiss: () -> Unit,
    onSavePin: (String) -> Boolean,
    onDisablePin: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    var pin1 by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (hasExistingPin) "PIN Kodunu Güncelle" else "Uygulama PIN Kodu Oluştur",
                color = extended.goldMid
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "4 ile 6 hane arasında yalnızca rakamlardan oluşan bir PIN belirleyin.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = pin1,
                    onValueChange = { raw ->
                        pin1 = raw.filter { it.isDigit() }.take(6)
                        errorText = null
                    },
                    label = { Text("Yeni PIN (4–6 hane)") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = divamTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("pin_setup_input_1")
                )
                OutlinedTextField(
                    value = pin2,
                    onValueChange = { raw ->
                        pin2 = raw.filter { it.isDigit() }.take(6)
                        errorText = null
                    },
                    label = { Text("PIN Tekrar") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = divamTextFieldColors(),
                    modifier = Modifier.fillMaxWidth().testTag("pin_setup_input_2")
                )
                if (!errorText.isNullOrBlank()) {
                    Text(
                        text = errorText!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                if (hasExistingPin) {
                    TextButton(
                        onClick = {
                            onDisablePin()
                            onDismiss()
                        }
                    ) {
                        Text("Uygulama Kilidini Kapat", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!AppSecurityHelper.isPinFormatValid(pin1)) {
                        errorText = "PIN 4–6 haneli rakamlardan oluşmalıdır."
                    } else if (pin1 != pin2) {
                        errorText = "Girilen PIN kodları eşleşmiyor."
                    } else if (onSavePin(pin1)) {
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
fun BackupRestorePreviewDialog(
    preview: BackupValidationPreview,
    onDismiss: () -> Unit,
    onConfirmRestore: () -> Unit
) {
    val extended = DivamTheme.extendedColors
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yedek Doğrulama Özeti", color = extended.goldMid) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Yedek dosyası doğrulandı. İçe aktarma öncesi mükerrer kayıt kontrolü tamamlandı:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text("• Dosyadaki toplam görev: ${preview.totalTasksInFile}")
                Text("• Eklenecek yeni görev: ${preview.newTasksToImportCount}", color = extended.goldMid, fontWeight = FontWeight.Bold)
                Text("• Atlanacak yinelenen kayıt: ${preview.duplicateTasksSkippedCount}")
                Text("• Eklenecek yeni kategori: ${preview.newCategoriesCount}")
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmRestore,
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier.testTag("confirm_restore_backup_button")
            ) {
                Text("Geri Yükle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
fun GoalEditorDialog(
    currentDaily: Int,
    currentWeekly: Int,
    onDismiss: () -> Unit,
    onSave: (daily: Int, weekly: Int) -> Unit
) {
    val extended = DivamTheme.extendedColors
    var dailyText by remember { mutableStateOf(currentDaily.toString()) }
    var weeklyText by remember { mutableStateOf(currentWeekly.toString()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Görev Hedeflerini Düzenle", color = extended.goldMid) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = dailyText,
                    onValueChange = { dailyText = it.filter { ch -> ch.isDigit() }.take(2); errorMsg = null },
                    label = { Text("Günlük Görev Hedefi (1–50)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = divamTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = weeklyText,
                    onValueChange = { weeklyText = it.filter { ch -> ch.isDigit() }.take(3); errorMsg = null },
                    label = { Text("Kişisel / Haftalık Görev Hedefi (1–300)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = divamTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                if (!errorMsg.isNullOrBlank()) {
                    Text(errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val d = dailyText.toIntOrNull()
                    val w = weeklyText.toIntOrNull()
                    if (d == null || d !in 1..50 || w == null || w !in 1..300) {
                        errorMsg = "Lütfen geçerli hedef sayıları girin."
                    } else {
                        onSave(d, w)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}

@Composable
fun EditUserNameDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val extended = DivamTheme.extendedColors
    var name by remember { mutableStateOf(currentName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kullanıcı Adını Düzenle", color = extended.goldMid) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(40) },
                label = { Text("Adınız") },
                singleLine = true,
                colors = divamTextFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.trim().isNotEmpty()) {
                        onSave(name.trim())
                        onDismiss()
                    }
                },
                enabled = name.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = extended.goldMid,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}
